#import visdom
import config_2d
from NetModel import Unet_2d, Unet_plus_2d, MultiResUnet_2d, MultiResUnet_plus_2d,Unet_4
import torch, time
from torch import nn, optim
from torch.utils.data import DataLoader
from traindataset_2d import MyTrainDataset
from torchvision.transforms import transforms
from metrics_2d import dice_loss, dice
import os

unet2d = Unet_2d.UNet2D                             # U-Net
unet2d_4 = Unet_4.UNet2D_4
unetplus2d = Unet_plus_2d.UNetPlus2D                # U-Net++
multiresunet2d = MultiResUnet_2d.MultiResUnet2D     # MultiRes U-Net
ournet2d = MultiResUnet_plus_2d.MultiResUnetPlus2D  # MultiRes U-Net++

patch_size_w = config_2d.PATCH_SIZE_W
patch_size_h = config_2d.PATCH_SIZE_H
batch_size = config_2d.BATCH_SIZE
n_epochs = config_2d.NUM_EPOCHS
n_classes = config_2d.NUM_CLASSES
image_rows = config_2d.VOLUME_ROWS
image_cols = config_2d.VOLUME_COLS
image_depth = config_2d.VOLUME_DEPS
test_imgs_path = config_2d.test_imgs_path
lr = config_2d.LR
flag_gpu = config_2d.FLAG_GPU

# 是否使用cuda
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# train
def train():
    global model, losses
    # 模型选择
    # 2D U-Net
    op_lr = 0.002

    model = unet2d(1, 2).to(device)
    # 训练集选择
    ON_train_x_t1_dir = 'ON_mydata/train_data/x_t1_data/'
    ON_train_x_fa_dir = 'ON_mydata/train_data/x_fa_data/'
    ON_train_y_dir = 'ON_mydata/train_data/y_data/'

    # 验证集选择
    ON_val_x_t1_dir = 'ON_mydata/val_data/x_t1_data/'
    ON_val_x_fa_dir = 'ON_mydata/val_data/x_fa_data/'
    ON_val_y_dir = 'ON_mydata/val_data/y_data/'

    # 损失函数选择
    losses = dice_loss()

    # 是否使用多块GPU
    if flag_gpu == 1:
        model = nn.DataParallel(model).cuda()

    # model.load_state_dict(torch.load(r"outputs_128_t1/20epoch_128batch.pth", map_location='cuda'))


    train_dataset = MyTrainDataset(ON_train_x_t1_dir, ON_train_x_fa_dir, ON_train_y_dir, x_transform=x_transforms, y_transform=y_transforms)
    train_dataloader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=0)

    val_dataset = MyTrainDataset(ON_val_x_t1_dir, ON_val_x_fa_dir, ON_val_y_dir, x_transform=x_transforms, y_transform=y_transforms)
    val_dataloader = DataLoader(val_dataset, batch_size=batch_size, shuffle=True, num_workers=0)


    ###----------------------
    #### start train
    print('-' * 30)
    print('Training start...')
    print('-' * 30)
    print('patch size   : ', patch_size_w, 'x', patch_size_h)
    print('batch size   : ', batch_size)
    print('  epoch      : ', n_epochs)
    print('learning rate: ', op_lr)
    print('-' * 30)


    last_val_epoch_loss = 10
    loss_nodecrease_num = 0


    for epoch in range(0, n_epochs):

        if (epoch+1) > 20:
            op_lr = lr * 0.5

        if (epoch+1) > 100:
            op_lr = lr * 0.5 * 0.5

        if (epoch+1) > 150:
            op_lr = lr * 0.5 * 0.5 * 0.5

        optimizer = optim.Adam(model.parameters(), lr=op_lr)


        dt_size = len(train_dataloader.dataset)
        train_epoch_loss_t1 = 0
        train_epoch_dice_t1 = 0
        step = 0


        model.train()
        for x_t1, x_fa, y in train_dataloader:
            step += 1
            inputs_t1 = x_t1.to(device)  # [batch_size, 9, 144, 144]->model(9,2)-> output:[batch_size, 2, 144, 144]

            groundtruth = y.to(device)
            # 梯度清零
            optimizer.zero_grad()

            outputs_t1 = model(inputs_t1)  # tensor[batch_size, 2, 144, 144]

            label_t1_predict = outputs_t1[:, 1, :, :].squeeze()  # label预测值      tensor[batch_size, 1, 144, 144]


            label_truth = groundtruth.squeeze()  # label真实值      tensor[batch_size, 1, 144, 144]

            loss_t1 = losses(label_t1_predict, label_truth)

            label_t1_dice = dice(label_t1_predict, label_truth)


            # 反向传播
            loss_t1.backward()

            # 梯度更新
            optimizer.step()


            train_epoch_loss_t1 += float(loss_t1.item())
            train_epoch_dice_t1 += float(label_t1_dice.item())
            step_loss_t1 = loss_t1.item()

            if step % 10 == 0:
                with open(r'loss_128/'  + str(batch_size) + 'batch_step_loss_4_t1.txt', 'a+') as f:
                    f.writelines('step{0}\t{1} \n'.format(str(step), str(step_loss_t1)))


            print("epoch:%d/%d, %d/%d, loss_t1:%0.3f, label_t1_dice:%0.3f, op_lr:%f" % (epoch + 1,
                                                                               n_epochs,
                                                                               step * train_dataloader.batch_size,
                                                                               dt_size,
                                                                               loss_t1.item(),
                                                                               label_t1_dice.item(),
                                                                               op_lr
                                                                                ))

        model_path = 'outputs_128_t1/' + '%depoch_%dbatch.pth' % (epoch + 1, batch_size)
        torch.save(model.state_dict(), model_path)


        train_epoch_loss_t1 = train_epoch_loss_t1 / step
        train_epoch_dice_t1 = train_epoch_dice_t1 / step

        step_val = 0
        val_epoch_loss_t1 = 0
        val_dt_size = len(val_dataloader.dataset)


        model.load_state_dict(torch.load(model_path, map_location='cpu'))
        model.eval()
        with torch.no_grad():
            for x1, x2, y in val_dataloader:
                step_val += 1
                inputs1 = x1.to(device)  # [batch_size, 9, 144, 144]->model(9,2)-> output:[batch_size, 2, 144, 144]
                y_truth = y.to(device)

                outputs1 = model(inputs1)

                val_t1_pred = torch.max(outputs1, 1)[1].squeeze().float()  # troch.max()[1]，只返回最大值的每个索引

                val_loss_t1 = 1 - dice(val_t1_pred, y_truth)

                val_epoch_loss_t1 += float(val_loss_t1.item())
                print("epoch:%s, %d/%d, loss_128_t1:%0.3f" % (epoch+1,
                                                            step_val * val_dataloader.batch_size,
                                                            val_dt_size,
                                                            val_loss_t1.item()))

            val_epoch_loss_t1 = val_epoch_loss_t1 / step_val



            with open(r'loss_128/'  + str(batch_size) + 'batch_epoch_loss_4_t1.txt', 'a+') as f:
                f.writelines('epoch{0}\t{1}\t{2} \n'.format(str(epoch + 1), str(train_epoch_loss_t1), str(val_epoch_loss_t1)))


            print("epoch:%d, train_loss_t1:%0.3f, train_label_t1_dice:%0.3f, val_loss_t1:%0.3f" % (epoch + 1,
                                                                                train_epoch_loss_t1,
                                                                                train_epoch_dice_t1,
                                                                                val_epoch_loss_t1))


            if val_epoch_loss_t1 > last_val_epoch_loss:
                loss_nodecrease_num +=1
                if loss_nodecrease_num > 10 :
                    return
            else :
                loss_nodecrease_num = 0

            last_val_epoch_loss = val_epoch_loss_t1


        print('-' * 30)



if __name__ == '__main__':

    x_transforms = transforms.Compose([
        transforms.ToPILImage(),
        transforms.RandomHorizontalFlip(0.5),
        transforms.ColorJitter(brightness=0.5, contrast=0.5, hue=0.5),
        transforms.ToTensor(),
        transforms.Normalize((0.5,), (0.5,))
    ])

    y_transforms = transforms.Compose([
        transforms.ToTensor()
    ])

    # 模型保存
    if 'outputs_128_t1' not in os.listdir(os.curdir):
        os.mkdir('outputs_128_t1')

    # loss保存
    if 'loss_128' not in os.listdir(os.curdir):
        os.mkdir('loss_128')

    ### train test ###
    start_time = time.time()
    train()
    end_time = time.time()
    print("2D train time is {:.3f} mins".format((end_time - start_time) / 60.0))
    print('-' * 30)
    print('patch size   : ', patch_size_w,'x',patch_size_h)
    print('batch size   : ', batch_size)
    print('  epoch      : ', n_epochs)
    print('learning rate: ', lr)
    print('-' * 30)
    print("done")




