import os
import config_2d
from NetModel import Unet_2d, Unet_plus_2d, MultiResUnet_2d, MultiResUnet_plus_2d, Newnet
import time
from torch import optim
from torch.utils.data import DataLoader
from traindataset_2d import MyTrainDataset
from torchvision.transforms import transforms
from metrics_2d import dice_loss, dice
import torch
import torch.nn as nn
import math

# os.environ['CUDA_VISIBLE_DEVICES']='0'

unet2d = Unet_2d.UNet2D  # U-Net
unetplus2d = Unet_plus_2d.UNetPlus2D  # U-Net++
multiresunet2d = MultiResUnet_2d.MultiResUnet2D  # MultiRes U-Net
ournet2d = MultiResUnet_plus_2d.MultiResUnetPlus2D  # MultiRes U-Net++
fusionnet = Newnet.DatafusionNet

patch_size_w = config_2d.PATCH_SIZE_W
patch_size_h = config_2d.PATCH_SIZE_H
batch_size = config_2d.BATCH_SIZE
n_epochs = config_2d.NUM_EPOCHS
n_classes = config_2d.NUM_CLASSES
image_rows = config_2d.VOLUME_ROWS
image_cols = config_2d.VOLUME_COLS
image_depth = config_2d.VOLUME_DEPS
test_imgs_path = config_2d.test_imgs_path

flag_gpu = config_2d.FLAG_GPU

# 是否使用cuda
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def conv3x3(input_channel, output_channel):
    return nn.Sequential(nn.Conv2d(input_channel, output_channel, kernel_size=3, stride=1, padding=1),
                         nn.BatchNorm2d(output_channel),
                         nn.ReLU(inplace=True))


def UNet_up_conv_bn_relu(input_channel, output_channel, learned_bilinear=False):
    if learned_bilinear:
        return nn.Sequential(nn.ConvTranspose2d(input_channel, output_channel, kernel_size=2, stride=2),
                             nn.BatchNorm2d(output_channel),
                             nn.ReLU())
    else:
        return nn.Sequential(nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
                             nn.Conv2d(input_channel, output_channel, kernel_size=3, padding=1),
                             nn.BatchNorm2d(output_channel),
                             nn.ReLU())


class basic_block(nn.Module):
    def __init__(self, input_channel, output_channel):
        super(basic_block, self).__init__()
        self.conv1 = nn.Conv2d(input_channel, output_channel, 3, padding=1)
        self.bn1 = nn.BatchNorm2d(output_channel)
        self.conv2 = nn.Conv2d(output_channel, output_channel, 3, padding=1)
        self.bn2 = nn.BatchNorm2d(output_channel)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.relu(self.bn1(self.conv1(x)))
        x = self.relu(self.bn2(self.conv2(x)))
        return x


class Channel_Attention(nn.Module):
    def __init__(self, channel, reduction):
        super(Channel_Attention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        y = x * y
        return y


class Feature_refine_block(nn.Module):
    def __init__(self, in_channel, dilation):
        super(Feature_refine_block, self).__init__()
        self.conv1 = nn.Conv2d(in_channel, in_channel, 3, padding=dilation, dilation=dilation)
        self.bn1 = nn.BatchNorm2d(in_channel)
        self.conv2 = nn.Conv2d(in_channel, in_channel, 3, padding=dilation, dilation=dilation)
        self.bn2 = nn.BatchNorm2d(in_channel)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        y = self.relu(self.bn1(self.conv1(x)))
        y = self.bn2(self.conv2(y))
        y = y + x
        y = self.relu(y)
        return y


class Spatial_Attention(nn.Module):
    def __init__(self, input_channel, reduction, dilation=4):
        super(Spatial_Attention, self).__init__()

        self.conv1 = nn.Conv2d(input_channel, input_channel // reduction, kernel_size=1, stride=1, padding=0)
        self.conv2 = nn.Conv2d(input_channel // reduction, input_channel // reduction, kernel_size=3, dilation=4,
                               stride=1, padding=4)
        self.conv3 = nn.Conv2d(input_channel // reduction, input_channel // reduction, kernel_size=3, dilation=4,
                               stride=1, padding=4)
        self.conv4 = nn.Conv2d(input_channel // reduction, 1, kernel_size=1, stride=1, padding=0)
        self.bn = nn.BatchNorm2d(1)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        y = self.conv1(x)
        y = self.conv2(y)
        y = self.conv3(y)
        y = self.bn(self.conv4(y))
        y = self.sigmoid(y)

        return y


class Bottleneck_Attention_Module(nn.Module):
    def __init__(self, input_channel, reduction=16, dilation=4):
        super(Bottleneck_Attention_Module, self).__init__()

        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(input_channel, input_channel // reduction),
            nn.ReLU(inplace=True),
            nn.Linear(input_channel // reduction, input_channel),
            nn.Sigmoid()
        )

        self.conv1 = nn.Conv2d(input_channel, input_channel // reduction, kernel_size=1, stride=1, padding=0)
        self.conv2 = nn.Conv2d(input_channel // reduction, input_channel // reduction, kernel_size=3, dilation=dilation,
                               stride=1, padding=dilation)
        self.conv3 = nn.Conv2d(input_channel // reduction, input_channel // reduction, kernel_size=3, dilation=dilation,
                               stride=1, padding=dilation)
        self.conv4 = nn.Conv2d(input_channel // reduction, 1, kernel_size=1, stride=1, padding=0)
        self.bn = nn.BatchNorm2d(1)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        b, c, _, _ = x.size()
        y1 = self.avg_pool(x).view(b, c)
        y1 = self.fc(y1).view(b, c, 1, 1)
        ca_weights = torch.ones(x.size()).cuda() * y1

        y2 = self.conv1(x)
        y2 = self.conv2(y2)
        y2 = self.conv3(y2)
        y2 = self.bn(self.conv4(y2))

        sa_weights = y2.repeat(1, x.size()[1], 1, 1)

        y = self.sigmoid(ca_weights + sa_weights)

        return y


class UNet_basic_down_block(nn.Module):
    def __init__(self, input_channel, output_channel):
        super(UNet_basic_down_block, self).__init__()
        self.block = basic_block(input_channel, output_channel)

    def forward(self, x):
        x = self.block(x)
        return x


class UNet_basic_up_block(nn.Module):
    def __init__(self, input_channel, prev_channel, output_channel, dilation, learned_bilinear=False):
        super(UNet_basic_up_block, self).__init__()
        self.bilinear_up = UNet_up_conv_bn_relu(input_channel, prev_channel, learned_bilinear)
        self.block = basic_block(prev_channel * 2, output_channel)
        self.feature = Feature_refine_block(prev_channel, dilation)

    def forward(self, pre_feature_map, x):
        x = self.bilinear_up(x)
        pre_feature_map = self.feature(pre_feature_map)
        x = torch.cat((x, pre_feature_map), dim=1)
        x = self.block(x)
        return x


class UNet_ca_up_block(nn.Module):
    def __init__(self, input_channel, prev_channel, output_channel, learned_bilinear=False):
        super(UNet_ca_up_block, self).__init__()
        self.bilinear_up = UNet_up_conv_bn_relu(input_channel, prev_channel, learned_bilinear)
        self.block = basic_block(prev_channel * 2, output_channel)
        self.ca = Channel_Attention(prev_channel * 2, reduction=16)

    def forward(self, pre_feature_map, x):
        x = self.bilinear_up(x)
        x = torch.cat((x, pre_feature_map), dim=1)
        x = self.ca(x) * x
        x = self.block(x)
        return x


class UNet_resca_up_block(nn.Module):
    def __init__(self, input_channel, prev_channel, output_channel, learned_bilinear=False):
        super(UNet_resca_up_block, self).__init__()
        self.bilinear_up = UNet_up_conv_bn_relu(input_channel, prev_channel, learned_bilinear)
        self.block = basic_block(prev_channel * 2, output_channel)
        self.ca = Channel_Attention(prev_channel * 2, reduction=16)

    def forward(self, pre_feature_map, x):
        x = self.bilinear_up(x)
        x = torch.cat((x, pre_feature_map), dim=1)
        x = self.ca(x) * x + x
        x = self.block(x)
        return x


'''class t1safaFuseUNet1(nn.Module):
    def __init__(self, num_classes=2, pretrain=False, reduction=16, dilation=4, learned_bilinear=False):
        super(t1safaFuseUNet1, self).__init__()

        ################# peaks encoder #################

        self.down_block1_peaks = UNet_basic_down_block(1, 32)
        self.sa1_peaks = Spatial_Attention(input_channel=32, reduction=reduction, dilation=dilation)
        self.max_pool1_peaks = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block2_peaks = UNet_basic_down_block(32, 64)
        self.sa2_peaks = Spatial_Attention(input_channel=64, reduction=reduction, dilation=dilation)
        self.max_pool2_peaks = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block3_peaks = UNet_basic_down_block(64, 128)
        self.sa3_peaks = Spatial_Attention(input_channel=128, reduction=reduction, dilation=dilation)
        self.max_pool3_peaks = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block4_peaks = UNet_basic_down_block(128, 256)
        self.sa4_peaks = Spatial_Attention(input_channel=256, reduction=reduction, dilation=dilation)
        self.max_pool4_peaks = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block5_peaks = UNet_basic_down_block(256, 512)
        self.sa5_peaks = Spatial_Attention(input_channel=512, reduction=reduction, dilation=dilation)

        ################# t1 encoder #################

        self.down_block1_t1 = UNet_basic_down_block(1, 32)
        self.max_pool1_t1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block2_t1 = UNet_basic_down_block(64, 64)
        self.max_pool2_t1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block3_t1 = UNet_basic_down_block(128, 128)
        self.max_pool3_t1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block4_t1 = UNet_basic_down_block(256, 256)
        self.max_pool4_t1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block5_t1 = UNet_basic_down_block(512, 512)

        ################# DCE decoder #################

        self.up_block1 = UNet_basic_up_block(1024, 512, 512, 4, learned_bilinear)
        self.up_block2 = UNet_basic_up_block(512, 256, 256, 3, learned_bilinear)
        self.up_block3 = UNet_basic_up_block(256, 128, 128, 2, learned_bilinear)
        self.up_block4 = UNet_basic_up_block(128, 64, 64, 1, learned_bilinear)

        self.last_conv1 = nn.Conv2d(64, 2, 1, padding=0)

    def forward(self, t1_inputs, peaks_inputs):
        x_1 = self.down_block1_peaks(peaks_inputs)
        y = self.down_block1_t1(t1_inputs)
        y1_peaks = self.sa1_peaks(y)
        x1_t1 = y1_peaks * x_1

        x = self.max_pool1_peaks(x1_t1)
        y_1 = torch.cat((y * y1_peaks, x1_t1), dim=1)
        y = self.max_pool1_t1(y_1)

        x_2 = self.down_block2_peaks(x)
        y = self.down_block2_t1(y)
        y2_peaks = self.sa2_peaks(y)
        x2_t1 = y2_peaks * x_2

        x = self.max_pool2_peaks(x2_t1)
        y_2 = torch.cat((y * y2_peaks, x2_t1), dim=1)
        y = self.max_pool2_t1(y_2)

        x_3 = self.down_block3_peaks(x)
        y = self.down_block3_t1(y)
        y3_peaks = self.sa3_peaks(y)
        x3_t1 = y3_peaks * x_3

        x = self.max_pool3_peaks(x3_t1)
        y_3 = torch.cat((y * y3_peaks, x3_t1), dim=1)
        y = self.max_pool3_t1(y_3)

        x_4 = self.down_block4_peaks(x)
        y = self.down_block4_t1(y)
        y4_peaks = self.sa4_peaks(y)
        x4_t1 = y4_peaks * x_4

        x = self.max_pool4_peaks(x4_t1)
        y_4 = torch.cat((y * y4_peaks, x4_t1), dim=1)
        y = self.max_pool4_t1(y_4)

        x_5 = self.down_block5_peaks(x)
        y = self.down_block5_t1(y)
        y5_peaks = self.sa5_peaks(y)
        x5_t1 = x_5 * y5_peaks

        y = torch.cat((y * y5_peaks, x5_t1), dim=1)

        ################# DCE encoder #################

        y = self.up_block1(y_4, y)
        y = self.up_block2(y_3, y)
        y = self.up_block3(y_2, y)
        y = self.up_block4(y_1, y)

        final = self.last_conv1(y)

        out = torch.sigmoid(final)
        return out'''


class semantic_feature_fusion(nn.Module):
    def __init__(self, in_channel,out_channel):
        super(semantic_feature_fusion, self).__init__()
        self.ca = Channel_Attention(in_channel, reduction=4)
        self.sa = Spatial_Attention(in_channel, 4)
        self.fr = Feature_refine_block(in_channel, 1)
        self.conv = UNet_basic_down_block(2 * in_channel, in_channel)
        self.conv1 = UNet_basic_down_block(2 * in_channel, 2 * in_channel)
        self.sigmoid = nn.Sigmoid()
        self.bn = nn.BatchNorm2d(out_channel)

    def forward(self, ai, bi, ci):
        ca_ai = self.ca(ai)
        ca_bi = self.ca(bi)
        ca_ci = self.ca(ci)
        sa_ai = self.sa(ca_ai)
        fr_bi = self.fr(bi)
        fr_ci = self.fr(ci)
        conv1 = self.conv(torch.cat(((sa_ai * ca_bi), fr_bi), dim=1))
        conv2 = self.conv(torch.cat(((sa_ai * ca_ci), fr_ci), dim=1))
        conv3 = self.conv(torch.cat((conv1, conv2), dim=1))
        conv4 = self.bn(self.conv1(torch.cat((ai, conv3), dim=1)))

        out = self.sigmoid(conv4)
        return out


class deep_modalities_fusion4(nn.Module):
    def __init__(self):
        super(deep_modalities_fusion4, self).__init__()
        self.conv1 = UNet_up_conv_bn_relu(1024, 256)
        self.conv2 = UNet_up_conv_bn_relu(256, 64)
        self.conv3 = UNet_up_conv_bn_relu(64, 16)
        self.ca = Channel_Attention(48, reduction=4)
        self.sa = Spatial_Attention(48, 4)
        self.fr = Feature_refine_block(48, 1)
        self.conv4 = UNet_basic_down_block(96, 2)
        self.sigmoid = nn.Sigmoid()
        self.bn = nn.BatchNorm2d(2)

    def forward(self, abc4, bac4, cab4):
        x1 = self.conv1(abc4)
        y1 = self.conv1(bac4)
        z1 = self.conv1(cab4)
        x2 = self.conv2(x1)
        y2 = self.conv2(y1)
        z2 = self.conv2(z1)
        x3 = self.conv3(x2)
        y3 = self.conv3(y2)
        z3 = self.conv3(z2)
        a = torch.cat((x3, y3), dim=1)
        b = torch.cat((a, z3), dim=1)
        b_sa = self.sa(b)
        b_ca = self.ca(b)
        b_fr = self.fr(b)
        c = torch.cat((b_sa * b_ca, b_fr), dim=1)
        conv = self.bn(self.conv4(c))
        out = self.sigmoid(conv)
        return out


class deep_modalities_fusion3(nn.Module):
    def __init__(self):
        super(deep_modalities_fusion3, self).__init__()
        self.conv1 = UNet_up_conv_bn_relu(256, 64)
        self.conv2 = UNet_up_conv_bn_relu(64, 16)
        self.ca = Channel_Attention(48, reduction=4)
        self.sa = Spatial_Attention(48, 4)
        self.fr = Feature_refine_block(48, 1)
        self.conv3 = UNet_basic_down_block(96, 2)
        self.sigmoid = nn.Sigmoid()
        self.bn = nn.BatchNorm2d(2)

    def forward(self, abc3, bac3, cab3):
        x1 = self.conv1(abc3)
        y1 = self.conv1(bac3)
        z1 = self.conv1(cab3)
        x2 = self.conv2(x1)
        y2 = self.conv2(y1)
        z2 = self.conv2(z1)
        a = torch.cat((x2, y2), dim=1)
        b = torch.cat((a, z2), dim=1)
        b_sa = self.sa(b)
        b_ca = self.ca(b)
        b_fr = self.fr(b)
        c = torch.cat((b_sa * b_ca, b_fr), dim=1)
        conv = self.bn(self.conv3(c))

        out = self.sigmoid(conv)
        return out


class deep_modalities_fusion2(nn.Module):
    def __init__(self):
        super(deep_modalities_fusion2, self).__init__()
        self.conv1 = UNet_up_conv_bn_relu(64, 16)
        self.ca = Channel_Attention(48, reduction=4)
        self.sa = Spatial_Attention(48, 4)
        self.fr = Feature_refine_block(48, 1)
        self.conv2 = UNet_basic_down_block(96, 2)
        self.sigmoid = nn.Sigmoid()
        self.bn = nn.BatchNorm2d(2)

    def forward(self, abc2, bac2, cab2):
        x1 = self.conv1(abc2)
        y1 = self.conv1(bac2)
        z1 = self.conv1(cab2)
        a = torch.cat((x1, y1), dim=1)
        b = torch.cat((a, z1), dim=1)
        b_sa = self.sa(b)
        b_ca = self.ca(b)
        b_fr = self.fr(b)
        c = torch.cat((b_sa * b_ca, b_fr), dim=1)
        conv = self.bn(self.conv2(c))
        out = self.sigmoid(conv)
        return out


class deep_modalities_fusion1(nn.Module):
    def __init__(self, ):
        super(deep_modalities_fusion1, self).__init__()
        self.ca = Channel_Attention(48, reduction=4)
        self.sa = Spatial_Attention(48, 4)
        self.fr = Feature_refine_block(48, 1)
        self.conv2 = UNet_basic_down_block(96, 2)
        self.bn = nn.BatchNorm2d(2)
        self.sigmoid = nn.Sigmoid()

    def forward(self, abc1, bac1, cab1):
        x1 = abc1
        y1 = bac1
        z1 = cab1
        a = torch.cat((x1, y1), dim=1)
        b = torch.cat((a, z1), dim=1)
        b_sa = self.sa(b)
        b_ca = self.ca(b)
        b_fr = self.fr(b)
        c = torch.cat((b_sa * b_ca, b_fr), dim=1)
        conv = self.bn(self.conv2(c))
        out = self.sigmoid(conv)
        return out


class molti_modal_data_fusion(nn.Module):
    def __init__(self):
        super(molti_modal_data_fusion, self).__init__()
        self.conv1 = basic_block(8, 2)
        self.sigmoid = nn.Sigmoid()
        self.ca = Channel_Attention(2, reduction=2)
        self.sa = Spatial_Attention(2, 2)
        self.conv2 = basic_block(9, 2)
        self.conv3 = basic_block(4, 2)
        self.bn = nn.BatchNorm2d(2)
        self.last_conv1 = nn.Conv2d(8, 2, 1, padding=0)

    def forward(self, out1, out2, out3, out4):
        sa = self.sa(out1)
        ca2 = self.ca(out2)
        ca3 = self.ca(out3)
        ca4 = self.ca(out4)
        x1 = sa * ca2
        x2 = sa * ca3
        x3 = sa * ca4
        cat1 = torch.cat((out1, x1), dim=1)
        cat2 = torch.cat((cat1, x2), dim=1)
        cat3 = torch.cat((cat2, x3), dim=1)
        out = self.last_conv1(cat3)
        final = torch.sigmoid(out)
        return final
        # x1 = torch.cat((out1, out2), dim=1)
        # x2 = torch.cat((x1, out3), dim=1)
        # x3 = torch.cat((x2, out4), dim=1)
        # x4 = self.conv1(x3)
        # ca1 = self.ca(x4)
        # ca2 = self.ca(torch.cat((out3, out4), dim=1))
        # ca3 = self.ca(torch.cat((out1, out2), dim=1))
        # sa = self.sa(ca2)
        # cat1 = torch.cat((sa, sa * ca1), dim=1)
        # cat2 = torch.cat((cat1, sa * ca3), dim=1)
        # outa = self.conv2(cat2)
        # cat3 = torch.cat((outa, out1), dim=1)
        # outb = self.bn(self.conv3(cat3))
        # out = self.sigmoid(outb)
        # return out


class SDM_net(nn.Module):
    def __init__(self, learned_bilinear=False):
        super(SDM_net, self).__init__()
        self.conv1 = UNet_basic_down_block(1, 8)
        self.conv11 = UNet_basic_down_block(9, 8)
        self.conv2 = UNet_basic_down_block(16, 32)
        self.conv3 = UNet_basic_down_block(64, 128)
        self.conv4 = UNet_basic_down_block(256, 512)
        self.sff1 = semantic_feature_fusion(8, 16)
        self.sff2 = semantic_feature_fusion(32, 64)
        self.sff3 = semantic_feature_fusion(128, 256)
        self.sff4 = semantic_feature_fusion(512, 1024)
        self.dmf1 = deep_modalities_fusion1()
        self.dmf2 = deep_modalities_fusion2()
        self.dmf3 = deep_modalities_fusion3()
        self.dmf4 = deep_modalities_fusion4()
        self.mdf = molti_modal_data_fusion()
        self.max_pooling = nn.MaxPool2d(kernel_size=2, stride=2)
        self.UNet_up_conv_bn_relu = UNet_up_conv_bn_relu(2, 2, learned_bilinear)

    def forward(self, a, b, c):
        a1 = self.max_pooling(self.conv1(a))  # 8*64*80
        b1 = self.max_pooling(self.conv1(b))
        c1 = self.max_pooling(self.conv11(c))
        abc1 = self.sff1(a1, b1, c1)  # 16*64*80
        bac1 = self.sff1(b1, a1, c1)
        cab1 = self.sff1(c1, a1, b1)
        a2 = self.max_pooling(self.conv2(abc1))  # 32*32*40
        b2 = self.max_pooling(self.conv2(bac1))
        c2 = self.max_pooling(self.conv2(cab1))
        abc2 = self.sff2(a2, b2, c2)  # 64*32*40
        bac2 = self.sff2(b2, a2, c2)
        cab2 = self.sff2(c2, a2, b2)
        a3 = self.max_pooling(self.conv3(abc2))  # 128*16*20
        b3 = self.max_pooling(self.conv3(bac2))
        c3 = self.max_pooling(self.conv3(cab2))
        abc3 = self.sff3(a3, b3, c3)  # 256*16*20
        bac3 = self.sff3(b3, a3, c3)
        cab3 = self.sff3(c3, a3, b3)
        a4 = self.max_pooling(self.conv4(abc3))  # 512*8*10
        b4 = self.max_pooling(self.conv4(bac3))
        c4 = self.max_pooling(self.conv4(cab3))
        abc4 = self.sff4(a4, b4, c4)  # 1024*8*10
        bac4 = self.sff4(b4, a4, c4)
        cab4 = self.sff4(c4, a4, b4)
        out1 = self.UNet_up_conv_bn_relu(self.dmf1(abc1, bac1, cab1))  # 2*128*160
        out2 = self.UNet_up_conv_bn_relu(self.dmf2(abc2, bac2, cab2))  # 2*128*160
        out3 = self.UNet_up_conv_bn_relu(self.dmf3(abc3, bac3, cab3))  # 2*128*160
        out4 = self.UNet_up_conv_bn_relu(self.dmf4(abc4, bac4, cab4))  # 2*128*160
        out = self.mdf(out1, out2, out3, out4)
        return out


def train():
    global model

    op_lr = 0.001 #

    # 模型选择
    # sanet
    model = SDM_net().to(device)

    #### 训练集选择
    ON_train_x_t1_dir = 'ON_mydata/train_data/x_t1_data/'
    ON_train_x_fa_dir = 'ON_mydata/train_data/x_fa_data/'
    ON_train_x_peaks_dir = 'ON_mydata/train_data/x_peaks_data/'
    ON_train_y_dir = 'ON_mydata/train_data/y_data/'

    # 损失函数选择
    losses1 = dice_loss()
    losses2 = nn.BCEWithLogitsLoss()
    # 是否使用多块GPU
    if flag_gpu == 1:
        model = nn.DataParallel(model).cuda()

    train_dataset = MyTrainDataset(ON_train_x_t1_dir, ON_train_x_fa_dir, ON_train_x_peaks_dir, ON_train_y_dir,
                                   x_transform=x_transforms, z_transform=z_transforms, y_transform=y_transforms)
    train_dataloader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=0)

    ###----------------------
    #### start train
    print('-' * 30)
    print('Training start...')
    print('-' * 30)
    print('patch size   : ', patch_size_w, 'x', patch_size_h)
    print('batch size   : ', batch_size)
    print('  epoch      : ', n_epochs)
    print('learning rate: ', op_lr)
    print('-' * 30)

    # model.load_state_dict(torch.load(r"/home/AVP Seg/2D_FusionNet/outputs_sa_fr_diceBCE_t1fa/t1fa_98epoch_64batch.pth",map_location='cuda'))

    # optimizer = optim.Adam(model.parameters(), lr=op_lr)

    # t = 10  # warmup
    # T = 200  # 共有200个epoch，则用于cosine rate的一共有180个epoch
    # n_t = 0.5
    # lambda1 = lambda epoch: (0.9 * epoch / t + 0.1) if epoch < t else 0.1 if n_t * (
    #         1 + math.cos(math.pi * (epoch - t) / (T - t))) < 0.1 else n_t * (
    #         1 + math.cos(math.pi * (epoch - t) / (T - t)))
    # scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=lambda1)

    for epoch in range(0, 200):

        dt_size = len(train_dataloader.dataset)

        ## model
        epoch_loss_t1fapeaks = 0
        epoch_dice_t1fapeaks = 0
        loss_t1fa = 0

        step = 0

        optimizer = optim.Adam(model.parameters(), lr=op_lr)

        model.train()

        for x_t1, x_fa, x_peaks, y in train_dataloader:

            step += 1
            inputs_t1 = x_t1.to(device)  # [batch_size, 9, 144, 144]->model(9,2)-> output:[batch_size, 2, 144, 144]
            inputs_fa = x_fa.to(device)
            inputs_peaks = x_peaks.to(device)
            groundtruth = y.to(device)
            # 梯度清零
            optimizer.zero_grad()

            outputs_t1fapeaks = model(inputs_t1, inputs_fa, inputs_peaks)

            # z = outputs_t1peaks.shape

            label_t1fapeaks_predict = outputs_t1fapeaks[:, 1, :, :].squeeze()

            # t1 = label_peaks_predict.shape

            label_truth = groundtruth.squeeze()  # label真实值      tensor[batch_size, 1, 144, 144]
            # t2 = label_truth.shape
            loss1 = losses1(label_t1fapeaks_predict, label_truth)
            loss2 = losses2(label_t1fapeaks_predict, label_truth)
            loss_t1fapeaks = loss1 + loss2

            label_t1fapeaks_dice = dice(label_t1fapeaks_predict, label_truth)

            # 反向传播
            loss_t1fapeaks.backward()

            # 梯度更新
            optimizer.step()

            epoch_loss_t1fapeaks += float(loss_t1fapeaks.item())
            epoch_dice_t1fapeaks += float(label_t1fapeaks_dice.item())
            step_loss_t1fapeaks = loss_t1fapeaks.item()
            step_dice_t1fapeaks = label_t1fapeaks_dice.item()

            if step % 10 == 0:
                with open(r'loss/SDM_diceBCE_train_t1fapeaks_' + str(batch_size) + 'batch_step_loss.txt',
                          'a+') as f:
                    f.writelines('step{0}\t{1} \n'.format(str(step), str(step_loss_t1fapeaks)))

            print("epoch:%d/%d, %d/%d, loss_t1fapeaks:%0.3f, label_dice_t1fapeaks:%0.3f, op_lr:%0.5f" % (epoch + 1,
                                                                                                         n_epochs,
                                                                                                         step * train_dataloader.batch_size,
                                                                                                         dt_size,
                                                                                                         step_loss_t1fapeaks,
                                                                                                         step_dice_t1fapeaks,
                                                                                                         op_lr))
            # scheduler.step()
        model_path = 'outputs_SDM_diceBCE_t1fapeaks/' + 't1fapeaks_%depoch_%dbatch.pth' % (epoch + 1, batch_size)
        torch.save(model.state_dict(), model_path)

        train_epoch_loss_t1fapeaks = epoch_loss_t1fapeaks / step
        train_epoch_dice_t1fapeaks = epoch_dice_t1fapeaks / step

        with open(r'loss/SDM_diceBCE_val_t1fapeaks_' + str(batch_size) + 'batch_epoch_loss.txt', 'a+') as f:
            f.writelines(
                'epoch{0}\t{1}\t{2} \n'.format(str(epoch + 1), str(train_epoch_loss_t1fapeaks),
                                               str(train_epoch_dice_t1fapeaks)))

        print("epoch:%d, train_loss_t1fapeaks:%0.3f, train_dice_t1fapeaks:%0.3f" % (
            epoch + 1, train_epoch_loss_t1fapeaks, train_epoch_dice_t1fapeaks))

    print('-' * 30)


### 训练各自模型
if __name__ == '__main__':

    x_transforms = transforms.Compose([
        transforms.ToPILImage(),
        transforms.RandomHorizontalFlip(0.5),
        transforms.ColorJitter(brightness=0.5, contrast=0.5, hue=0.5),
        transforms.ToTensor(),
        transforms.Normalize((0.5,), (0.5,))
    ])
    z_transforms = transforms.ToTensor()
    y_transforms = transforms.Compose([
        transforms.ToTensor()
    ])

    # 模型保存
    if 'outputs_SDM_diceBCE_t1fapeaks' not in os.listdir(os.curdir):
        os.mkdir('outputs_SDM_diceBCE_t1fapeaks')

    # loss保存
    if 'loss' not in os.listdir(os.curdir):
        os.mkdir('loss')

    ### train test ###
    start_time = time.time()
    train()
    end_time = time.time()
    print("2D train time is {:.3f} mins".format((end_time - start_time) / 60.0))
    print('-' * 30)
    print('patch size   : ', patch_size_w, 'x', patch_size_h)
    print('batch size   : ', batch_size)
    print('  epoch      : ', n_epochs)
    print('-' * 30)
    print("done")

    x1 = torch.rand(1, 1, 128, 160).to(device)
    x2 = torch.rand(1, 1, 128, 160).to(device)
    x3 = torch.rand(1, 9, 128, 160).to(device)
    model = SDM_net().to(device)
    y = model(x1, x2, x3)
    print(y.shape)
