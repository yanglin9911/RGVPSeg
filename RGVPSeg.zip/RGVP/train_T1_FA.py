  # import visdom
import config_2d
from NetModel import Unet_2d, Unet_plus_2d, MultiResUnet_2d, MultiResUnet_plus_2d
import torch, time
from torch import nn, optim
from torch.utils.data import DataLoader
from traindataset_2d import MyTrainDataset
from torchvision.transforms import transforms
from metrics_2d import dice_loss, dice
import os

unet2d = Unet_2d.UNet2D  # U-Net
unetplus2d = Unet_plus_2d.UNetPlus2D  # U-Net++
multiresunet2d = MultiResUnet_2d.MultiResUnet2D  # MultiRes U-Net
ournet2d = MultiResUnet_plus_2d.MultiResUnetPlus2D  # MultiRes U-Net++

patch_size_w = config_2d.PATCH_SIZE_W
patch_size_h = config_2d.PATCH_SIZE_H
batch_size = config_2d.BATCH_SIZE
n_epochs = config_2d.NUM_EPOCHS
n_classes = config_2d.NUM_CLASSES
image_rows = config_2d.VOLUME_ROWS
image_cols = config_2d.VOLUME_COLS
image_depth = config_2d.VOLUME_DEPS
test_imgs_path = config_2d.test_imgs_path

flag_gpu = config_2d.FLAG_GPU

# 是否使用cuda
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# train
def train():
    global model1, model2, model3

    lr = 0.002  #
    op_lr = 0.0004  #

    # 模型选择
    # 2D U-Net
    model1 = unet2d(1, 2).to(device)
    model2 = unet2d(1, 2).to(device)
    # model3 = unet2d(9, 2).to(device)

    #### 训练集选择
    ON_train_x_t1_dir = 'ON_mydata/train_data1/x_t1_data/'
    ON_train_x_fa_dir = 'ON_mydata/train_data1/x_fa_data/'
    ON_train_x_peaks_dir = 'ON_mydata/train_data1/x_peaks_data/'
    ON_train_y_dir = 'ON_mydata/train_data1/y_data/'

    ### 验证集选择
    # ON_val_x_t1_dir = 'ON_mydata/val_data/x_t1_data/'
    # ON_val_x_fa_dir = 'ON_mydata/val_data/x_fa_data/'
    # ON_val_y_dir    = 'ON_mydata/val_data/y_data/'

    # 损失函数选择
    losses1 = dice_loss()
    losses2 = torch.nn.CrossEntropyLoss()

    # 是否使用多块GPU
    if flag_gpu == 1:
        model1 = nn.DataParallel(model1).cuda()
        # model2 = nn.DataParallel(model2).cuda()
        # model3 = nn.DataParallel(model3).cuda()

    train_dataset = MyTrainDataset(ON_train_x_t1_dir, ON_train_x_fa_dir, ON_train_x_peaks_dir, ON_train_y_dir,
                                   x_transform=x_transforms, z_transform=z_transforms, y_transform=y_transforms)
    train_dataloader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=0)

    # val_dataset = MyTrainDataset(ON_val_x_t1_dir, ON_val_x_fa_dir, ON_val_y_dir, x_transform=x_transforms, y_transform=y_transforms)
    # val_dataloader = DataLoader(val_dataset, batch_size=batch_size, shuffle=True, num_workers=0)

    ###----------------------
    #### start train
    print('-' * 30)
    print('Training start...')
    print('-' * 30)
    print('patch size   : ', patch_size_w, 'x', patch_size_h)
    print('batch size   : ', batch_size)
    print('  epoch      : ', n_epochs)
    print('learning rate: ', op_lr)
    print('-' * 30)

    # model1.load_state_dict(torch.load(r"/home/AVP Seg/2D_FusionNet/outputs_t1/t1_98epoch_256batch.pth", map_location='cuda'))
    # model2.load_state_dict(torch.load(r"outputs_fa/fa_20epoch_64batch.pth", map_location='cuda'))
    # model3.load_state_dict(torch.load(r"outputs_peaks/peaks_20epoch_64batch.pth", map_location='cuda'))

    for epoch in range(0, 100):

        # if (epoch+1) > 20:
        #     op_lr = lr * 0.5
        #
        # if (epoch+1) > 100:
        #     op_lr = lr * 0.5 * 0.5
        #
        # if (epoch+1) > 150:
        #     op_lr = lr * 0.5 * 0.5 * 0.5

        dt_size = len(train_dataloader.dataset)

        ## model1
        epoch_loss_t1 = 0
        epoch_dice_t1 = 0
        loss_t1 = 0

        ## model2
        epoch_loss_fa = 0
        epoch_dice_fa = 0
        loss_fa = 0

        ## model3
        # epoch_loss_peaks = 0
        # epoch_dice_peaks = 0
        # loss_peaks = 0

        step = 0

        optimizer1 = optim.Adam(model1.parameters(), lr=op_lr)
        # optimizer2 = optim.Adam(model2.parameters(), lr=op_lr)
        # optimizer3 = optim.Adam(model3.parameters(), lr=op_lr)

        model1.train()
        # model2.train()
        # model3.train()

        for x_t1, x_fa, x_peaks, y in train_dataloader:

            step += 1
            inputs_t1 = x_t1.to(device)  # [batch_size, 9, 144, 144]->model(9,2)-> output:[batch_size, 2, 144, 144]
            # inputs_fa = x_fa.to(device)
            # inputs_peaks = x_peaks.to(device)
            groundtruth = y.to(device)
            # 梯度清零
            optimizer1.zero_grad()
            # optimizer2.zero_grad()
            # optimizer3.zero_grad()

            outputs_t1 = model1(inputs_t1)  # tensor[batch_size, 2, 144, 144]
            # outputs_fa = model2(inputs_fa)
            # outputs_peaks = model3(inputs_peaks)

            label_t1_predict = outputs_t1[:, 1, :, :].squeeze()  # label预测值      tensor[batch_size, 1, 144, 144]
            # label_fa_predict = outputs_fa[:, 1, :, :].squeeze()
            # label_peaks_predict = outputs_peaks[:, 1, :, :].squeeze()

            label_truth = groundtruth.squeeze()  # label真实值      tensor[batch_size, 1, 144, 144]

            loss_t1 = losses1(label_t1_predict, label_truth)+losses2(label_t1_predict, label_truth)
            # loss_fa = losses(label_fa_predict, label_truth)
            # loss_peaks = losses(label_peaks_predict, label_truth)

            label_t1_dice = dice(label_t1_predict, label_truth)
            # label_fa_dice = dice(label_fa_predict, label_truth)
            # label_peaks_dice = dice(label_peaks_predict, label_truth)

            # 反向传播
            loss_t1.backward()
            # loss_fa.backward()
            # loss_peaks.backward()

            # 梯度更新
            optimizer1.step()
            # optimizer2.step()
            # optimizer3.step()

            epoch_loss_t1 += float(loss_t1.item())
            epoch_dice_t1 += float(label_t1_dice.item())
            step_loss_t1 = loss_t1.item()
            step_dice_t1 = label_t1_dice.item()

            # epoch_loss_fa += float(loss_fa.item())
            # epoch_dice_fa += float(label_fa_dice.item())
            # step_loss_fa = loss_fa.item()
            # step_dice_fa = label_fa_dice.item()

            # epoch_loss_peaks += float(loss_peaks.item())
            # epoch_dice_peaks += float(label_peaks_dice.item())
            # step_loss_peaks = loss_peaks.item()
            # step_dice_peaks = label_peaks_dice.item()

            if step % 10 == 0:
                with open(r'loss/2DUnet_train_t1_' + str(batch_size) + 'batch_step_loss.txt', 'a+') as f:
                    f.writelines('step{0}\t{1} \n'.format(str(step), str(step_loss_t1)))

                # with open(r'loss/2DUnet_train_fa_' + str(batch_size) + 'batch_step_loss.txt', 'a+') as f:
                #     f.writelines('step{0}\t{1} \n'.format(str(step), str(step_loss_fa)))

                # with open(r'loss/2DUnet_train_peaks_' + str(batch_size) + 'batch_step_loss.txt', 'a+') as f:
                #     f.writelines('step{0}\t{1} \n'.format(str(step), str(step_loss_peaks)))

            print("epoch:%d/%d, %d/%d, loss_t1:%0.3f, label_dice_t1:%0.3f, op_lr:%0.5f" % (epoch + 1,
                                                                                           n_epochs,
                                                                                           step * train_dataloader.batch_size,
                                                                                           dt_size,
                                                                                           step_loss_t1,
                                                                                           step_dice_t1,
                                                                                           op_lr))
            # print("epoch:%d/%d, %d/%d, loss_fa:%0.3f, label_dice_fa:%0.3f, op_lr:%0.5f" % (epoch + 1,
            #                                                                                n_epochs,
            #                                                                                step * train_dataloader.batch_size,
            #                                                                                dt_size,
            #                                                                                step_loss_fa,
            #                                                                                step_dice_fa,
            #                                                                                op_lr))
            # print("epoch:%d/%d, %d/%d, loss_peaks:%0.3f, label_dice_peaks:%0.3f, op_lr:%0.5f" % (epoch + 1,
            #                                                                                n_epochs,
            #                                                                                step * train_dataloader.batch_size,
            #                                                                                dt_size,
            #                                                                                step_loss_peaks,
            #                                                                                step_dice_peaks,
            #                                                                                op_lr))

        model1_path = 'outputs1_t1/' + 't1_%depoch_%dbatch.pth' % (epoch + 1, batch_size)
        # model2_path = 'outputs1_fa/' + 'fa_%depoch_%dbatch.pth' % (epoch + 1, batch_size)
        # model3_path = 'outputs1_peaks/' + 'peaks_%depoch_%dbatch.pth' % (epoch + 1, batch_size)
        torch.save(model1.state_dict(), model1_path)
        # torch.save(model2.state_dict(), model2_path)
        # torch.save(model3.state_dict(), model3_path)

        train_epoch_loss_t1 = epoch_loss_t1 / step
        train_epoch_dice_t1 = epoch_dice_t1 / step

        # train_epoch_loss_fa = epoch_loss_fa / step
        # train_epoch_dice_fa = epoch_dice_fa / step

        # train_epoch_loss_peaks = epoch_loss_peaks / step
        # train_epoch_dice_peaks = epoch_dice_peaks / step

        # step_val = 0
        #
        # val_epoch_loss_t1 = 0
        # val_epoch_loss_fa = 0
        # val_dt_size = len(val_dataloader.dataset)
        #
        # model1.load_state_dict(torch.load(model1_path, map_location='cpu'))
        # model2.load_state_dict(torch.load(model2_path, map_location='cpu'))
        #
        # model1.eval()
        # model2.eval()
        #
        # with torch.no_grad():
        #     for x1, x2, y in val_dataloader:
        #         step_val += 1
        #         inputs1_t1 = x1.to(device)
        #         inputs1_fa = x2.to(device)
        #         y_truth = y.to(device)
        #
        #         outputs1_t1 = model1(inputs1_t1)
        #         outputs1_fa = model2(inputs1_fa)
        #
        #         val_t1_pred = torch.max(outputs1_t1, 1)[1].squeeze().float()
        #         val_fa_pred = torch.max(outputs1_fa, 1)[1].squeeze().float()
        #
        #         val_loss_t1 = 1 - dice(val_t1_pred, y_truth)
        #         val_loss_fa = 1 - dice(val_fa_pred, y_truth)
        #
        #         val_epoch_loss_t1 += float(val_loss_t1.item())
        #         val_epoch_loss_fa += float(val_loss_fa.item())
        #
        #         print("epoch:%s, %d/%d, val_loss_t1:%0.3f, val_loss_fa:%0.3f" % (epoch + 1,
        #                                                                          step_val * val_dataloader.batch_size,
        #                                                                          val_dt_size,
        #                                                                          val_loss_t1.item(),
        #                                                                          val_loss_fa.item()))
        #
        #     val_epoch_loss_t1 = val_epoch_loss_t1 / step_val
        #     val_epoch_loss_fa = val_epoch_loss_fa / step_val

        with open(r'loss/2DUnet_val_t1_' + str(batch_size) + 'batch_epoch_loss.txt', 'a+') as f:
            f.writelines(
                'epoch{0}\t{1} \n'.format(str(epoch + 1), str(train_epoch_loss_t1)))

        # with open(r'loss/2DUnet_val_fa_' + str(batch_size) + 'batch_epoch_loss.txt', 'a+') as f:
        #     f.writelines(
        #         'epoch{0}\t{1} \n'.format(str(epoch + 1), str(train_epoch_loss_fa)))

        # with open(r'loss/2DUnet_val_peaks_' + str(batch_size) + 'batch_epoch_loss.txt', 'a+') as f:
        #     f.writelines(
        #         'epoch{0}\t{1} \n'.format(str(epoch + 1), str(train_epoch_loss_peaks)))

        print("epoch:%d, train_loss_t1:%0.3f, train_dice_t1:%0.3f" % (epoch + 1, train_epoch_loss_t1, train_epoch_dice_t1))
        # print("epoch:%d, train_loss_fa:%0.3f, train_dice_fa:%0.3f" % (epoch + 1, train_epoch_loss_fa, train_epoch_dice_fa))
        # print("epoch:%d, train_loss_peaks:%0.3f, train_dice_peaks:%0.3f" % (epoch + 1, train_epoch_loss_peaks, train_epoch_dice_peaks))


    print('-' * 30)


### 训练各自模型
if __name__ == '__main__':

    x_transforms = transforms.Compose([
        transforms.ToPILImage(),
        transforms.RandomHorizontalFlip(0.5),
        transforms.ColorJitter(brightness=0.5, contrast=0.5, hue=0.5),
        transforms.ToTensor(),
        transforms.Normalize((0.5,), (0.5,))
    ])
    z_transforms = transforms.ToTensor()
    y_transforms = transforms.Compose([
        transforms.ToTensor()
    ])

    # 模型保存
    if 'outputs1_t1' not in os.listdir(os.curdir):
        os.mkdir('outputs1_t1')
    if 'outputs1_fa' not in os.listdir(os.curdir):
        os.mkdir('outputs1_fa')
    if 'outputs1_peaks' not in os.listdir(os.curdir):
        os.mkdir('outputs1_peaks')

    # loss保存
    if 'loss' not in os.listdir(os.curdir):
        os.mkdir('loss')

    ### train test ###
    start_time = time.time()
    train()
    end_time = time.time()
    print("2D train time is {:.3f} mins".format((end_time - start_time) / 60.0))
    print('-' * 30)
    print('patch size   : ', patch_size_w, 'x', patch_size_h)
    print('batch size   : ', batch_size)
    print('  epoch      : ', n_epochs)
    print('-' * 30)
    print("done")
