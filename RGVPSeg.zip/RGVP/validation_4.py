import config_2d
from NetModel import Unet_2d, Unet_plus_2d, MultiResUnet_2d, MultiResUnet_plus_2d,Newnet,Unet_4
import torch
from torch import nn
from torch.utils.data import DataLoader
from traindataset_2d import MyTrainDataset
import os
from torchvision.transforms import transforms
from metrics_2d import dice
import numpy as np
import nibabel as nib


unet2d = Unet_2d.UNet2D                             # U-Net
unet2d_4 = Unet_4.UNet2D_4
unetplus2d = Unet_plus_2d.UNetPlus2D                # U-Net++
multiresunet2d = MultiResUnet_2d.MultiResUnet2D     # MultiRes U-Net
ournet2d = MultiResUnet_plus_2d.MultiResUnetPlus2D  # MultiRes U-Net++
newnet = Newnet.Newnet2D
fusionnet=Newnet.DatafusionNet

patch_size_w = config_2d.PATCH_SIZE_W
patch_size_h = config_2d.PATCH_SIZE_H
flag_gpu = config_2d.FLAG_GPU


batch_size = config_2d.BATCH_SIZE
n_epochs = config_2d.NUM_EPOCHS
n_classes = config_2d.NUM_CLASSES
image_rows = config_2d.VOLUME_ROWS
image_cols = config_2d.VOLUME_COLS
image_depth = config_2d.VOLUME_DEPS
test_imgs_path = config_2d.test_imgs_path
test_extraction_step = config_2d.TEST_EXTRACTION_STEP
# 是否使用cuda
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

if __name__ == '__main__':

    global val_dataset, model1,  model2, model3
    x_transforms = transforms.Compose([
        transforms.ToPILImage(),
        transforms.ToTensor(),
        transforms.Normalize((0.5,), (0.5,))
    ])
    y_transforms = transforms.Compose([
        transforms.ToTensor()
    ])

    # 验证集选择
    ON_val_x_t1_dir = 'ON_mydata/val_data/x_t1_data/'
    ON_val_x_fa_dir = 'ON_mydata/val_data/x_fa_data/'
    ON_val_y_dir = 'ON_mydata/val_data/y_data/'


    model1 = unet2d_4(1,2).to(device)


    # 是否使用多块GPU
    if flag_gpu == 1:
        model1 = nn.DataParallel(model1).cuda()


    val_dataset = MyTrainDataset(ON_val_x_t1_dir,ON_val_x_fa_dir, ON_val_y_dir, x_transform=x_transforms, y_transform=y_transforms)
    val_dataloader = DataLoader(val_dataset, batch_size=batch_size, shuffle=True, num_workers=0)


    model_t1_dir = os.listdir('outputs_4_t1/')

    epoch = []


    ########### T1
    for model_name in model_t1_dir:
        model_t1_name = model_name.split('.')[0]
        model_t1_path = 'outputs_4_t1/' + model_t1_name + '.pth'
        print('model_t1_path=', model_t1_path)

        batch_num = 'epoch_' + str(batch_size) + 'batch.pth'  # 'epoch_64batch'
        epoch = model_t1_name.replace(batch_num, '')

        # 模型选择
        model1.load_state_dict(torch.load(model_t1_path, map_location='cpu'))
        model1.eval()

        step = 0
        val_epoch_loss_t1 = 0
        val_all_loss_t1 = 0
        dt_size = len(val_dataloader.dataset)

        with torch.no_grad():
            for x1, x2, y in val_dataloader:
                step += 1
                inputs1 = x1.to(device)  # [batch_size, 9, 144, 144]->model(9,2)-> output:[batch_size, 2, 144, 144]
                y_truth = y.to(device)

                outputs1 = model1(inputs1)

                val_t1_pred = torch.max(outputs1, 1)[1].squeeze().float()  # troch.max()[1]，只返回最大值的每个索引

                val_loss_t1 = 1 - dice(val_t1_pred, y_truth)

                val_all_loss_t1 += float(val_loss_t1.item())
                print("epoch:%s, %d/%d, loss_4_t1:%0.3f" % (epoch,
                                                       step * val_dataloader.batch_size,
                                                       dt_size,
                                                       val_loss_t1.item()))

            val_epoch_loss_t1 = val_all_loss_t1/step
            print("val_epoch_loss = %0.3f" %(val_epoch_loss_t1))
            with open(r'val_epoch_loss_4_t1.txt', 'a+') as f:
                f.writelines('{0}\t{1} \n'.format(str(epoch), str(val_epoch_loss_t1)))

    ########## FA
    # for model_name in model_fa_dir:
    #     model_fa_name = model_name.split('.')[0]
    #     model_fa_path = 'outputs_fa/' + model_fa_name + '.pth'
    #     print('model_fa_path=', model_fa_path)
    #
    #     batch_num = 'epoch_' + str(batch_size) + 'batch.pth'  # 'epoch_64batch'
    #     epoch = model_fa_name.replace(batch_num, '')
    #
    #     # 模型选择
    #     model2.load_state_dict(torch.load(model_fa_path, map_location='cpu'))
    #     model2.eval()
    #
    #     step = 0
    #     val_epoch_loss_fa = 0
    #     val_all_loss_fa = 0
    #     dt_size = len(val_dataloader.dataset)
    #
    #     with torch.no_grad():
    #         for x1, x2, y in val_dataloader:
    #             step += 1
    #             inputs1 = x2.to(device)  # [batch_size, 9, 144, 144]->model(9,2)-> output:[batch_size, 2, 144, 144]
    #             y_truth = y.to(device)
    #
    #             outputs1 = model2(inputs1)
    #
    #             val_fa_pred = torch.max(outputs1, 1)[1].squeeze().float()  # troch.max()[1]，只返回最大值的每个索引
    #
    #             val_loss_fa = 1 - dice(val_fa_pred, y_truth)
    #
    #             val_all_loss_fa += float(val_loss_fa.item())
    #             print("epoch:%s, %d/%d, loss_fa:%0.3f" % (epoch,
    #                                                       step * val_dataloader.batch_size,
    #                                                       dt_size,
    #                                                       val_loss_fa.item()))
    #
    #         val_epoch_loss_fa = val_all_loss_fa/step
    #         print("val_epoch_loss = %0.3f" %(val_epoch_loss_fa))
    #         with open(r'val_epoch_loss_fa.txt', 'a+') as f:
    #             f.writelines('{0}\t{1} \n'.format(str(epoch), str(val_epoch_loss_fa)))




##### T1+FA
    # for model_name in model_t1_fa_dir:
    #     model_t1fa_name = model_name.split('.')[0]
    #     model_t1fa_path = 'outputs_t1+fa/' + model_t1fa_name + '.pth'
    #     print('model_t1fa_path=', model_t1fa_path)
    #
    #     batch_num = 'epoch_' + str(batch_size) + 'batch.pth'  # 'epoch_64batch'
    #     epoch = model_t1fa_name.replace(batch_num, '')
    #
    #
    #     model3.load_state_dict(torch.load(model_t1fa_path, map_location='cpu'))
    #
    #     model1.eval()
    #     model2.eval()
    #     model3.eval()
    #
    #
    #     step = 0
    #     val_epoch_loss_t1_fa = 0
    #     val_all_loss_t1_fa = 0
    #     dt_size = len(val_dataloader.dataset)
    #
    #     with torch.no_grad():
    #         for x1, x2, y in val_dataloader:
    #             step += 1
    #             inputs1 = x1.to(device)  # [batch_size, 9, 144, 144]->model(9,2)-> output:[batch_size, 2, 144, 144]
    #             inputs2 = x2.to(device)
    #             y_truth = y.to(device)
    #
    #             outputs1 = model1(inputs1)
    #             outputs2 = model2(inputs2)
    #             outputs = model3(outputs1, outputs2)
    #
    #
    #             val_t1_fa_pred = torch.max(outputs, 1)[1].squeeze().float()  # troch.max()[1]，只返回最大值的每个索引
    #
    #             val_loss_t1_fa = 1 - dice(val_t1_fa_pred, y_truth)
    #
    #             val_all_loss_t1_fa += float(val_loss_t1_fa.item())
    #             print("epoch:%s, %d/%d, loss_t1:%0.3f" % (epoch,
    #                                                    step * val_dataloader.batch_size,
    #                                                    dt_size,
    #                                                    val_loss_t1_fa.item()))
    #
    #         val_epoch_loss_t1_fa = val_all_loss_t1_fa/step
    #         print("val_epoch_loss = %0.3f" %(val_epoch_loss_t1_fa))
    #         with open(r'val_epoch_loss_t1_fa.txt', 'a+') as f:
    #             f.writelines('{0}\t{1} \n'.format(str(epoch), str(val_epoch_loss_t1_fa)))