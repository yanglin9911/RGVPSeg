import config_2d
import torch
from torch import nn
from torch.utils.data import DataLoader
from traindataset_2d import MyTrainDataset
import os
from torchvision.transforms import transforms
import time
import nibabel as nib
import numpy as np
from NetModel import Unet_2d, Unet_plus_2d, MultiResUnet_2d, MultiResUnet_plus_2d, Newnet
from multi_modal_fusion_net1 import SDM_net

unet2d = Unet_2d.UNet2D  # U-Net
unetplus2d = Unet_plus_2d.UNetPlus2D  # U-Net++
multiresunet2d = MultiResUnet_2d.MultiResUnet2D  # MultiRes U-Net
ournet2d = MultiResUnet_plus_2d.MultiResUnetPlus2D  # MultiRes U-Net++

patch_size_w = config_2d.PATCH_SIZE_W
patch_size_h = config_2d.PATCH_SIZE_H
batch_size = config_2d.BATCH_SIZE
n_epochs = config_2d.NUM_EPOCHS
n_classes = config_2d.NUM_CLASSES
image_rows = config_2d.VOLUME_ROWS
image_cols = config_2d.VOLUME_COLS
image_depth = config_2d.VOLUME_DEPS
test_imgs_path = config_2d.test_imgs_path

flag_gpu = config_2d.FLAG_GPU

# 是否使用cuda
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
fusionnet = Newnet.DatafusionNet

def conv3x3(input_channel, output_channel):
    return nn.Sequential(nn.Conv2d(input_channel, output_channel, kernel_size=3, stride=1, padding=1),
                         nn.BatchNorm2d(output_channel),
                         nn.ReLU(inplace=True))


def UNet_up_conv_bn_relu(input_channel, output_channel, learned_bilinear=False):
    if learned_bilinear:
        return nn.Sequential(nn.ConvTranspose2d(input_channel, output_channel, kernel_size=2, stride=2),
                             nn.BatchNorm2d(output_channel),
                             nn.ReLU())
    else:
        return nn.Sequential(nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
                             nn.Conv2d(input_channel, output_channel, kernel_size=3, padding=1),
                             nn.BatchNorm2d(output_channel),
                             nn.ReLU())


class basic_block(nn.Module):
    def __init__(self, input_channel, output_channel):
        super(basic_block, self).__init__()
        self.conv1 = nn.Conv2d(input_channel, output_channel, 3, padding=1)
        self.bn1 = nn.BatchNorm2d(output_channel)
        self.conv2 = nn.Conv2d(output_channel, output_channel, 3, padding=1)
        self.bn2 = nn.BatchNorm2d(output_channel)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.relu(self.bn1(self.conv1(x)))
        x = self.relu(self.bn2(self.conv2(x)))
        return x


class Channel_Attention(nn.Module):
    def __init__(self, channel, reduction=16):
        super(Channel_Attention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return y


class Feature_refine_block(nn.Module):
    def __init__(self, in_channel, dilation):
        super(Feature_refine_block, self).__init__()
        self.conv1 = nn.Conv2d(in_channel, in_channel, 3, padding=dilation, dilation=dilation)
        self.bn1 = nn.BatchNorm2d(in_channel)
        self.conv2 = nn.Conv2d(in_channel, in_channel, 3, padding=dilation, dilation=dilation)
        self.bn2 = nn.BatchNorm2d(in_channel)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        y = self.relu(self.bn1(self.conv1(x)))
        y = self.bn2(self.conv2(y))
        y = y + x
        y = self.relu(y)
        return y


class Spatial_Attention(nn.Module):
    def __init__(self, input_channel, reduction=16, dilation=4):
        super(Spatial_Attention, self).__init__()

        self.conv1 = nn.Conv2d(input_channel, input_channel // 16, kernel_size=1, stride=1, padding=0)
        self.conv2 = nn.Conv2d(input_channel // 16, input_channel // 16, kernel_size=3, dilation=4,
                               stride=1, padding=4)
        self.conv3 = nn.Conv2d(input_channel // 16, input_channel // 16, kernel_size=3, dilation=4,
                               stride=1, padding=4)
        self.conv4 = nn.Conv2d(input_channel // 16, 1, kernel_size=1, stride=1, padding=0)
        self.bn = nn.BatchNorm2d(1)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        y = self.conv1(x)
        y = self.conv2(y)
        y = self.conv3(y)
        y = self.bn(self.conv4(y))
        y = self.sigmoid(y)

        return y


class Bottleneck_Attention_Module(nn.Module):
    def __init__(self, input_channel, reduction=16, dilation=4):
        super(Bottleneck_Attention_Module, self).__init__()

        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(input_channel, input_channel // reduction),
            nn.ReLU(inplace=True),
            nn.Linear(input_channel // reduction, input_channel),
            nn.Sigmoid()
        )

        self.conv1 = nn.Conv2d(input_channel, input_channel // reduction, kernel_size=1, stride=1, padding=0)
        self.conv2 = nn.Conv2d(input_channel // reduction, input_channel // reduction, kernel_size=3, dilation=dilation,
                               stride=1, padding=dilation)
        self.conv3 = nn.Conv2d(input_channel // reduction, input_channel // reduction, kernel_size=3, dilation=dilation,
                               stride=1, padding=dilation)
        self.conv4 = nn.Conv2d(input_channel // reduction, 1, kernel_size=1, stride=1, padding=0)
        self.bn = nn.BatchNorm2d(1)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        b, c, _, _ = x.size()
        y1 = self.avg_pool(x).view(b, c)
        y1 = self.fc(y1).view(b, c, 1, 1)
        ca_weights = torch.ones(x.size()).cuda() * y1

        y2 = self.conv1(x)
        y2 = self.conv2(y2)
        y2 = self.conv3(y2)
        y2 = self.bn(self.conv4(y2))

        sa_weights = y2.repeat(1, x.size()[1], 1, 1)

        y = self.sigmoid(ca_weights + sa_weights)

        return y


class UNet_basic_down_block(nn.Module):
    def __init__(self, input_channel, output_channel):
        super(UNet_basic_down_block, self).__init__()
        self.block = basic_block(input_channel, output_channel)

    def forward(self, x):
        x = self.block(x)
        return x


class UNet_basic_up_block(nn.Module):
    def __init__(self, input_channel, prev_channel, output_channel, dilation, learned_bilinear=False):
        super(UNet_basic_up_block, self).__init__()
        self.bilinear_up = UNet_up_conv_bn_relu(input_channel, prev_channel, learned_bilinear)
        self.block = basic_block(prev_channel * 2, output_channel)
        self.feature = Feature_refine_block(prev_channel, dilation)

    def forward(self, pre_feature_map, x):
        x = self.bilinear_up(x)
        pre_feature_map = self.feature(pre_feature_map)
        x = torch.cat((x, pre_feature_map), dim=1)
        x = self.block(x)
        return x


class UNet_ca_up_block(nn.Module):
    def __init__(self, input_channel, prev_channel, output_channel, learned_bilinear=False):
        super(UNet_ca_up_block, self).__init__()
        self.bilinear_up = UNet_up_conv_bn_relu(input_channel, prev_channel, learned_bilinear)
        self.block = basic_block(prev_channel * 2, output_channel)
        self.ca = Channel_Attention(prev_channel * 2, reduction=16)

    def forward(self, pre_feature_map, x):
        x = self.bilinear_up(x)
        x = torch.cat((x, pre_feature_map), dim=1)
        x = self.ca(x) * x
        x = self.block(x)
        return x


class UNet_resca_up_block(nn.Module):
    def __init__(self, input_channel, prev_channel, output_channel, learned_bilinear=False):
        super(UNet_resca_up_block, self).__init__()
        self.bilinear_up = UNet_up_conv_bn_relu(input_channel, prev_channel, learned_bilinear)
        self.block = basic_block(prev_channel * 2, output_channel)
        self.ca = Channel_Attention(prev_channel * 2, reduction=16)

    def forward(self, pre_feature_map, x):
        x = self.bilinear_up(x)
        x = torch.cat((x, pre_feature_map), dim=1)
        x = self.ca(x) * x + x
        x = self.block(x)
        return x


class t1safaFuseUNet1(nn.Module):
    def __init__(self, num_classes=2, pretrain=False, reduction=16, dilation=4, learned_bilinear=False):
        super(t1safaFuseUNet1, self).__init__()

        ################# peaks encoder #################

        self.down_block1_peaks = UNet_basic_down_block(1, 32)
        self.sa1_peaks = Spatial_Attention(input_channel=32, reduction=reduction, dilation=dilation)
        self.max_pool1_peaks = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block2_peaks = UNet_basic_down_block(32, 64)
        self.sa2_peaks = Spatial_Attention(input_channel=64, reduction=reduction, dilation=dilation)
        self.max_pool2_peaks = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block3_peaks = UNet_basic_down_block(64, 128)
        self.sa3_peaks = Spatial_Attention(input_channel=128, reduction=reduction, dilation=dilation)
        self.max_pool3_peaks = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block4_peaks = UNet_basic_down_block(128, 256)
        self.sa4_peaks = Spatial_Attention(input_channel=256, reduction=reduction, dilation=dilation)
        self.max_pool4_peaks = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block5_peaks = UNet_basic_down_block(256, 512)
        self.sa5_peaks = Spatial_Attention(input_channel=512, reduction=reduction, dilation=dilation)

        ################# t1 encoder #################

        self.down_block1_t1 = UNet_basic_down_block(1, 32)
        self.max_pool1_t1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block2_t1 = UNet_basic_down_block(64, 64)
        self.max_pool2_t1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block3_t1 = UNet_basic_down_block(128, 128)
        self.max_pool3_t1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block4_t1 = UNet_basic_down_block(256, 256)
        self.max_pool4_t1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block5_t1 = UNet_basic_down_block(512, 512)

        ################# DCE decoder #################

        self.up_block1 = UNet_basic_up_block(1024, 512, 512, 4,learned_bilinear)
        self.up_block2 = UNet_basic_up_block(512, 256, 256, 3, learned_bilinear)
        self.up_block3 = UNet_basic_up_block(256, 128, 128, 2, learned_bilinear)
        self.up_block4 = UNet_basic_up_block(128, 64, 64, 1, learned_bilinear)

        self.last_conv1 = nn.Conv2d(64, 2, 1, padding=0)

    def forward(self, t1_inputs, peaks_inputs):
        x_1 = self.down_block1_peaks(peaks_inputs)
        y = self.down_block1_t1(t1_inputs)
        y1_peaks = self.sa1_peaks(y)
        x1_t1 = y1_peaks * x_1

        x = self.max_pool1_peaks(x1_t1)
        y_1 = torch.cat((y * y1_peaks, x1_t1), dim=1)
        y = self.max_pool1_t1(y_1)

        x_2 = self.down_block2_peaks(x)
        y = self.down_block2_t1(y)
        y2_peaks = self.sa2_peaks(y)
        x2_t1 = y2_peaks * x_2

        x = self.max_pool2_peaks(x2_t1)
        y_2 = torch.cat((y * y2_peaks, x2_t1), dim=1)
        y = self.max_pool2_t1(y_2)

        x_3 = self.down_block3_peaks(x)
        y = self.down_block3_t1(y)
        y3_peaks = self.sa3_peaks(y)
        x3_t1 = y3_peaks * x_3

        x = self.max_pool3_peaks(x3_t1)
        y_3 = torch.cat((y * y3_peaks, x3_t1), dim=1)
        y = self.max_pool3_t1(y_3)

        x_4 = self.down_block4_peaks(x)
        y = self.down_block4_t1(y)
        y4_peaks = self.sa4_peaks(y)
        x4_t1 = y4_peaks * x_4

        x = self.max_pool4_peaks(x4_t1)
        y_4 = torch.cat((y * y4_peaks, x4_t1), dim=1)
        y = self.max_pool4_t1(y_4)

        x_5 = self.down_block5_peaks(x)
        y = self.down_block5_t1(y)
        y5_peaks = self.sa5_peaks(y)
        x5_t1 = x_5 * y5_peaks

        y = torch.cat((y * y5_peaks, x5_t1), dim=1)

        ################# DCE encoder #################

        y = self.up_block1(y_4, y)
        y = self.up_block2(y_3, y)
        y = self.up_block3(y_2, y)
        y = self.up_block4(y_1, y)

        final = self.last_conv1(y)

        out = torch.sigmoid(final)
        return out


class t1sapeaksFuseUNet2(nn.Module):
    def __init__(self, num_classes=2, pretrain=False, reduction=16, dilation=4, learned_bilinear=False):
        super(t1sapeaksFuseUNet2, self).__init__()

        ################# peaks encoder #################

        self.down_block1_peaks = UNet_basic_down_block(9, 32)
        self.sa1_peaks = Spatial_Attention(input_channel=32, reduction=reduction, dilation=dilation)
        self.max_pool1_peaks = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block2_peaks = UNet_basic_down_block(32, 64)
        self.sa2_peaks = Spatial_Attention(input_channel=64, reduction=reduction, dilation=dilation)
        self.max_pool2_peaks = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block3_peaks = UNet_basic_down_block(64, 128)
        self.sa3_peaks = Spatial_Attention(input_channel=128, reduction=reduction, dilation=dilation)
        self.max_pool3_peaks = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block4_peaks = UNet_basic_down_block(128, 256)
        self.sa4_peaks = Spatial_Attention(input_channel=256, reduction=reduction, dilation=dilation)
        self.max_pool4_peaks = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block5_peaks = UNet_basic_down_block(256, 512)
        self.sa5_peaks = Spatial_Attention(input_channel=512, reduction=reduction, dilation=dilation)

        ################# t1 encoder #################

        self.down_block1_t1 = UNet_basic_down_block(1, 32)
        self.max_pool1_t1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block2_t1 = UNet_basic_down_block(64, 64)
        self.max_pool2_t1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block3_t1 = UNet_basic_down_block(128, 128)
        self.max_pool3_t1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block4_t1 = UNet_basic_down_block(256, 256)
        self.max_pool4_t1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block5_t1 = UNet_basic_down_block(512, 512)

        ################# DCE decoder #################

        self.up_block1 = UNet_basic_up_block(1024, 512, 512, 4, learned_bilinear)
        self.up_block2 = UNet_basic_up_block(512, 256, 256, 3, learned_bilinear)
        self.up_block3 = UNet_basic_up_block(256, 128, 128, 2, learned_bilinear)
        self.up_block4 = UNet_basic_up_block(128, 64, 64, 1, learned_bilinear)

        self.last_conv1 = nn.Conv2d(64, 2, 1, padding=0)

    def forward(self, t1_inputs, peaks_inputs):
        x_1 = self.down_block1_peaks(peaks_inputs)
        y = self.down_block1_t1(t1_inputs)
        y1_peaks = self.sa1_peaks(y)
        x1_t1 = y1_peaks * x_1

        x = self.max_pool1_peaks(x1_t1)
        y_1 = torch.cat((y * y1_peaks, x1_t1), dim=1)
        y = self.max_pool1_t1(y_1)

        x_2 = self.down_block2_peaks(x)
        y = self.down_block2_t1(y)
        y2_peaks = self.sa2_peaks(y)
        x2_t1 = y2_peaks * x_2

        x = self.max_pool2_peaks(x2_t1)
        y_2 = torch.cat((y * y2_peaks, x2_t1), dim=1)
        y = self.max_pool2_t1(y_2)

        x_3 = self.down_block3_peaks(x)
        y = self.down_block3_t1(y)
        y3_peaks = self.sa3_peaks(y)
        x3_t1 = y3_peaks * x_3

        x = self.max_pool3_peaks(x3_t1)
        y_3 = torch.cat((y * y3_peaks, x3_t1), dim=1)
        y = self.max_pool3_t1(y_3)

        x_4 = self.down_block4_peaks(x)
        y = self.down_block4_t1(y)
        y4_peaks = self.sa4_peaks(y)
        x4_t1 = y4_peaks * x_4

        x = self.max_pool4_peaks(x4_t1)
        y_4 = torch.cat((y * y4_peaks, x4_t1), dim=1)
        y = self.max_pool4_t1(y_4)

        x_5 = self.down_block5_peaks(x)
        y = self.down_block5_t1(y)
        y5_peaks = self.sa5_peaks(y)
        x5_t1 = x_5 * y5_peaks

        y = torch.cat((y * y5_peaks, x5_t1), dim=1)

        ################# DCE encoder #################

        y = self.up_block1(y_4, y)
        y = self.up_block2(y_3, y)
        y = self.up_block3(y_2, y)
        y = self.up_block4(y_1, y)

        final = self.last_conv1(y)

        out = torch.sigmoid(final)
        return out


class t1safapeaksFuseUNet3(nn.Module):
    def __init__(self, num_classes=2, pretrain=False, reduction=16, dilation=4, learned_bilinear=False):
        super(t1safapeaksFuseUNet3, self).__init__()

        ################# peaks encoder #################

        self.down_block1_peaks = UNet_basic_down_block(9, 32)
        self.sa1_peaks = Spatial_Attention(input_channel=32, reduction=reduction, dilation=dilation)
        self.max_pool1_peaks = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block2_peaks = UNet_basic_down_block(32, 64)
        self.sa2_peaks = Spatial_Attention(input_channel=64, reduction=reduction, dilation=dilation)
        self.max_pool2_peaks = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block3_peaks = UNet_basic_down_block(64, 128)
        self.sa3_peaks = Spatial_Attention(input_channel=128, reduction=reduction, dilation=dilation)
        self.max_pool3_peaks = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block4_peaks = UNet_basic_down_block(128, 256)
        self.sa4_peaks = Spatial_Attention(input_channel=256, reduction=reduction, dilation=dilation)
        self.max_pool4_peaks = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block5_peaks = UNet_basic_down_block(256, 512)
        self.sa5_peaks = Spatial_Attention(input_channel=512, reduction=reduction, dilation=dilation)

        ################# t1 encoder #################

        self.down_block1_t1 = UNet_basic_down_block(2, 32)
        self.max_pool1_t1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block2_t1 = UNet_basic_down_block(64, 64)
        self.max_pool2_t1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block3_t1 = UNet_basic_down_block(128, 128)
        self.max_pool3_t1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block4_t1 = UNet_basic_down_block(256, 256)
        self.max_pool4_t1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.down_block5_t1 = UNet_basic_down_block(512, 512)

        ################# DCE decoder #################

        self.up_block1 = UNet_basic_up_block(1024, 512, 512, 4, learned_bilinear)
        self.up_block2 = UNet_basic_up_block(512, 256, 256, 3, learned_bilinear)
        self.up_block3 = UNet_basic_up_block(256, 128, 128, 2 ,learned_bilinear)
        self.up_block4 = UNet_basic_up_block(128, 64, 64, 1, learned_bilinear)

        self.last_conv1 = nn.Conv2d(64, 2, 1, padding=0)

    def forward(self, t1_inputs, peaks_inputs):
        x_1 = self.down_block1_peaks(peaks_inputs)
        y = self.down_block1_t1(t1_inputs)
        y1_peaks = self.sa1_peaks(y)
        x1_t1 = y1_peaks * x_1

        x = self.max_pool1_peaks(x1_t1)
        y_1 = torch.cat((y * y1_peaks, x1_t1), dim=1)
        y = self.max_pool1_t1(y_1)

        x_2 = self.down_block2_peaks(x)
        y = self.down_block2_t1(y)
        y2_peaks = self.sa2_peaks(y)
        x2_t1 = y2_peaks * x_2

        x = self.max_pool2_peaks(x2_t1)
        y_2 = torch.cat((y * y2_peaks, x2_t1), dim=1)
        y = self.max_pool2_t1(y_2)

        x_3 = self.down_block3_peaks(x)
        y = self.down_block3_t1(y)
        y3_peaks = self.sa3_peaks(y)
        x3_t1 = y3_peaks * x_3

        x = self.max_pool3_peaks(x3_t1)
        y_3 = torch.cat((y * y3_peaks, x3_t1), dim=1)
        y = self.max_pool3_t1(y_3)

        x_4 = self.down_block4_peaks(x)
        y = self.down_block4_t1(y)
        y4_peaks = self.sa4_peaks(y)
        x4_t1 = y4_peaks * x_4

        x = self.max_pool4_peaks(x4_t1)
        y_4 = torch.cat((y * y4_peaks, x4_t1), dim=1)
        y = self.max_pool4_t1(y_4)

        x_5 = self.down_block5_peaks(x)
        y = self.down_block5_t1(y)
        y5_peaks = self.sa5_peaks(y)
        x5_t1 = x_5 * y5_peaks

        y = torch.cat((y * y5_peaks, x5_t1), dim=1)

        ################# DCE encoder #################

        y = self.up_block1(y_4, y)
        y = self.up_block2(y_3, y)
        y = self.up_block3(y_2, y)
        y = self.up_block4(y_1, y)

        final = self.last_conv1(y)

        out = torch.sigmoid(final)
        return out


# train
def predict(img_dir, predict_t1, imgs_num):
    global model1, model2, model3, model4, test_dataset, test_dataloader

    model1_path = "/home/AVP Seg/2D_FusionNet/outputs_SDM_diceBCE_t1fapeaks/t1fapeaks_150epoch_64batch.pth"
    # model2_path = "/home/AVP Seg/2D_FusionNet/outputs_sa_fr_diceBCE_t1peaks/t1peaks_49epoch_64batch.pth"
    # model3_path = "/home/AVP Seg/2D_FusionNet/outputs_sa_fr_diceBCE_t1peaks/t1peaks_135epoch_32batch-net3.pth"
    # model4_path = "/home/AVP Seg/2D_FusionNet/outputs_2sa_fr_fusion_diceBCE_t1fapeaks/t1fapeaks_84epoch_32batch.pth"

    # 模型选择
    model1 = SDM_net().to(device)
    # model2 = t1sapeaksFuseUNet2(1, 9).to(device)
    # model3 = t1safapeaksFuseUNet3(2, 9).to(device)
    # model4 = fusionnet(4, 2).to(device)

    model1 = nn.DataParallel(model1).cuda()
    # model2 = nn.DataParallel(model2).cuda()
    # model3 = nn.DataParallel(model3).cuda()
    # model4 = nn.DataParallel(model4).cuda()

    ON_test_x_t1_dir = img_dir + 'x_t1_data/'
    ON_test_x_fa_dir = img_dir + 'x_fa_data/'
    ON_test_x_peaks_dir = img_dir + 'x_peaks_data/'
    ON_test_y_dir = img_dir + 'y_data/'

    model1.load_state_dict(torch.load(model1_path, map_location='cpu'))
    # model2.load_state_dict(torch.load(model2_path, map_location='cpu'))
    # model3.load_state_dict(torch.load(model3_path, map_location='cpu'))
    # model4.load_state_dict(torch.load(model4_path, map_location='cpu'))

    test_dataset = MyTrainDataset(ON_test_x_t1_dir, ON_test_x_fa_dir, ON_test_x_peaks_dir, ON_test_y_dir,
                                  x_transform=x_transforms, z_transform=z_transforms, y_transform=y_transforms)

    test_dataloader = DataLoader(test_dataset, batch_size=1, shuffle=False, num_workers=0)

    all_t1_patch_num = 0

    model1.eval()
    # model2.eval()
    # model3.eval()
    # model4.eval()

    with torch.no_grad():
        for x1, x2, x3, y in test_dataloader:
            inputs1 = x1.to(device)  # [batch_size, 9, 144, 144]->model(9,2)-> output:[batch_size, 2, 144, 144]
            inputs2 = x2.to(device)
            inputs3 = x3.to(device)
            # outputs1 = model1(inputs1, inputs2)
            # outputs2 = model2(inputs1, inputs3)
            pre_final = model1(inputs1, inputs2, inputs3)
            t1fa_pred = torch.max(pre_final, 1)[1].squeeze()  # troch.max()[1]，只返回最大值的每个索引
            t1fa_pred_result = t1fa_pred.cpu().numpy().astype(float)

            if all_t1_patch_num == 0:
                test_t1_data_path = ON_test_x_t1_dir + 'x_t1-data_0.nii.gz'
                test_t1_img = nib.load(test_t1_data_path)
                test_t1_img_affine = test_t1_img.affine
            t1_pred_patches_nii = nib.Nifti1Image(t1fa_pred_result, test_t1_img_affine)
            t1_pred_nii_path = predict_t1 + 'pre_' + str(all_t1_patch_num) + '.nii.gz'
            nib.save(t1_pred_patches_nii, t1_pred_nii_path)
            all_t1_patch_num += 1

    #### -------------------------------------------------
    #### -------------------------------------------------
    #### -------------------------------------------------
    ## Combination
    pre_seg_t1fa_final = np.zeros((image_rows, image_cols, image_depth))

    # source.nii
    img_name = imgs_num + '_ON-new_T1.nii.gz'

    img_name = os.path.join(test_imgs_path, imgs_num, img_name)
    img = nib.load(img_name)
    img_data = img.get_fdata()
    img_affine = img.affine

    # mask.nii
    img_mask_name = imgs_num + '_ON-mask.nii.gz'  # 根据测试集取的mask来调整
    img_mask_name = os.path.join(test_imgs_path, imgs_num, img_mask_name)
    img_mask = nib.load(img_mask_name)
    img_mask_data = img_mask.get_fdata()
    img_mask_data = np.squeeze(img_mask_data)

    X = img_mask_data.shape

    step = 0

    for iSlice in range(0, X[2]):
        if np.count_nonzero(img_mask_data[:, :, iSlice]) and np.count_nonzero(img_data[:, :, iSlice]):
            pre_name = 'pre_' + str(step) + '.nii.gz'

            pre_t1fa_name = os.path.join(predict_t1, pre_name)

            pre_seg_t1fa_temp = nib.load(pre_t1fa_name)
            pre_seg_t1fa_temp_data = pre_seg_t1fa_temp.get_fdata()

            step += 1

            for i in range(0, patch_size_w):
                for j in range(0, patch_size_h):
                    pre_seg_t1fa_final[i][j][iSlice] = pre_seg_t1fa_temp_data[i][j]

    pre_seg_t1fa_final = nib.Nifti1Image(pre_seg_t1fa_final, img_affine)

    pre_sge_finalname = 'pre_final-label.nii.gz'

    pre_sge_t1fa_final_savepath = os.path.join(predict_t1, pre_sge_finalname)
    nib.save(pre_seg_t1fa_final, pre_sge_t1fa_final_savepath)


if __name__ == '__main__':

    x_transforms = transforms.Compose([
        transforms.ToPILImage(),
        transforms.ToTensor(),
        transforms.Normalize((0.5,), (0.5,))
    ])
    z_transforms = transforms.ToTensor()
    y_transforms = transforms.ToTensor()

    # 预测结果保存
    pre_file_t1fa = 'predic_SDM_diceBCE_t1fapeaks_fusion_mask'  # model3

    if pre_file_t1fa not in os.listdir(os.curdir):
        os.mkdir(pre_file_t1fa)

    start_time = time.time()

    test_dir = os.listdir(test_imgs_path)

    for test_num in test_dir:
        test_name = 'test_' + test_num
        test_pre_name = 'test_result_' + test_num

        os.mkdir(os.path.join(pre_file_t1fa, test_pre_name))

        test_input_path = 'ON_mydata/test_data/' + test_name + '/'
        test_result_t1fa = pre_file_t1fa + '/' + test_pre_name + '/'

        ## 1.预测并合成
        predict(test_input_path, test_result_t1fa, test_num)

    end_time = time.time()
    print("2D train time is {:.3f} s".format((end_time - start_time)))
