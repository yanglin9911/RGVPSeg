import numpy as np
import config_2d
import torch
import time, os
import nibabel as nib
from skimage import measure

batch_size =config_2d.BATCH_SIZE
patch_size_w = config_2d.PATCH_SIZE_W
patch_size_h = config_2d.PATCH_SIZE_H
n_classes = config_2d.NUM_CLASSES

train_extraction_step = config_2d.TRAIN_EXTRACTION_STEP # 提取训练集ptach的步长=12
test_extraction_step = config_2d.TEST_EXTRACTION_STEP   # 提取测试集ptach的步长=patch_size


train_imgs_path = config_2d.train_imgs_path
# val_imgs_path = config_2d.val_imgs_path
test_imgs_path = config_2d.test_imgs_path




##---------------------------------------------------------------------------------
##---------------------------------------------------------------------------------
##---------------------------------------------------------------------------------
def find_chiasm_center(allslice_num):
    center_num = 0
    length = len(allslice_num)
    flag_one = 1
    flag_two = 1
    first_num = 0
    last_num = 0
    #print([len(list(v)) for k, v in itertools.groupby(allslice_num)])
    #print(allslice_num)
    for i in range(1,length):
        if allslice_num[i-1] == 2 and allslice_num[i] == 1 and flag_one==1 :
            flag_one =0
            first_num = i
            for j in range(first_num,length):
                if allslice_num[j - 1] == 1 and allslice_num[j] == 2 and flag_two == 1:
                    flag_two = 0
                    last_num =j

    center_num = first_num + int((last_num - first_num) / 2)
    return center_num


##### create train data 训练集数据 ####
def create_train_data(imgs_path, save_path):

    images_dir = os.listdir(imgs_path)
    # For model 1
    x_EC_t1_dir = os.path.join(save_path, 'x_EC_t1_data')   # ETC(T1)
    y_EC_dir = os.path.join(save_path, 'y_EC_data')
    # For model 2
    x_CL_t1_dir = os.path.join(save_path, 'x_CL_t1_data')   # CTL(T1)、CTL(FA)
    x_CL_fa_dir = os.path.join(save_path, 'x_CL_fa_data')
    y_CL_dir = os.path.join(save_path,    'y_CL_data')

    j = 0
    print('-' * 30)
    print('Creating train 2d_patches...')
    print('-' * 30)

    EC_all_patch_num = 0
    CL_all_patch_num = 0

    num = 0
    # for each volume do:
    for img_dir_name in images_dir:
        num = num + 1
        # T1
        img_t1_name = img_dir_name + '_CN-T1_new.nii.gz'  # T1
        img_t1_name = os.path.join(imgs_path, img_dir_name, img_t1_name)
        # FA
        img_t1_fa_name = img_dir_name + '_CN-FA_new.nii.gz'  # FA
        img_t1_fa_name = os.path.join(imgs_path, img_dir_name, img_t1_fa_name)
        # label
        img_label_name = img_dir_name + '_ON-label.nii.gz'
        img_label_name = os.path.join(imgs_path, img_dir_name, img_label_name)
        # mask
        img_mask_name = img_dir_name + '_CN-mask.nii.gz'
        img_mask_name = os.path.join(imgs_path, img_dir_name, img_mask_name)


        # load T1, FA, label and mask
        img_t1 = nib.load(img_t1_name)
        img_t1_data = img_t1.get_fdata()
        img_t1_affine = img_t1.affine
        img_t1_data = np.squeeze(img_t1_data)

        img_fa = nib.load(img_t1_fa_name)
        img_fa_data = img_fa.get_fdata()
        img_fa_affine = img_fa.affine
        img_fa_data = np.squeeze(img_fa_data)

        img_label = nib.load(img_label_name)
        img_label_data = img_label.get_fdata()
        img_label_affine = img_label.affine
        img_label_data = np.squeeze(img_label_data)

        img_mask = nib.load(img_mask_name)
        img_mask_data = img_mask.get_fdata()
        img_mask_data = np.squeeze(img_mask_data)

        X = img_label_data.shape
        allnum = []

        for i in range(X[2]):
            nii_label_slice = img_label_data[:,:,i]
            #print('slice = ', i)
            label, number = measure.label(nii_label_slice, connectivity=2, background=0, return_num=True)
            allnum.append(number)
        center_num = find_chiasm_center(allnum)


        # for each slice do
        for slice in range(X[2]):
            print('Processing: volume {0} / {1} volume images, slice {2} / {3} slices'.format(j + 1,
                                                                                              len(images_dir),
                                                                                              slice+1,
                                                                                              img_label_data.shape[2]))

            if slice <= center_num: # For model 1  EC(T1)
                # 2D Axial
                #if np.count_nonzero(img_label_data[:, :, slice])==0 and np.count_nonzero(img_t1_data[:, :, slice])>0:
                if np.count_nonzero(img_label_data[:, :, slice]) >= 0 and np.count_nonzero(img_mask_data[:, :, slice]) >= 0 and np.count_nonzero(img_t1_data[:, :, slice]) >= 0:
                    t1_patches = img_t1_data[:, :, slice]
                    fa_patches = img_fa_data[:, :, slice]
                    label_patches = img_label_data[:, :, slice]
                    ### ETC (T1)
                    # x_EC data
                    t1_patches_nii = t1_patches
                    t1_flip_patches_nii = np.flip(t1_patches_nii, 0)
                    t1_nonum_nii_path = x_EC_t1_dir + '/x_EC_t1-data_' + str(EC_all_patch_num) + '.nii.gz'
                    t1_patches_nii = nib.Nifti1Image(t1_patches_nii, img_t1_affine)
                    nib.save(t1_patches_nii, t1_nonum_nii_path)
                    # y_EC data
                    label_patches_nii = label_patches
                    label_flip_patches_nii = np.flip(label_patches_nii, 0)  # t1_fa-label flip data
                    label_nonum_nii_path = y_EC_dir + '/y_EC-data_' + str(EC_all_patch_num) + '.nii.gz'
                    label_patches_nii = nib.Nifti1Image(label_patches_nii, img_label_affine)
                    nib.save(label_patches_nii, label_nonum_nii_path)
                    EC_all_patch_num += 1
                    ### --------------
                    ####数据增强
                    ### t1 x flip data  （翻转180）
                    t1_flip_nonum_nii_path = x_EC_t1_dir + '/x_EC_t1-data_' + str(EC_all_patch_num) + '.nii.gz'
                    t1_flip_patches_nii = nib.Nifti1Image(t1_flip_patches_nii, img_t1_affine)
                    nib.save(t1_flip_patches_nii, t1_flip_nonum_nii_path)
                    ### y flip data
                    label_flip_nonum_nii_path = y_EC_dir + '/y_EC-data_' + str(EC_all_patch_num) + '.nii.gz'
                    label_flip_patches_nii = nib.Nifti1Image(label_flip_patches_nii, img_label_affine)
                    nib.save(label_flip_patches_nii, label_flip_nonum_nii_path)
                    EC_all_patch_num += 1
                    ### --------------

            if slice > center_num:  # For model 2  CL(T1、FA)
                # 2D Axial
                #if np.count_nonzero(img_label_data[:, :, slice])==0 and np.count_nonzero(img_t1_data[:, :, slice])>0:
                if np.count_nonzero(img_label_data[:, :, slice]) >= 0 and np.count_nonzero(img_mask_data[:, :, slice]) >= 0 and np.count_nonzero(img_t1_data[:, :, slice]) >= 0:
                    t1_patches = img_t1_data[:, :, slice]
                    fa_patches = img_fa_data[:, :, slice]
                    label_patches = img_label_data[:, :, slice]
                    ### CTL (T1)  x1
                    # x1 data
                    t1_patches_nii = t1_patches
                    t1_flip_patches_nii = np.flip(t1_patches_nii, 0)
                    t1_nonum_nii_path = x_CL_t1_dir + '/x_CL_t1-data_' + str(CL_all_patch_num) + '.nii.gz'
                    t1_patches_nii = nib.Nifti1Image(t1_patches_nii, img_t1_affine)
                    nib.save(t1_patches_nii, t1_nonum_nii_path)
                    ### CTL (FA)  x2
                    # x2 data
                    fa_patches_nii = fa_patches
                    fa_flip_patches_nii = np.flip(fa_patches_nii, 0)
                    fa_nonum_nii_path = x_CL_fa_dir + '/x_CL_fa-data_' + str(CL_all_patch_num) + '.nii.gz'
                    fa_patches_nii = nib.Nifti1Image(fa_patches_nii, img_fa_affine)
                    nib.save(fa_patches_nii, fa_nonum_nii_path)
                    # y data
                    label_patches_nii = label_patches
                    label_flip_patches_nii = np.flip(label_patches_nii, 0)  # t1_fa-label flip data
                    label_nonum_nii_path = y_CL_dir + '/y_CL-data_' + str(CL_all_patch_num) + '.nii.gz'
                    label_patches_nii = nib.Nifti1Image(label_patches_nii, img_label_affine)
                    nib.save(label_patches_nii, label_nonum_nii_path)
                    CL_all_patch_num += 1
                    ### --------------
                    ####数据增强
                    ### t1 x flip data  （翻转180）
                    t1_flip_nonum_nii_path = x_CL_t1_dir + '/x_CL_t1-data_' + str(CL_all_patch_num) + '.nii.gz'
                    t1_flip_patches_nii = nib.Nifti1Image(t1_flip_patches_nii, img_t1_affine)
                    nib.save(t1_flip_patches_nii, t1_flip_nonum_nii_path)
                    ### fa x flip data  （翻转180）
                    fa_flip_nonum_nii_path = x_CL_fa_dir + '/x_CL_fa-data_' + str(CL_all_patch_num) + '.nii.gz'
                    fa_flip_patches_nii = nib.Nifti1Image(fa_flip_patches_nii, img_fa_affine)
                    nib.save(fa_flip_patches_nii, fa_flip_nonum_nii_path)
                    ### y flip data
                    label_flip_nonum_nii_path = y_CL_dir + '/y_CL-data_' + str(CL_all_patch_num) + '.nii.gz'
                    label_flip_patches_nii = nib.Nifti1Image(label_flip_patches_nii, img_label_affine)
                    nib.save(label_flip_patches_nii, label_flip_nonum_nii_path)
                    CL_all_patch_num += 1
                    ### --------------
        j += 1
        print('Input num:   {0}'.format(img_dir_name))
        print('EC All Patch num:  {0}'.format(EC_all_patch_num))
        print('CL All Patch num:  {0}'.format(CL_all_patch_num))

        print('Patch size:  [{0}*{1}]'.format(patch_size_w, patch_size_h))
    print('-' * 30)
    print('EC All Patches: {0}'.format(EC_all_patch_num))
    print('CL All Patches: {0}'.format(CL_all_patch_num))

    print('-' * 30)

##---------------------------------------------------------------------------------
##---------------------------------------------------------------------------------
##---------------------------------------------------------------------------------
##### create val data 创建验证集数据 ####
def create_val_data(imgs_path, save_path):

    images_dir = os.listdir(imgs_path)
    # For model 1
    x_EC_t1_dir = os.path.join(save_path, 'x_EC_t1_data')   # ETC(T1)
    y_EC_dir = os.path.join(save_path, 'y_EC_data')
    # For model 2
    x_CL_t1_dir = os.path.join(save_path, 'x_CL_t1_data')   # CTL(T1)、CTL(FA)
    x_CL_fa_dir = os.path.join(save_path, 'x_CL_fa_data')
    y_CL_dir = os.path.join(save_path,    'y_CL_data')


    j = 0
    print('-' * 30)
    print('Creating train 2d_patches...')
    print('-' * 30)

    EC_all_patch_num = 0
    CL_all_patch_num = 0

    num = 0
    # for each volume do:
    for img_dir_name in images_dir:
        num = num + 1
        # T1
        img_t1_name = img_dir_name + '_ON-new_T1.nii.gz'  # T1
        img_t1_name = os.path.join(imgs_path, img_dir_name, img_t1_name)
        # FA
        img_t1_fa_name = img_dir_name + '_ON-new_FA.nii.gz'  # FA
        img_t1_fa_name = os.path.join(imgs_path, img_dir_name, img_t1_fa_name)
        # label
        img_label_name = img_dir_name + '_ON-label.nii.gz'
        img_label_name = os.path.join(imgs_path, img_dir_name, img_label_name)

        # load T1, FA, label and mask
        img_t1 = nib.load(img_t1_name)
        img_t1_data = img_t1.get_fdata()
        img_t1_affine = img_t1.affine
        img_t1_data = np.squeeze(img_t1_data)

        img_fa = nib.load(img_t1_fa_name)
        img_fa_data = img_fa.get_fdata()
        img_fa_affine = img_fa.affine
        img_fa_data = np.squeeze(img_fa_data)

        img_label = nib.load(img_label_name)
        img_label_data = img_label.get_fdata()
        img_label_affine = img_label.affine
        img_label_data = np.squeeze(img_label_data)


        X = img_label_data.shape
        allnum = []

        for i in range(X[2]):
            nii_label_slice = img_label_data[:,:,i]
            #print('slice = ', i)
            label, number = measure.label(nii_label_slice, connectivity=2, background=0, return_num=True)
            allnum.append(number)
        center_num = find_chiasm_center(allnum)


        # for each slice do
        for slice in range(X[2]):
            print('Processing: volume {0} / {1} volume images, slice {2} / {3} slices'.format(j + 1,
                                                                                              len(images_dir),
                                                                                              slice+1,
                                                                                              img_label_data.shape[2]))

            if slice <= center_num:  # For model 1  EC(T1)
                # 2D Axial
                t1_patches = img_t1_data[:, :, slice]
                fa_patches = img_fa_data[:, :, slice]
                label_patches = img_label_data[:, :, slice]
                ### ETC (T1)
                # x_EC data
                t1_patches_nii = t1_patches
                t1_flip_patches_nii = np.flip(t1_patches_nii, 0)
                t1_nonum_nii_path = x_EC_t1_dir + '/x_EC_t1-data_' + str(EC_all_patch_num) + '.nii.gz'
                t1_patches_nii = nib.Nifti1Image(t1_patches_nii, img_t1_affine)
                nib.save(t1_patches_nii, t1_nonum_nii_path)
                # y_EC data
                label_patches_nii = label_patches
                label_flip_patches_nii = np.flip(label_patches_nii, 0)  # t1_fa-label flip data
                label_nonum_nii_path = y_EC_dir + '/y_EC-data_' + str(EC_all_patch_num) + '.nii.gz'
                label_patches_nii = nib.Nifti1Image(label_patches_nii, img_label_affine)
                nib.save(label_patches_nii, label_nonum_nii_path)
                EC_all_patch_num += 1
                ### --------------
                ### --------------

            if slice > center_num:  # For model 2  CL(T1、FA)
                # 2D Axial
                t1_patches = img_t1_data[:, :, slice]
                fa_patches = img_fa_data[:, :, slice]
                label_patches = img_label_data[:, :, slice]
                ### CTL (T1)  x1
                # x1 data
                t1_patches_nii = t1_patches
                t1_flip_patches_nii = np.flip(t1_patches_nii, 0)
                t1_nonum_nii_path = x_CL_t1_dir + '/x_CL_t1-data_' + str(CL_all_patch_num) + '.nii.gz'
                t1_patches_nii = nib.Nifti1Image(t1_patches_nii, img_t1_affine)
                nib.save(t1_patches_nii, t1_nonum_nii_path)
                ### CTL (FA)  x2
                # x2 data
                fa_patches_nii = fa_patches
                fa_flip_patches_nii = np.flip(fa_patches_nii, 0)
                fa_nonum_nii_path = x_CL_fa_dir + '/x_CL_fa-data_' + str(CL_all_patch_num) + '.nii.gz'
                fa_patches_nii = nib.Nifti1Image(fa_patches_nii, img_fa_affine)
                nib.save(fa_patches_nii, fa_nonum_nii_path)
                # y data
                label_patches_nii = label_patches
                label_flip_patches_nii = np.flip(label_patches_nii, 0)  # t1_fa-label flip data
                label_nonum_nii_path = y_CL_dir + '/y_CL-data_' + str(CL_all_patch_num) + '.nii.gz'
                label_patches_nii = nib.Nifti1Image(label_patches_nii, img_label_affine)
                nib.save(label_patches_nii, label_nonum_nii_path)
                CL_all_patch_num += 1
                ### --------------

        j += 1
        print('Input num:   {0}'.format(img_dir_name))
        print('EC All Patch num:  {0}'.format(EC_all_patch_num))
        print('CL All Patch num:  {0}'.format(CL_all_patch_num))

        print('Patch size:  [{0}*{1}]'.format(patch_size_w, patch_size_h))
    print('-' * 30)
    print('EC All Patches: {0}'.format(EC_all_patch_num))
    print('CL All Patches: {0}'.format(CL_all_patch_num))

    print('-' * 30)

##---------------------------------------------------------------------------------
##---------------------------------------------------------------------------------
##---------------------------------------------------------------------------------
##### create test data without_data_partition创建测试集数据 ####
def create_test_data_without_data_partition(img_dir_name, save_path):


    x_t1_dir = os.path.join(save_path, 'x_t1_data')   # CTL(T1)、CTL(FA)
    x_fa_dir = os.path.join(save_path, 'x_fa_data')
    y_dir = os.path.join(save_path,    'y_data')


    j = 0
    print('-' * 30)
    print('Creating test 2d_patches...')
    print('-' * 30)

    # for each volume do:
    img_t1_name = img_dir_name + '_CN-T1_new.nii.gz'
    img_t1_name = os.path.join(test_imgs_path, img_dir_name, img_t1_name)

    img_fa_name = img_dir_name +  '_CN-FA_new.nii.gz'
    img_fa_name = os.path.join(test_imgs_path, img_dir_name, img_fa_name)

    img_label_name = img_dir_name + '_ON-label.nii.gz'
    img_label_name = os.path.join(test_imgs_path, img_dir_name, img_label_name)

    # mask
    img_mask_name = img_dir_name + '_CN-mask.nii.gz'
    img_mask_name = os.path.join(test_imgs_path, img_dir_name, img_mask_name)

    # T1.nii
    img_t1 = nib.load(img_t1_name)
    img_t1_affine = img_t1.affine
    img_t1_data = img_t1.get_fdata()
    img_t1_data = np.squeeze(img_t1_data)
    # FA.nii
    img_fa = nib.load(img_fa_name)
    img_fa_data = img_fa.get_fdata()
    img_fa_affine = img_fa.affine
    img_fa_data = np.squeeze(img_fa_data)
    # label.nii
    img_label = nib.load(img_label_name)
    img_label_data = img_label.get_fdata()
    img_label_affine = img_label.affine
    img_label_data = np.squeeze(img_label_data)

    img_mask = nib.load(img_mask_name)
    img_mask_data = img_mask.get_fdata()
    img_mask_data = np.squeeze(img_mask_data)

    X = img_label_data.shape
    all_patch_num = 0

    for slice in range(X[2]):
        # 2D Axial
        t1_patches = img_t1_data[:, :, slice]
        fa_patches = img_fa_data[:, :, slice]
        label_patches = img_label_data[:, :, slice]
        # x_t1 data
        t1_patches_nii = t1_patches
        t1_nonum_nii_path = x_t1_dir + '/x_t1-data_' + str(all_patch_num) + '.nii.gz'
        t1_patches_nii = nib.Nifti1Image(t1_patches_nii, img_t1_affine)
        nib.save(t1_patches_nii, t1_nonum_nii_path)
        # x_fa data
        fa_patches_nii = fa_patches
        fa_nonum_nii_path = x_fa_dir + '/x_fa-data_' + str(all_patch_num) + '.nii.gz'
        fa_patches_nii = nib.Nifti1Image(fa_patches_nii, img_fa_affine)
        nib.save(fa_patches_nii, fa_nonum_nii_path)
        # y_data
        label_patches_nii = label_patches
        label_nonum_nii_path = y_dir + '/y-data_' + str(all_patch_num) + '.nii.gz'
        label_patches_nii = nib.Nifti1Image(label_patches_nii, img_label_affine)
        nib.save(label_patches_nii, label_nonum_nii_path)
        all_patch_num += 1
        ### --------------
        ### --------------
    j += 1
    print('-' * 30)


##---------------------------------------------------------------------------------
##---------------------------------------------------------------------------------
##---------------------------------------------------------------------------------
##### create test data 创建测试集数据 ####
def create_test_data_with_data_partition(img_dir_name, save_path):

    # For model 1
    x_EC_t1_dir = os.path.join(save_path, 'x_EC_t1_data')   # ETC(T1)
    y_EC_dir = os.path.join(save_path, 'y_EC_data')
    # For model 2
    x_CL_t1_dir = os.path.join(save_path, 'x_CL_t1_data')   # CTL(T1)、CTL(FA)
    x_CL_fa_dir = os.path.join(save_path, 'x_CL_fa_data')
    y_CL_dir = os.path.join(save_path,    'y_CL_data')

    start_time = time.time()
    j = 0
    print('-' * 30)
    print('Creating test 2d_patches...')
    print('-' * 30)
    EC_all_patch_num = 0
    CL_all_patch_num = 0

    # for each volume do:
    img_t1_name = img_dir_name +  '_CN-T1_new.nii.gz'
    img_t1_name = os.path.join(test_imgs_path, img_dir_name, img_t1_name)

    img_fa_name = img_dir_name +  '_CN-FA_new.nii.gz'
    img_fa_name = os.path.join(test_imgs_path, img_dir_name, img_fa_name)

    img_label_name = img_dir_name + '_ON-label.nii.gz'
    img_label_name = os.path.join(test_imgs_path, img_dir_name, img_label_name)


    # T1.nii
    img_t1 = nib.load(img_t1_name)
    img_t1_affine = img_t1.affine
    img_t1_data = img_t1.get_fdata()
    img_t1_data = np.squeeze(img_t1_data)
    # FA.nii
    img_fa = nib.load(img_fa_name)
    img_fa_data = img_fa.get_fdata()
    img_fa_affine = img_fa.affine
    img_fa_data = np.squeeze(img_fa_data)
    # label.nii
    img_label = nib.load(img_label_name)
    img_label_data = img_label.get_fdata()
    img_label_affine = img_label.affine
    img_label_data = np.squeeze(img_label_data)


    X = img_label_data.shape
    allnum = []

    for i in range(X[2]):
        nii_label_slice = img_label_data[:, :, i]
        # print('slice = ', i)
        label, number = measure.label(nii_label_slice, connectivity=2, background=0, return_num=True)
        allnum.append(number)
    center_num = find_chiasm_center(allnum)

    for slice in range(X[2]):
        if slice <= center_num:  # For model 1  EC(T1)
            # 2D Axial
            t1_patches = img_t1_data[:, :, slice]
            fa_patches = img_fa_data[:, :, slice]
            label_patches = img_label_data[:, :, slice]
            ### ETC (T1)
            # x_EC data
            t1_patches_nii = t1_patches
            t1_flip_patches_nii = np.flip(t1_patches_nii, 0)
            t1_nonum_nii_path = x_EC_t1_dir + '/x_EC_t1-data_' + str(EC_all_patch_num) + '.nii.gz'
            t1_patches_nii = nib.Nifti1Image(t1_patches_nii, img_t1_affine)
            nib.save(t1_patches_nii, t1_nonum_nii_path)
            # y_EC data
            label_patches_nii = label_patches
            label_flip_patches_nii = np.flip(label_patches_nii, 0)  # t1_fa-label flip data
            label_nonum_nii_path = y_EC_dir + '/y_EC-data_' + str(EC_all_patch_num) + '.nii.gz'
            label_patches_nii = nib.Nifti1Image(label_patches_nii, img_label_affine)
            nib.save(label_patches_nii, label_nonum_nii_path)
            EC_all_patch_num += 1
            ### --------------
            ### --------------

        if slice > center_num:  # For model 2  CL(T1、FA)
            # 2D Axial
            t1_patches = img_t1_data[:, :, slice]
            fa_patches = img_fa_data[:, :, slice]
            label_patches = img_label_data[:, :, slice]
            ### CTL (T1)  x1
            # x1 data
            t1_patches_nii = t1_patches
            t1_flip_patches_nii = np.flip(t1_patches_nii, 0)
            t1_nonum_nii_path = x_CL_t1_dir + '/x_CL_t1-data_' + str(CL_all_patch_num) + '.nii.gz'
            t1_patches_nii = nib.Nifti1Image(t1_patches_nii, img_t1_affine)
            nib.save(t1_patches_nii, t1_nonum_nii_path)
            ### CTL (FA)  x2
            # x2 data
            fa_patches_nii = fa_patches
            fa_flip_patches_nii = np.flip(fa_patches_nii, 0)
            fa_nonum_nii_path = x_CL_fa_dir + '/x_CL_fa-data_' + str(CL_all_patch_num) + '.nii.gz'
            fa_patches_nii = nib.Nifti1Image(fa_patches_nii, img_fa_affine)
            nib.save(fa_patches_nii, fa_nonum_nii_path)
            # y data
            label_patches_nii = label_patches
            label_flip_patches_nii = np.flip(label_patches_nii, 0)  # t1_fa-label flip data
            label_nonum_nii_path = y_CL_dir + '/y_CL-data_' + str(CL_all_patch_num) + '.nii.gz'
            label_patches_nii = nib.Nifti1Image(label_patches_nii, img_label_affine)
            nib.save(label_patches_nii, label_nonum_nii_path)
            CL_all_patch_num += 1
            ### --------------
    j += 1
    print('-' * 30)





if __name__ == '__main__':
    if 'ON_mydata' not in os.listdir(os.curdir):
        os.mkdir('ON_mydata')
    ### 1. create my train data: ###
    train_save_path = 'ON_mydata/train_clinic_T1+FA'
    trainfile_name = 'train_clinic_T1+FA'
    if trainfile_name not in os.listdir('ON_mydata'):
        os.mkdir(os.path.join('ON_mydata', trainfile_name))

    if 'x_EC_t1_data' not in os.listdir('ON_mydata/'+ trainfile_name):
        os.mkdir(os.path.join('ON_mydata/' + trainfile_name, 'x_EC_t1_data'))
    if 'x_CL_t1_data' not in os.listdir('ON_mydata/' + trainfile_name):
        os.mkdir(os.path.join('ON_mydata/' + trainfile_name, 'x_CL_t1_data'))
    if 'x_CL_fa_data' not in os.listdir('ON_mydata/' + trainfile_name):
        os.mkdir(os.path.join('ON_mydata/' + trainfile_name, 'x_CL_fa_data'))
    if 'y_EC_data' not in os.listdir('ON_mydata/' + trainfile_name):
        os.mkdir(os.path.join('ON_mydata/' + trainfile_name, 'y_EC_data'))
    if 'y_CL_data' not in os.listdir('ON_mydata/' + trainfile_name):
        os.mkdir(os.path.join('ON_mydata/' + trainfile_name, 'y_CL_data'))
    create_train_data(train_imgs_path, train_save_path)

    #
    ### 2. create my val data: ###
    # val_save_path = 'ON_mydata/val_T1+FA'
    # valfile_name = 'val_T1+FA'
    # if valfile_name not in os.listdir('ON_mydata'):
    #     os.mkdir(os.path.join('ON_mydata', valfile_name))
    # if 'x_EC_t1_data' not in os.listdir('ON_mydata/'+ valfile_name):
    #     os.mkdir(os.path.join('ON_mydata/' + valfile_name, 'x_EC_t1_data'))
    # if 'x_CL_t1_data' not in os.listdir('ON_mydata/' + valfile_name):
    #     os.mkdir(os.path.join('ON_mydata/' + valfile_name, 'x_CL_t1_data'))
    # if 'x_CL_fa_data' not in os.listdir('ON_mydata/' + valfile_name):
    #     os.mkdir(os.path.join('ON_mydata/' + valfile_name, 'x_CL_fa_data'))
    # if 'y_EC_data' not in os.listdir('ON_mydata/' + valfile_name):
    #     os.mkdir(os.path.join('ON_mydata/' + valfile_name, 'y_EC_data'))
    # if 'y_CL_data' not in os.listdir('ON_mydata/' + valfile_name):
    #     os.mkdir(os.path.join('ON_mydata/' + valfile_name, 'y_CL_data'))
    # create_val_data(val_imgs_path, val_save_path)



    ## 3. creatr my test data(one by one): ### without data partition
    # test_save_path = 'ON_mydata/test_T1+FA_without_data_partition'
    # testfile_name = 'test_T1+FA_without_data_partition'    # test  ...
    # if testfile_name not in os.listdir('ON_mydata'):
    #     os.mkdir(os.path.join('ON_mydata', testfile_name))
    # test_dir = os.listdir(test_imgs_path)
    # for test_num in test_dir:
    #     test_name = 'test_' + test_num
    #     test_inputdata_save_path = os.path.join(test_save_path, test_name)
    #     os.mkdir(test_inputdata_save_path)
    #     if 'x_t1_data' not in os.listdir(test_inputdata_save_path):
    #         os.mkdir(os.path.join(test_inputdata_save_path, 'x_t1_data'))
    #     if 'x_fa_data' not in os.listdir(test_inputdata_save_path):
    #         os.mkdir(os.path.join(test_inputdata_save_path, 'x_fa_data'))
    #     if 'y_data' not in os.listdir(test_inputdata_save_path):
    #         os.mkdir(os.path.join(test_inputdata_save_path, 'y_data'))
    #     create_test_data_without_data_partition(test_num, test_inputdata_save_path)


    ### 3. creatr my test data(one by one): ###
    test_save_path = 'ON_mydata/test_clinic_T1+FA_with_data_partition'
    testfile_name = 'test_clinic_T1+FA_with_data_partition'      # test_T1  ...
    if testfile_name not in os.listdir('ON_mydata'):
        os.mkdir(os.path.join('ON_mydata', testfile_name))
    test_savepath = 'ON_mydata/' + testfile_name
    test_dir = os.listdir(test_imgs_path)
    for test_num in test_dir:
        test_name = 'test_' + test_num
        test_inputdata_save_path = os.path.join(test_savepath, test_name)
        os.mkdir(test_inputdata_save_path)
        if 'x_EC_t1_data' not in os.listdir(test_inputdata_save_path):
            os.mkdir(os.path.join(test_inputdata_save_path, 'x_EC_t1_data'))
        if 'x_CL_t1_data' not in os.listdir(test_inputdata_save_path):
            os.mkdir(os.path.join(test_inputdata_save_path, 'x_CL_t1_data'))
        if 'x_CL_fa_data' not in os.listdir(test_inputdata_save_path):
            os.mkdir(os.path.join(test_inputdata_save_path, 'x_CL_fa_data'))
        if 'y_EC_data' not in os.listdir(test_inputdata_save_path):
            os.mkdir(os.path.join(test_inputdata_save_path, 'y_EC_data'))
        if 'y_CL_data' not in os.listdir(test_inputdata_save_path):
            os.mkdir(os.path.join(test_inputdata_save_path, 'y_CL_data'))
        create_test_data_with_data_partition(test_num, test_inputdata_save_path)