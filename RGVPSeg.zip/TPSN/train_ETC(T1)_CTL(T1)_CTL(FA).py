import config_2d
from NetModel import Unet_2d, Unet_plus_2d, MultiResUnet_2d, MultiResUnet_plus_2d, Newnet
import torch, time
from torch import nn, optim
from torch.utils.data import DataLoader
from traindataset_2d import EC_MyTrainDataset, CL_MyTrainDataset
from torchvision.transforms import transforms
from metrics_2d import dice_loss, dice
import os
import setproctitle
setproctitle.setproctitle('RGVPSeg')
# os.environ['CUDA_VISIBLE_DEVICES']='0'
unet2d = Unet_2d.UNet2D  # U-Net
unetplus2d = Unet_plus_2d.UNetPlus2D  # U-Net++

patch_size_w = config_2d.PATCH_SIZE_W
patch_size_h = config_2d.PATCH_SIZE_H
batch_size = config_2d.BATCH_SIZE
n_epochs = config_2d.NUM_EPOCHS
n_classes = config_2d.NUM_CLASSES
image_rows = config_2d.VOLUME_ROWS
image_cols = config_2d.VOLUME_COLS
image_depth = config_2d.VOLUME_DEPS
test_imgs_path = config_2d.test_imgs_path
flag_gpu = config_2d.FLAG_GPU
flag_model = config_2d.MODEL_name

# 是否使用cuda
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# train
def train():
    global model1, model2, model3, losses, train_dataset, train_dataloader, val_dataset, val_dataloader

    lr = 0.002  #
    op_lr = 0.0004  #

    #### 训练集选择
    # For model 1 (ETC_t1)
    ON_train_x_EC_t1_dir = 'ON_mydata/train_clinic_T1+FA/x_EC_t1_data/'
    ON_train_y_EC_dir = 'ON_mydata/train_clinic_T1+FA/y_EC_data/'
    # For model 2,3 (CTL_t1, CTL_fa )
    ON_train_x_CL_t1_dir = 'ON_mydata/train_clinic_T1+FA/x_CL_t1_data/'
    ON_train_x_CL_fa_dir = 'ON_mydata/train_clinic_T1+FA/x_CL_fa_data/'
    ON_train_y_CL_dir = 'ON_mydata/train_clinic_T1+FA/y_CL_data/'

    #### 验证集选择
    # #For model 1 (ETC_t1)
    # ON_val_x_EC_t1_dir = 'ON_mydata/val_T1+FA/x_EC_t1_data/'
    # ON_val_y_EC_dir    = 'ON_mydata/val_T1+FA/y_EC_data/'
    # #For model 2,3 (CTL_t1, CTL_fa )
    # ON_val_x_CL_t1_dir = 'ON_mydata/val_T1+FA/x_CL_t1_data/'
    # ON_val_x_CL_fa_dir = 'ON_mydata/val_T1+FA/x_CL_fa_data/'
    # ON_val_y_CL_dir    = 'ON_mydata/val_T1+FA/y_CL_data/'

    # 损失函数选择
    losses1 = dice_loss()
    losses2 = torch.nn.CrossEntropyLoss()

    if flag_model == 'model_ETC':
        model1 = unet2d(1, 2).to(device)
        train_dataset = EC_MyTrainDataset(ON_train_x_EC_t1_dir, ON_train_y_EC_dir, x_transform=x_transforms,
                                          y_transform=y_transforms)
        # val_dataset   = EC_MyTrainDataset(ON_val_x_EC_t1_dir, ON_val_y_EC_dir, x_transform=x_transforms, y_transform=y_transforms)
        # 是否使用多块GPU
        if flag_gpu == 1:
            model1 = nn.DataParallel(model1).cuda()




    elif flag_model == 'model_CTL':
        model2 = unet2d(1, 2).to(device)
        model3 = unet2d(1, 2).to(device)
        train_dataset = CL_MyTrainDataset(ON_train_x_CL_t1_dir, ON_train_x_CL_fa_dir, ON_train_y_CL_dir,
                                          x_transform=x_transforms, y_transform=y_transforms)
        # val_dataset = CL_MyTrainDataset(ON_val_x_CL_t1_dir, ON_val_x_CL_fa_dir, ON_val_y_CL_dir, x_transform=x_transforms, y_transform=y_transforms)

        # 是否使用多块GPU
        if flag_gpu == 1:
            model2 = nn.DataParallel(model2).cuda()
            model3 = nn.DataParallel(model3).cuda()

    ### 模型载入
    model1.load_state_dict(torch.load(r"weight2/ETC_t1_36epoch_32batch.pth", map_location='cuda'))
    # model2.load_state_dict(torch.load(r"weight3/CTL_t1_63epoch_32batch.pth", map_location='cuda'))
    # model3.load_state_dict(torch.load(r"weight3/CTL_fa_65epoch_32batch.pth", map_location='cuda'))

    train_dataloader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=0)
    # val_dataloader = DataLoader(val_dataset, batch_size=batch_size, shuffle=True, num_workers=0)

    ###----------------------
    #### start train
    print('-' * 30)
    print('Training start...')
    print('-' * 30)
    print('model type   : ', flag_model)
    print('patch size   : ', patch_size_w, 'x', patch_size_h)
    print('batch size   : ', batch_size)
    print('  epoch      : ', n_epochs)
    print('learning rate: ', op_lr)
    print('-' * 30)

    # last_val_epoch_loss = 10

    for epoch in range(0, 100):

        dt_size = len(train_dataloader.dataset)

        ## model1
        epoch_loss_EC_t1 = 0
        epoch_dice_EC_t1 = 0
        loss_EC_t1 = 0

        ## model2
        epoch_loss_CL_t1 = 0
        epoch_dice_CL_t1 = 0
        loss_CL_t1 = 0

        ## model3
        epoch_loss_CL_fa = 0
        epoch_dice_CL_fa = 0
        loss_CL_fa = 0

        step = 0

        if flag_model == 'model_ETC':
            optimizer1 = optim.Adam(model1.parameters(), lr=op_lr)
            model1.train()
            for x1, y in train_dataloader:
                step += 1
                inputs1 = x1.to(device)  # [batch_size, 9, 144, 144]->model(9,2)-> output:[batch_size, 2, 144, 144]
                groundtruth = y.to(device)
                # 梯度清零
                optimizer1.zero_grad()

                outputs1 = model1(inputs1)  # tensor[batch_size, 2, 144, 144]

                net1_predict = outputs1[:, 1, :, :].squeeze()  # label预测值      tensor[batch_size, 1, 144, 144]

                y_truth = groundtruth.squeeze()  # label真实值      tensor[batch_size, 1, 144, 144]

                loss_EC_t1 = losses1(net1_predict, y_truth)+losses2(net1_predict, y_truth)
                label_dice_EC_t1 = dice(net1_predict, y_truth)

                # 反向传播
                loss_EC_t1.backward()

                # 梯度更新
                optimizer1.step()

                epoch_loss_EC_t1 += float(loss_EC_t1.item())
                epoch_dice_EC_t1 += float(label_dice_EC_t1.item())
                step_loss_EC_t1 = loss_EC_t1.item()
                step_dice_EC_t1 = label_dice_EC_t1.item()

                if step % 10 == 0:
                    with open(r'loss/2DUnet_train2_clinic_ETC_t1_' + str(batch_size) + 'batch_step_loss.txt', 'a+') as f:
                        f.writelines('step{0}\t{1} \n'.format(str(step), str(step_loss_EC_t1)))

                print("epoch:%d/%d, %d/%d, loss_ETC_t1:%0.3f, label_dice_ETC_t1:%0.3f, op_lr:%0.5f" % (epoch + 1,
                                                                                                       n_epochs,
                                                                                                       step * train_dataloader.batch_size,
                                                                                                       dt_size,
                                                                                                       step_loss_EC_t1,
                                                                                                       step_dice_EC_t1,
                                                                                                       op_lr))
            model1_path = 'outputs2_clinic_ETC_t1/' + 'ETC_t1_%depoch_%dbatch.pth' % (epoch + 1, batch_size)
            torch.save(model1.state_dict(), model1_path)

            train_epoch_loss_EC_t1 = epoch_loss_EC_t1 / step
            train_epoch_dice_EC_t1 = epoch_dice_EC_t1 / step

            with open(r'loss/2DUnet_val2_clinic_ETC_t1_' + str(batch_size) + 'batch_epoch_loss.txt', 'a+') as f:
                f.writelines('epoch{0}\t{1}\t{2} \n'.format(str(epoch + 1), str(train_epoch_loss_EC_t1), str(train_epoch_dice_EC_t1)))

            print("epoch:%d, train_loss_EC_t1:%0.3f, train_dice_EC_t1:%0.3f" % (epoch + 1, train_epoch_loss_EC_t1, train_epoch_dice_EC_t1))

            print('-' * 30)


        elif flag_model == 'model_CTL':
            optimizer2 = optim.Adam(model2.parameters(), lr=op_lr)
            optimizer3 = optim.Adam(model3.parameters(), lr=op_lr)

            model2.train()
            model3.train()

            for x1, x2, y in train_dataloader:
                # x1: T1(CTL)
                # x2: FA(CTL)
                step += 1
                inputs1 = x1.to(device)  # [batch_size, 9, 144, 144]->model(9,2)-> output:[batch_size, 2, 144, 144]                # inputs2 = x2.to(device)
                inputs2 = x2.to(device)
                groundtruth = y.to(device)
                # 梯度清零
                optimizer2.zero_grad()
                optimizer3.zero_grad()

                outputs_CL_t1 = model2(inputs1)
                outputs_CL_fa = model3(inputs2)

                CL_t1_predict = outputs_CL_t1[:, 1, :, :].squeeze()
                CL_fa_predict = outputs_CL_fa[:, 1, :, :].squeeze()  # label预测值      tensor[batch_size, 1, 144, 144]

                y_truth = groundtruth.squeeze()  # label真实值      tensor[batch_size, 1, 144, 144]

                loss_CL_t1 = losses1(CL_t1_predict, y_truth) + losses2(CL_t1_predict, y_truth)
                loss_CL_fa = losses1(CL_fa_predict, y_truth)+losses2(CL_fa_predict, y_truth)

                label_dice_CL_t1 = dice(CL_t1_predict, y_truth)
                label_dice_CL_fa = dice(CL_fa_predict, y_truth)

                # 反向传播
                loss_CL_t1.backward()
                loss_CL_fa.backward()

                # 梯度更新
                optimizer2.step()
                optimizer3.step()

                epoch_loss_CL_t1 += float(loss_CL_t1.item())
                epoch_dice_CL_t1 += float(label_dice_CL_t1.item())
                step_loss_CL_t1 = loss_CL_t1.item()
                step_dice_CL_t1 = label_dice_CL_t1.item()

                epoch_loss_CL_fa += float(loss_CL_fa.item())
                epoch_dice_CL_fa += float(label_dice_CL_fa.item())
                step_loss_CL_fa = loss_CL_fa.item()
                step_dice_CL_fa = label_dice_CL_fa.item()

                if step % 10 == 0:
                    with open(r'loss/2DUnet_train3_clinic_CTL_t1_' + str(batch_size) + 'batch_step_loss.txt', 'a+') as f:
                        f.writelines('step{0}\t{1} \n'.format(str(step), str(step_loss_CL_t1)))

                    with open(r'loss/2DUnet_train3_clinic_CTL_fa_' + str(batch_size) + 'batch_step_loss.txt', 'a+') as f:
                                        f.writelines('step{0}\t{1} \n'.format(str(step), str(step_loss_CL_fa)))

                print("epoch:%d/%d, %d/%d, loss_CTL_t1:%0.3f, label_dice_CTL_t1:%0.3f,op_lr:%0.5f" % (epoch + 1,
                                                                                                      n_epochs,
                                                                                                      step * train_dataloader.batch_size,
                                                                                                      dt_size,
                                                                                                      step_loss_CL_t1,
                                                                                                      step_dice_CL_t1,
                                                                                                      op_lr))
                print("epoch:%d/%d, %d/%d, loss_CTL_fa:%0.3f, label_dice_CTL_fa:%0.3f,op_lr:%0.5f" % (epoch + 1,
                                                                                                      n_epochs,
                                                                                                      step * train_dataloader.batch_size,
                                                                                                      dt_size,
                                                                                                      step_loss_CL_fa,
                                                                                                      step_dice_CL_fa,
                                                                                                      op_lr))

            model2_path = 'outputs3_clinic_CTL_t1/' + 'CTL_t1_%depoch_%dbatch.pth' % (epoch + 1, batch_size)
            model3_path = 'outputs3_clinic_CTL_fa/' + 'CTL_fa_%depoch_%dbatch.pth' % (epoch + 1, batch_size)
            torch.save(model2.state_dict(), model2_path)
            torch.save(model3.state_dict(), model3_path)

            train_epoch_loss_CL_t1 = epoch_loss_CL_t1 / step
            train_epoch_dice_CL_t1 = epoch_dice_CL_t1 / step

            train_epoch_loss_CL_fa = epoch_loss_CL_fa / step
            train_epoch_dice_CL_fa = epoch_dice_CL_fa / step

            with open(r'loss/2DUnet_val3_clinic_CTL_t1_' + str(batch_size) + 'batch_epoch_loss.txt', 'a+') as f:
                f.writelines('epoch{0}\t{1}\t{2} \n'.format(str(epoch + 1), str(train_epoch_loss_CL_t1), str(train_epoch_dice_CL_t1)))

            with open(r'loss/2DUnet_val3_clinic_CTL_fa_' + str(batch_size) + 'batch_epoch_loss.txt', 'a+') as f:
                f.writelines('epoch{0}\t{1}\t{2} \n'.format(str(epoch + 1), str(train_epoch_loss_CL_fa), str(train_epoch_dice_CL_fa)))

            print("epoch:%d, train_loss_CL_t1:%0.3f,  val_loss_CL_t1:%0.3f, " % (epoch + 1,
                                                                                 train_epoch_loss_CL_t1,
                                                                                 train_epoch_dice_CL_t1,
                                                                                 ))

            print("epoch:%d,  train_loss_CL_fa:%0.3f, val_loss_CL_fa:%0.3f" % (
                                                                                epoch + 1,
                                                                                train_epoch_loss_CL_fa,
                                                                                train_epoch_dice_CL_fa))

            print('-' * 30)


if __name__ == '__main__':

    x_transforms = transforms.Compose([
        transforms.ToPILImage(),
        transforms.RandomHorizontalFlip(0.5),
        transforms.ColorJitter(brightness=0.5, contrast=0.5, hue=0.3),
        transforms.ToTensor(),
        transforms.Normalize((0.5,), (0.5,))
    ])

    y_transforms = transforms.Compose([
        transforms.ToTensor()
    ])

    # 模型保存
    if 'outputs3_clinic_ETC_t1' not in os.listdir(os.curdir):
        os.mkdir('outputs3_clinic_ETC_t1')
    if 'outputs3_clinic_CTL_t1' not in os.listdir(os.curdir):
        os.mkdir('outputs3_clinic_CTL_t1')
    if 'outputs3_clinic_CTL_fa' not in os.listdir(os.curdir):
        os.mkdir('outputs3_clinic_CTL_fa')

    # loss保存
    if 'loss' not in os.listdir(os.curdir):
        os.mkdir('loss')

    ### train test ###
    start_time = time.time()
    train()
    end_time = time.time()
    print("2D train time is {:.3f} mins".format((end_time - start_time) / 60.0))
    print('-' * 30)
    print('model type   : ', flag_model)
    print('patch size   : ', patch_size_w, 'x', patch_size_h)
    print('batch size   : ', batch_size)
    print('  epoch      : ', n_epochs)
    print('-' * 30)
    print("done")
