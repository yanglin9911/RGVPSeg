#import visdom
import config_2d
from NetModel import Unet_2d, Unet_plus_2d, MultiResUnet_2d, MultiResUnet_plus_2d, Newnet
import torch, time
from torch import nn, optim
from torch.utils.data import DataLoader
from traindataset_2d import EC_MyTrainDataset, CL_MyTrainDataset
from torchvision.transforms import transforms
from metrics_2d import dice_loss, dice, dice_l2_loss
import os


unet2d = Unet_2d.UNet2D                             # U-Net
unetplus2d = Unet_plus_2d.UNetPlus2D                # U-Net++
multiresunet2d = MultiResUnet_2d.MultiResUnet2D     # MultiRes U-Net

ournet = Newnet.OurNet2D
fusionnet = Newnet.DatafusionNet

patch_size_w = config_2d.PATCH_SIZE_W
patch_size_h = config_2d.PATCH_SIZE_H
batch_size = config_2d.BATCH_SIZE
n_epochs = config_2d.NUM_EPOCHS
n_classes = config_2d.NUM_CLASSES
image_rows = config_2d.VOLUME_ROWS
image_cols = config_2d.VOLUME_COLS
image_depth = config_2d.VOLUME_DEPS
test_imgs_path = config_2d.test_imgs_path

flag_gpu = config_2d.FLAG_GPU
flag_model = config_2d.MODEL_name

# 是否使用cuda
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# train
def train():
    global model, losses, train_dataset, train_dataloader, val_dataset, val_dataloader

    lr = 0.002 #
    op_lr = 0.0004 #


    # 训练集选择
    #For model 4 (CTL_t1+fa)
    ON_train_x_CL_t1_dir = 'ON_mydata/train1_T1+FA/x_CL_t1_data/'
    ON_train_x_CL_fa_dir = 'ON_mydata/train1_T1+FA/x_CL_fa_data/'
    ON_train_y_CL_dir    = 'ON_mydata/train1_T1+FA/y_CL_data/'

    # 验证集选择
    #For model 4 (CTL_t1+fa)
    # ON_val_x_CL_t1_dir = 'ON_mydata/val_T1+FA/x_CL_t1_data/'
    # ON_val_x_CL_fa_dir = 'ON_mydata/val_T1+FA/x_CL_fa_data/'
    # ON_val_y_CL_dir    = 'ON_mydata/val_T1+FA/y_CL_data/'

    # 损失函数选择
    losses1 = dice_loss()
    losses2 = torch.nn.CrossEntropyLoss()


    model = unet2d(2, 2).to(device)



    if flag_gpu == 1:
        model = nn.DataParallel(model).cuda()


    train_dataset = CL_MyTrainDataset(ON_train_x_CL_t1_dir, ON_train_x_CL_fa_dir, ON_train_y_CL_dir, x_transform=x_transforms, y_transform=y_transforms)
    val_dataset = CL_MyTrainDataset(ON_val_x_CL_t1_dir, ON_val_x_CL_fa_dir, ON_val_y_CL_dir, x_transform=x_transforms, y_transform=y_transforms)

    train_dataloader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=0)
    val_dataloader = DataLoader(val_dataset, batch_size=batch_size, shuffle=True, num_workers=0)


    ### 模型载入
    #model4.load_state_dict(torch.load(r"outputs_CTL_t1fa/CTL_t1fa_20epoch_64batch.pth", map_location='cuda'))

###----------------------
#### start train
    print('-' * 30)
    print('Training start...')
    print('-' * 30)
    print('patch size   : ', patch_size_w, 'x', patch_size_h)
    print('batch size   : ', batch_size)
    print('  epoch      : ', n_epochs)
    print('learning rate: ', op_lr)
    print('-' * 30)

    last_val_epoch_loss = 10

    for epoch in range(0, 100):

        dt_size = len(train_dataloader.dataset)
        epoch_loss_CL_t1fa = 0
        epoch_dice_CL_t1fa = 0
        loss_CL_t1fa = 0
        step = 0

        optimizer = optim.Adam(model.parameters(), lr=op_lr)


        model.train()

        for x1, x2, y in train_dataloader:
            # x1: T1(CTL)
            # x2: FA(CTL)
            step += 1
            inputs1 = x1.to(device)  # [batch_size, 9, 144, 144]->model(9,2)-> output:[batch_size, 2, 144, 144]
            inputs2 = x2.to(device)
            groundtruth = y.to(device)
            # 梯度清零
            optimizer.zero_grad()

            input = torch.cat([inputs1, inputs2], 1)


            outputs = model(input) # FA

            predict = outputs[:, 1, :, :].squeeze()  # label预测值      tensor[batch_size, 1, 144, 144]

            y_truth = groundtruth.squeeze()  # label真实值      tensor[batch_size, 1, 144, 144]

            loss_CL_t1fa = losses(predict, y_truth)

            label_dice_CL_t1fa = dice(predict, y_truth)

            # 反向传播
            loss_CL_t1fa.backward()

            # 梯度更新
            optimizer.step()

            epoch_loss_CL_t1fa += float(loss_CL_t1fa.item())
            epoch_dice_CL_t1fa += float(label_dice_CL_t1fa.item())
            step_loss_CL_t1fa = loss_CL_t1fa.item()
            step_dice_CL_t1fa = label_dice_CL_t1fa.item()

            if step % 10 == 0:
                with open(r'loss/2DUnet_train_CTL_' + str(batch_size) + 'batch_step_loss.txt', 'a+') as f:
                    f.writelines('step{0}\t{1} \n'.format(str(step), str(step_loss_CL_t1fa)))

            print("epoch:%d/%d, %d/%d, loss_CTL:%0.3f, label_dice_CTL:%0.3f, op_lr:%0.5f" % (epoch + 1,
                                                                                                   n_epochs,
                                                                                                   step * train_dataloader.batch_size,
                                                                                                   dt_size,
                                                                                                   step_loss_CL_t1fa,
                                                                                                   step_dice_CL_t1fa,
                                                                                                   op_lr))
        model_path = 'outputs_CTL/' + 'CTL_%depoch_%dbatch.pth' % (epoch + 1, batch_size)
        torch.save(model.state_dict(), model_path)

        train_epoch_loss_CL_t1fa = epoch_loss_CL_t1fa / step
        train_epoch_dice_CL_t1fa = epoch_dice_CL_t1fa / step

        step_val = 0
        val_epoch_loss_CL_t1fa = 0
        val_dt_size_CL_t1fa = len(val_dataloader.dataset)

        ## 验证集
        model.load_state_dict(torch.load(model_path, map_location='cpu'))


        model.eval()
        with torch.no_grad():
            for x1, x2, y in val_dataloader:
                step_val += 1
                inputs1 = x1.to(device)  # [batch_size, 9, 144, 144]->model(9,2)-> output:[batch_size, 2, 144, 144]
                inputs2 = x2.to(device)
                y_truth = y.to(device)

                input = torch.cat([inputs1, inputs2], 1)

                outputs = model(input)  # FA


                val_CL_t1fa_pred = torch.max(outputs, 1)[1].squeeze().float()  # troch.max()[1]，只返回最大值的每个索引

                val_loss_CL_t1fa = 1 - dice(val_CL_t1fa_pred, y_truth)

                val_epoch_loss_CL_t1fa += float(val_loss_CL_t1fa.item())

                print("epoch:%s, %d/%d, val_loss_CTL:%0.3f" % (epoch + 1,
                                                                 step_val * val_dataloader.batch_size,
                                                                 val_dt_size_CL_t1fa,
                                                                 val_loss_CL_t1fa.item()))

            val_epoch_loss_CL_t1fa = val_epoch_loss_CL_t1fa / step_val

            with open(r'loss/2DUnet_val_CTL_' + str(batch_size) + 'batch_epoch_loss.txt', 'a+') as f:
                f.writelines('epoch{0}\t{1}\t{2} \n'.format(str(epoch + 1), str(train_epoch_loss_CL_t1fa),
                                                            str(val_epoch_loss_CL_t1fa)))

            print("epoch:%d, train_loss_CTL:%0.3f,  val_loss_CTL:%0.3f" % (epoch + 1, train_epoch_loss_CL_t1fa, val_epoch_loss_CL_t1fa))

            if val_epoch_loss_CL_t1fa > last_val_epoch_loss:
                loss_nodecrease_num += 1
                if loss_nodecrease_num > 10:
                    return
            else:
                loss_nodecrease_num = 0
            last_val_epoch_loss = val_epoch_loss_CL_t1fa

        print('-' * 30)




if __name__ == '__main__':

    x_transforms = transforms.Compose([
        transforms.ToPILImage(),
        transforms.RandomHorizontalFlip(0.5),
        transforms.ColorJitter(brightness=0.5, contrast=0.5, hue=0.3),
        transforms.ToTensor(),
        transforms.Normalize((0.5,), (0.5,))
    ])

    y_transforms = transforms.Compose([
        transforms.ToTensor()
    ])

    # 模型保存
    if 'outputs_CTL' not in os.listdir(os.curdir):
        os.mkdir('outputs_CTL')

    # loss保存
    if 'loss' not in os.listdir(os.curdir):
        os.mkdir('loss')


    ### train test ###
    start_time = time.time()
    train()
    end_time = time.time()
    print("2D train time is {:.3f} mins".format((end_time - start_time) / 60.0))
    print('-' * 30)
    print('patch size   : ', patch_size_w,'x',patch_size_h)
    print('batch size   : ', batch_size)
    print('  epoch      : ', n_epochs)
    print('-' * 30)
    print("done")




