# import nibabel as nib
# import numpy as np
# import os
#
#
# if __name__ == '__main__':
#     img_dir_name='E:/LSQ/ON_data/128x160x128_102_T1+FA+hist+mask+label/Test_Set/120212/120212'
#     save_path1 = 'E:/LSQ/ON_data/128x160x128_102_T1+FA+hist+mask+label/Test_Set/120212/120212_30.nii.gz'
#     save_path2 = 'E:/LSQ/ON_data/128x160x128_102_T1+FA+hist+mask+label/Test_Set/120212/120212_03.nii.gz'
#
#     # 水平镜像翻转后保存的地址
#     img_t1_name = img_dir_name + '_ON-new_T1.nii.gz'  # T1
#
#     img_t1 = nib.load(img_t1_name)
#     img_t1_data = img_t1.get_data()
#     img_t1_affine = img_t1.get_affine()
#     img_t1_data = np.squeeze(img_t1_data)
#
#     im_30= img_t1_data[:,:,30]
#     t1_patches_nii = nib.Nifti1Image(im_30, img_t1_affine)
#     nib.save(t1_patches_nii, save_path1)
#
#     mi_30 = np.flip(img_t1_data[:,:,30], 0)
#     t1_patches30_nii = nib.Nifti1Image(mi_30, img_t1_affine)
#     nib.save(t1_patches30_nii, save_path2)
#
#
#
# import nibabel as nib
# import numpy as np
# import os
# if __name__ == '__main__':
#     imgs_path='F:/Data/ON_Data/Finish/128x160x128_102_T1+FA+hist+mask+label/Training_Set'
#     images_dir = os.listdir(imgs_path)
#     for img_dir_num in images_dir:
#         img_peaks_name = img_dir_num + '_ON-new_Peaks.nii.gz'  # T1
#         img_peaks_name = os.path.join(imgs_path, img_dir_num, img_peaks_name)
#         img_peaks = nib.load(img_peaks_name)
#         img_peaks_data = img_peaks.get_data()
#         img_peaks_affine = img_peaks.get_affine()
#         img_peaks_data = np.squeeze(img_peaks_data)
#         print(img_peaks_data.shape)
#         print("done")
#     print("done")


# import nibabel as nib
# import numpy as np
# import os
# if __name__ == '__main__':
#     imgs_path='F:/Gwl/XW/07/07_ON-hist.nii.gz'
#     peaks_nonum_nii_path = 'F:/Gwl/XW/07/071_ON-hist.nii.gz'
#     img = nib.load(imgs_path)
#     img_data = img.get_data()
#     img_affine = img.get_affine()
#     img_data_1  = img_data[:,123,:]
#     img_patches_nii = nib.Nifti1Image(img_data_1, img_affine)
#     nib.save(img_patches_nii, peaks_nonum_nii_path)


# import numpy as np
# import nibabel as nib
# import dipy.reconst.dti as dti
# from dipy.io import read_bvals_bvecs
# from dipy.core.gradients import gradient_table
# from dipy.reconst.dti import fractional_anisotropy
# # 求FA值
# if __name__ == '__main__':
#     dwi_path = 'F:/Data/ON_Data/Group1/source/100206/T1w/Diffusion/data.nii.gz'
#     bvals_path = 'F:/Data/ON_Data/Group1/source/100206/T1w/Diffusion/bvals'
#     bvecs_path = 'F:/Data/ON_Data/Group1/source/100206/T1w/Diffusion/bvecs'
#     fa_output = 'F:/Data/ON_Data/Group1/source/100206/T1w/Diffusion/100206_FA.nii.gz'
#     img = nib.load(dwi_path)
#     data = img.get_data()
#     masked_brain = data
#     bvals, bvecs = read_bvals_bvecs(bvals_path, bvecs_path)
#     gtab = gradient_table(bvals, bvecs)
#     tenmodel = dti.TensorModel(gtab)
#     tenfit = tenmodel.fit(masked_brain)
#     FA = fractional_anisotropy(tenfit.evals)
#     FA[np.isnan(FA)] = 0
#     fa_img = nib.Nifti1Image(FA.astype(np.float32), img.affine)
#     nib.save(fa_img, fa_output)



# import nibabel as nib
# import numpy as np
# import os
# if __name__ == '__main__':
#     # 去除FA中大于1小于0的值、nan的值
#     imgs_path='F:/Data/ON_Data/Finish/ON_Data_145x174x145_102/FA/'
#     output = 'F:/Data/ON_Data/Finish/ON_Data_145x174x145_102/New_FA/'
#     images_dir = os.listdir(imgs_path)
#     for img_dir_num in images_dir:
#         img_peaks_name = os.path.join(imgs_path, img_dir_num)
#         img_peaks = nib.load(img_peaks_name)
#         img_peaks_data = img_peaks.get_data()
#         img_peaks_affine = img_peaks.get_affine()
#         img_peaks_data = np.squeeze(img_peaks_data)
#         nan_num = np.isnan(img_peaks_data)
#         img_peaks_data[nan_num]=0
#
#         (x,y,z) = img_peaks_data.shape
#         for i in range(x):
#             for j in range(y):
#                 for k in range(z):
#                     if img_peaks_data[i,j,k]>1:
#                         img_peaks_data[i,j,k] = 1
#                     if img_peaks_data[i,j,k]<0:
#                         img_peaks_data[i,j,k] = 0
#
#         newdata_nonum_nii_path = output +  img_dir_num
#         newdata_patches_nii = nib.Nifti1Image(img_peaks_data, img_peaks_affine)
#         nib.save(newdata_patches_nii, newdata_nonum_nii_path)
#     print("done")




# import os
# import numpy as np
# import nibabel as nib
# import matplotlib.pyplot as plt
# import seaborn as sns
# from torchvision.transforms import transforms
# ###### 数据分布可视化分析
# def data_distribution(imgs_path):
#     totensor_transforms = transforms.ToTensor()
#     num_files = 0
#     images_dir = os.listdir(imgs_path)
#     img_t1_new_data = []
#     img_t1_new_totensor_data = []
#     for img_dir_name in images_dir:
#         num_files = num_files + 1
#         print('Processing: volume {0} / {1} volume images'.format(num_files, len(images_dir)))
#         # T1
#         img_t1_name = os.path.join(imgs_path, img_dir_name)
#         img_t1 = nib.load(img_t1_name)
#         img_t1_data = img_t1.get_data()
#         img_t1_trans_data = img_t1_data.transpose((1,0,2))
#         img_t1_trans_data = img_t1_trans_data.transpose((0,2,1))
#         img_t1_totensor_data = totensor_transforms(img_t1_trans_data)
#
#         for i in range(img_t1_data.shape[0]):
#             for j in range(img_t1_data.shape[1]):
#                 for k in range (img_t1_data.shape[2]):
#                     img_t1_new_data.append(img_t1_data[i,j,k])
#                     img_t1_new_totensor_data.append(img_t1_totensor_data[i,j,k])
#         print(" done! ")
#     plt.figure(figsize=(16,10), dpi= 80)
#     plt.subplot(1, 2, 1)
#     sns.kdeplot(img_t1_new_data, shade=True, color="r", label="T1", alpha=.7)
#     plt.subplot(1, 2, 2)
#     sns.kdeplot(img_t1_new_totensor_data, shade=True, color="r", label="T1-totensor", alpha=.7)
#     plt.title('Density Plot of ON_Data', fontsize=22)
#     plt.legend()
#     plt.show()
# if __name__ == '__main__':
#     test_imgs_path = 'F:/Data/ON_Data/Finish/ON_Data_128x160x128_102/test2/'
#     data_distribution(test_imgs_path)






# import nibabel as nib
# import numpy as np
# import os
# if __name__ == '__main__':
#     imgs_path='F:/Data/ON_Data/Finish/ON_Data_145x174x145_102/T1/'
#     output = 'F:/Data/ON_Data/Finish/ON_Data_145x174x145_102/New_T1/'
#     images_dir = os.listdir(imgs_path)
# ### 归一化
#     for img_dir_num in images_dir:
#         img_name = os.path.join(imgs_path, img_dir_num)
#         img = nib.load(img_name)
#         nii_data = img.get_data()
#         nii_affine = img.get_affine()
#         nii_data = np.squeeze(nii_data)
#         (x, y, z) = nii_data.shape
#         hist_data_z = np.zeros(shape=[145,174,145], dtype='float32')
#         hist_data_y = np.zeros(shape=[145,174,145], dtype='float32')
#         hist_data_x = np.zeros(shape=[145,174,145], dtype='float32')
#
#         for k in range(z):
#             nii_data_z = nii_data[:, :, k]
#             originalMinValue = np.float32(np.min(nii_data_z))
#             originalMaxValue = np.float32(np.max(nii_data_z))
#             originalRange = originalMaxValue - originalMinValue
#             hist_data = (np.float32(nii_data_z) - originalMinValue) / originalRange
#             hist_data_z[:, :, k] = hist_data
#             hist_data_z[:, :, k] = np.array(hist_data_z[:, :, k])
#         for k in range(y):
#             nii_data_y = nii_data[:, k, :]
#             originalMinValue = np.float32(np.min(nii_data_y))
#             originalMaxValue = np.float32(np.max(nii_data_y))
#             originalRange = originalMaxValue - originalMinValue
#             hist_data = (np.float32(nii_data_y) - originalMinValue) / originalRange
#             hist_data_y[:, k, :] = hist_data
#             hist_data_y[:, k, :] = np.array(hist_data_y[:, k, :])
#         for k in range(x):
#             nii_data_x = nii_data[k, :, :]
#             originalMinValue = np.float32(np.min(nii_data_x))
#             originalMaxValue = np.float32(np.max(nii_data_x))
#             originalRange = originalMaxValue - originalMinValue
#             hist_data = (np.float32(nii_data_x) - originalMinValue) / originalRange #归一化到 0，1
#             hist_data_x[k, :, :] = hist_data
#             hist_data_x[k, :, :] = np.array(hist_data_x[k, :, :])
#
#         hist_data_all= ((hist_data_x+hist_data_y+hist_data_z)/3)
#         #hist_data_all = np.trunc(hist_data_all) # 取整
#         img_dir_num= img_dir_num.replace('_ON-T1.nii.gz', '')
#         newdata_nonum_nii_path = output +  img_dir_num + '_ON-new_T1.nii.gz'
#         newdata_patches_nii = nib.Nifti1Image(hist_data_all, nii_affine)
#         nib.save(newdata_patches_nii, newdata_nonum_nii_path)
#     print("done")



# import nibabel as nib
# import numpy as np
# import os
# if __name__ == '__main__':
#     imgs_path='F:\Data\ON_Data\Finish\ON_Data_145x174x145_102\FA/'
#     output = 'F:\Data\ON_Data\Finish\ON_Data_128x160x128_102\FA/'
#     images_dir = os.listdir(imgs_path)
# ### 裁剪
#     for img_dir_num in images_dir:
#         img_name = os.path.join(imgs_path, img_dir_num)
#         img = nib.load(img_name)
#         nii_data = img.get_data()
#         nii_affine = img.get_affine()
#         nii_data = np.squeeze(nii_data)
#         new_data = np.zeros(shape=[128,160,128], dtype='float32')
#         new_data[:,:,:] = nii_data[8:136,7:167,0:128]
#         img_dir_num= img_dir_num.replace('_ON-FA.nii.gz', '')
#         newdata_nonum_nii_path = output +  img_dir_num + '_ON-FA.nii.gz'
#         newdata_patches_nii = nib.Nifti1Image(new_data, nii_affine)
#         nib.save(newdata_patches_nii, newdata_nonum_nii_path)
#     print("done")


# import nibabel as nib
# import numpy as np
# import os
# from skimage import measure
# if __name__ == '__main__':
#     ### 裁剪ETC CTL
#     def find_chiasm_center(allslice_num):
#         center_num = 0
#         length = len(allslice_num)
#         flag_one = 1
#         flag_two = 1
#         first_num = 0
#         last_num = 0
#         # print([len(list(v)) for k, v in itertools.groupby(allslice_num)])
#         # print(allslice_num)
#         for i in range(1, length):
#             if allslice_num[i - 1] == 2 and allslice_num[i] == 1 and flag_one == 1:
#                 flag_one = 0
#                 first_num = i
#                 for j in range(first_num, length):
#                     if allslice_num[j - 1] == 1 and allslice_num[j] == 2 and flag_two == 1:
#                         flag_two = 0
#                         last_num = j
#
#         center_num = first_num + int((last_num - first_num) / 2)
#         return center_num
#
#
#     imgs_path='D:\Brain\Code\DEEP_LEARNING\Segmentation\Pytorch\Final_example\ON_segmentation_2020.7.13_test/2DU-net_indivi\AVP_groundtruth/'
#     imga_pre_path = 'D:\Brain\Code\DEEP_LEARNING\Segmentation\Pytorch\Final_example\ON_segmentation_2020.7.13_test/2DU-net_indivi\predict_T1+FA_AVPmodel/prelabel/'
#     output = 'D:\Brain\Code\DEEP_LEARNING\Segmentation\Pytorch\Final_example\ON_segmentation_2020.7.13_test/2DU-net_indivi\predict_T1+FA_AVPmodel/CTL_label/'
#
#     images_dir = os.listdir(imgs_path)
#     imga_pre_dir = os.listdir(imga_pre_path)
#
#     for img_dir_num in images_dir:
#         img_name = os.path.join(imgs_path, img_dir_num)
#         num = img_dir_num.replace("_ON-label.nii.gz",'')
#
#         for img_pre_num in imga_pre_dir:
#             img_pre_name = os.path.join(imga_pre_path, img_pre_num)
#             pre_num = img_pre_num.replace("_pre-label.nii.gz",'')
#             if num == pre_num :
#                 img = nib.load(img_name)
#                 img_label_data = img.get_data()
#                 nii_affine = img.get_affine()
#                 img_label_data = np.squeeze(img_label_data)
#                 new_data = np.zeros(shape=[128,160,128], dtype='float32')
#
#                 img_pre = nib.load(img_pre_name)
#                 img_pre_data = img_pre.get_data()
#                 img_pre_data = np.squeeze(img_pre_data)
#
#                 X = img_label_data.shape
#                 allnum = []
#
#                 for i in range(X[2]):
#                     nii_label_slice = img_label_data[:, :, i]
#                     # print('slice = ', i)
#                     label, number = measure.label(nii_label_slice, connectivity=2, background=0, return_num=True)
#                     allnum.append(number)
#                 center_num = find_chiasm_center(allnum)
#
#
#
#                 new_data[:,:,center_num:] = img_pre_data[:,:,center_num:]
#                 img_dir_num= img_dir_num.replace('_ON-label.nii.gz', '')
#                 newdata_nonum_nii_path = output +  img_dir_num + '_pre-label.nii.gz'
#                 newdata_patches_nii = nib.Nifti1Image(new_data, nii_affine)
#                 nib.save(newdata_patches_nii, newdata_nonum_nii_path)
#     print("done")




# import torch
# a = torch.randn(3,2,5,5)
# b=torch.max(a,1)
# c=torch.max(a,1)[1].squeeze()
# d = c.cpu().numpy().astype(int)
# print('done')


# import nibabel as nib
# import numpy as np
# import os
# if __name__ == '__main__':
#     imgs_path='F:/Data/ON_Data/XuanWu/01/Test/'
#     output = 'F:/Data/ON_Data/XuanWu/01/Test/'
#     images_dir = os.listdir(imgs_path)
# ### 归一化
#     for img_dir_num in images_dir:
#         img_name = os.path.join(imgs_path, img_dir_num)
#         img = nib.load(img_name)
#         nii_data = img.get_data()
#         nii_affine = img.get_affine()
#         nii_data = np.squeeze(nii_data)
#         (x, y, z) = nii_data.shape
#         hist_data_z = np.zeros(shape=[256,256,192], dtype='float32')
#         hist_data_y = np.zeros(shape=[256,256,192], dtype='float32')
#         hist_data_x = np.zeros(shape=[256,256,192], dtype='float32')
#
#         for k in range(z):
#             nii_data_z = nii_data[:, :, k]
#             originalMinValue = np.float32(np.min(nii_data_z))
#             originalMaxValue = np.float32(np.max(nii_data_z))
#             originalRange = originalMaxValue - originalMinValue
#             hist_data = (np.float32(nii_data_z) - originalMinValue) / originalRange
#             hist_data_z[:, :, k] = hist_data
#             hist_data_z[:, :, k] = np.array(hist_data_z[:, :, k])
#         for k in range(y):
#             nii_data_y = nii_data[:, k, :]
#             originalMinValue = np.float32(np.min(nii_data_y))
#             originalMaxValue = np.float32(np.max(nii_data_y))
#             originalRange = originalMaxValue - originalMinValue
#             hist_data = (np.float32(nii_data_y) - originalMinValue) / originalRange
#             hist_data_y[:, k, :] = hist_data
#             hist_data_y[:, k, :] = np.array(hist_data_y[:, k, :])
#         for k in range(x):
#             nii_data_x = nii_data[k, :, :]
#             originalMinValue = np.float32(np.min(nii_data_x))
#             originalMaxValue = np.float32(np.max(nii_data_x))
#             originalRange = originalMaxValue - originalMinValue
#             hist_data = (np.float32(nii_data_x) - originalMinValue) / originalRange #归一化到 0，1
#             hist_data_x[k, :, :] = hist_data
#             hist_data_x[k, :, :] = np.array(hist_data_x[k, :, :])
#
#         hist_data_all= ((hist_data_x+hist_data_y+hist_data_z)/3)
#         #hist_data_all = np.trunc(hist_data_all) # 取整
#         img_dir_num= img_dir_num.replace('.nii.gz', '')
#         newdata_nonum_nii_path = output +  img_dir_num + '.new_T1.nii.gz'
#         newdata_patches_nii = nib.Nifti1Image(hist_data_all, nii_affine)
#         nib.save(newdata_patches_nii, newdata_nonum_nii_path)
#     print("done")



# import nibabel as nib
# import numpy as np
# import os
# from skimage import measure
# if __name__ == '__main__':
#     imgs_path='E:\LSQ\ON_data\ON_Data_128x160x128_102\All/test/'
#     images_dir = os.listdir(imgs_path)
#
#     for img_dir_name in images_dir:
#         # label
#         img_label_name = img_dir_name + '_ON-label.nii.gz'
#         img_label_name = os.path.join(imgs_path, img_dir_name, img_label_name)
#         # mask
#         img_mask_name = img_dir_name + '_ON-mask.nii.gz'
#         img_mask_name = os.path.join(imgs_path, img_dir_name, img_mask_name)
#
#         img_label = nib.load(img_label_name)
#         img_label_data = img_label.get_data()
#
#         img_mask = nib.load(img_mask_name)
#         img_mask_data = img_mask.get_data()
#         img_mask_affine = img_mask.get_affine()
#         img_mask_data = np.squeeze(img_mask_data)
#
#         X = img_label_data.shape
#
#         allnum = []
#         zero_num = []
#         nonzero_num = []
#         flag = 0
#         fu_zhi = 0
#         for i in range(X[2]):
#             nii_label_slice = img_label_data[:, :, i]
#             label, num = measure.label(nii_label_slice, connectivity=2, background=0, return_num=True)
#             if num != 0:
#                 flag = 1
#                 nonzero_num.append(num)
#             if num == 0 and flag == 0:
#                 zero_num.append(num)
#             allnum.append(num)
#         start = len(zero_num)  # 视神经开始所在层数
#         label_num = len(nonzero_num)  # 视神经总共的层数
#         end = start + label_num  # 视神经结 束所在层数
#         slice_start = start - int(label_num / 2)  # 视神经往上扩张
#         if slice_start<0:
#             fu_zhi = 0 - slice_start
#             slice_start = 0
#         slice_end = end + int(label_num / 2) + fu_zhi # 视神经往下扩张
#
#         new_data = np.zeros(shape=[128,160,128], dtype='float32')
#
#         new_data[:,:,slice_start:slice_end] = img_mask_data[:,:,slice_start:slice_end]
#         img_new_name = img_dir_name + '_ON-new_mask.nii.gz'
#         img_new_name = os.path.join(imgs_path, img_dir_name, img_new_name)
#
#         newdata_patches_nii = nib.Nifti1Image(new_data, img_mask_affine)
#         nib.save(newdata_patches_nii, img_new_name)
#     print("done")


# ## 找到视交叉位置
# def find_chiasm_center(allslice_num):
#     center_num = 0
#     length = len(allslice_num)
#     flag_one = 1
#     flag_two = 1
#     first_num = 0
#     last_num = 0
#
#     for i in range(1,length):
#         if allslice_num[i-1] == 2 and allslice_num[i] == 1 and flag_one==1 :
#             flag_one =0
#             first_num = i
#             for j in range(first_num,length):
#                 if allslice_num[j - 1] == 1 and allslice_num[j] == 2 and flag_two == 1:
#                     flag_two = 0
#                     last_num =j
#
#     center_num = first_num + int((last_num - first_num) / 2)
#     return center_num





# import nibabel as nib
# import SimpleITK as sitk
# from matplotlib import pyplot as plt
# import numpy as np
# import skimage.io as io
# import os
# if __name__ == '__main__':
#     imgs_path='F:\Data\ON_Data\Finish\ON_Data_128x160x128_102\T1/100206_ON-T1.nii.gz'
#
#     itk_img = sitk.ReadImage(imgs_path)
#     img = sitk.GetArrayFromImage(itk_img).transpose(2, 1, 0)
#     spacing = itk_img.GetSpacing()
#     # spacing 翻转，为了和普通图片读取的depth, width, height对应
#     spacing_reverse = spacing[::-1]
#
#     plt.imshow(img[:, :, 35], cmap='gray')
#     plt.show()
#     print('done')


import nibabel as nib
import numpy as np
import os
if __name__ == '__main__':

    imgs_path_OK='/tmp/LSQ/2D_OurNet/ON_mydata_1/train_T1+FA/x_CL_t1_data/'
    imgs_path_notOK='/tmp/LSQ/2D_OurMethod_8.27/ON_mydata/train_T1+FA/x_CL_t1_data/'
    images_dir_1 = os.listdir(imgs_path_OK)
    images_dir_2 = os.listdir(imgs_path_notOK)

    for img_dir_num in images_dir_2:

        # img1 = nib.load(imgs_path_OK+img_dir_num)
        # img1_data = img1.get_data()
        # print(img1_data.dtype)

        img2 = nib.load(imgs_path_notOK+img_dir_num)
        img2_data = img2.get_data()
        print(img2_data.dtype)

        print("done")
    print("done")