import config_2d
from NetModel import Unet_2d, Unet_plus_2d, MultiResUnet_2d, MultiResUnet_plus_2d,Newnet
import torch
from torch import nn
from torch.utils.data import DataLoader
from traindataset_2d import EC_MyTrainDataset, CL_MyTrainDataset
import os
from torchvision.transforms import transforms
import numpy as np
import time
import nibabel as nib
from skimage import measure


unet2d = Unet_2d.UNet2D                             # U-Net
unetplus2d = Unet_plus_2d.UNetPlus2D                # U-Net++
multiresunet2d = MultiResUnet_2d.MultiResUnet2D     # MultiRes U-Net
fusionnet=Newnet.DatafusionNet

patch_size_w = config_2d.PATCH_SIZE_W
patch_size_h = config_2d.PATCH_SIZE_H
flag_gpu = config_2d.FLAG_GPU

batch_size = config_2d.BATCH_SIZE
n_epochs = config_2d.NUM_EPOCHS
n_classes = config_2d.NUM_CLASSES
image_rows = config_2d.VOLUME_ROWS
image_cols = config_2d.VOLUME_COLS
image_depth = config_2d.VOLUME_DEPS
test_imgs_path = config_2d.test_imgs_path
test_extraction_step = config_2d.TEST_EXTRACTION_STEP

# 是否使用cuda
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def find_chiasm_center(allslice_num):
    center_num = 0
    length = len(allslice_num)
    flag_one = 1
    flag_two = 1
    first_num = 0
    last_num = 0
    #print([len(list(v)) for k, v in itertools.groupby(allslice_num)])
    #print(allslice_num)
    for i in range(1,length):
        if allslice_num[i-1] == 2 and allslice_num[i] == 1 and flag_one==1 :
            flag_one =0
            first_num = i
            for j in range(first_num,length):
                if allslice_num[j - 1] == 1 and allslice_num[j] == 2 and flag_two == 1:
                    flag_two = 0
                    last_num =j

    center_num = first_num + int((last_num - first_num) / 2)
    return center_num


# 通过模型预测结果
def predict(img_dir, predict_dir, imgs_num):
    global model1, model2, model3, model4, test_dataset, test_dataloader
    model1_path = 'bestmodel/ETC_T1.pth'
    # model2_path = 'best_model/model2_CTL_T1.pth'
    # model3_path = 'best_model/model3_CTL_FA.pth'
    # model4_path = 'best_model/model4_CTL_T1+FA.pth'
    model5_path = 'bestmodel/CTL_T1+FA.pth'


    # 模型选择
    model1 = unet2d(1, 2).to(device)
    # model2 = unet2d(1, 2).to(device)
    # model3 = unet2d(1, 2).to(device)
    # model4 = fusionnet(4,2).to(device)
    model5 = unet2d(2, 2).to(device)

    model1 = nn.DataParallel(model1).cuda()
    # model3 = nn.DataParallel(model3).cuda()
    # model4 = nn.DataParallel(model4).cuda()
    model5 = nn.DataParallel(model5).cuda()


    ON_test_x_EC_t1_dir = img_dir + 'x_EC_t1_data/'
    ON_test_x_CL_t1_dir = img_dir + 'x_CL_t1_data/'
    ON_test_x_CL_fa_dir = img_dir + 'x_CL_fa_data/'
    ON_test_y_EC_dir = img_dir + 'y_EC_data/'
    ON_test_y_CL_dir = img_dir + 'y_CL_data/'

    model1.load_state_dict(torch.load(model1_path, map_location='cpu'))
    # model2.load_state_dict(torch.load(model2_path, map_location='cpu'))
    # model3.load_state_dict(torch.load(model3_path, map_location='cpu'))
    # model4.load_state_dict(torch.load(model4_path, map_location='cpu'))
    model5.load_state_dict(torch.load(model5_path, map_location='cpu'))

    test_EC_dataset = EC_MyTrainDataset(ON_test_x_EC_t1_dir, ON_test_y_EC_dir, x_transform=x_transforms, y_transform=y_transforms)
    test_EC_dataloader = DataLoader(test_EC_dataset, batch_size=1, shuffle=False, num_workers=0)

    test_CL_dataset = CL_MyTrainDataset(ON_test_x_CL_t1_dir, ON_test_x_CL_fa_dir, ON_test_y_CL_dir, x_transform=x_transforms, y_transform=y_transforms)
    test_CL_dataloader = DataLoader(test_CL_dataset, batch_size=1, shuffle=False, num_workers=0)


    EC_patch_num = 0
    CL_patch_num = 0
    model1.eval()
    # model2.eval()
    # model3.eval()
    # model4.eval()
    model5.eval()

    with torch.no_grad():
        for x1, y in test_EC_dataloader:
            inputs1 = x1.to(device)  # [batch_size, 9, 144, 144]->model(9,2)-> output:[batch_size, 2, 144, 144]
            outputs1= model1(inputs1)
            pred = torch.max(outputs1, 1)[1].squeeze()  # troch.max()[1]，只返回最大值的每个索引
            pred_result = pred.cpu().numpy().astype(int)

            if EC_patch_num == 0:
                test_data_path = ON_test_x_EC_t1_dir + 'x_EC_t1-data_0.nii.gz'
                test_img = nib.load(test_data_path)
                test_img_affine = test_img.get_affine()
            pred_patches_nii = nib.Nifti1Image(pred_result, test_img_affine)
            pred_nii_path = predict_dir + 'pre_' + str(EC_patch_num) + '.nii.gz'
            nib.save(pred_patches_nii, pred_nii_path)
            EC_patch_num += 1
        print('Sum of 2D EC blocks is: {0}'.format(EC_patch_num))

    with torch.no_grad():
        for x1, x2, y in test_CL_dataloader:
            inputs1 = x1.to(device)  # [batch_size, 9, 144, 144]->model(9,2)-> output:[batch_size, 2, 144, 144]
            inputs2 = x2.to(device)

            # outputs1= model2(inputs1)
            # outputs2 = model3(inputs2)
            input = torch.cat([inputs1, inputs2], 1)


            CTL_ouputs = model5(input) # FA


            CTL_pred = torch.max(CTL_ouputs, 1)[1].squeeze()  # troch.max()[1]，只返回最大值的每个索引
            CTL_pred_result = CTL_pred.cpu().numpy().astype(int)

            if CL_patch_num == 0:
                test_data_path = ON_test_x_CL_t1_dir + 'x_CL_t1-data_0.nii.gz'
                test_img = nib.load(test_data_path)
                test_img_affine = test_img.get_affine()
            pred_patches_nii = nib.Nifti1Image(CTL_pred_result, test_img_affine)
            pred_nii_path = predict_dir + 'pre_' + str(EC_patch_num + CL_patch_num) + '.nii.gz'
            nib.save(pred_patches_nii, pred_nii_path)
            CL_patch_num += 1
        print('Sum of 2D CL blocks is: {0}'.format(CL_patch_num))

    #pre_nii_num = len(os.listdir(predict_dir))
    #print(pre_nii_num)
    pre_seg_final = np.zeros((image_rows, image_cols, image_depth))

    # source.nii
    img_name = imgs_num + '_ON-T1.nii.gz'
    img_name = os.path.join(test_imgs_path, imgs_num, img_name)
    img = nib.load(img_name)
    img_data = img.get_data()
    img_affine = img.get_affine()

    # label.nii
    img_label_name = imgs_num + '_ON-label.nii.gz'
    img_label_name = os.path.join(test_imgs_path, imgs_num, img_label_name)
    img_label = nib.load(img_label_name)
    img_label_data = img_label.get_data()
    img_label_data = np.squeeze(img_label_data)

    X = img_label_data.shape
    allnum = []
    step = 0

    for i in range(X[2]):
        nii_label_slice = img_label_data[:, :, i]
        # print('slice = ', i)
        label, number = measure.label(nii_label_slice, connectivity=2, background=0, return_num=True)
        allnum.append(number)
    center_num = find_chiasm_center(allnum)

    for iSlice in range(0, X[2]):
        #if np.count_nonzero(img_mask_data[:, :, iSlice]) and np.count_nonzero(img_data[:, :, iSlice]):
        pre_name = 'pre_' + str(step) + '.nii.gz'
        pre_name = os.path.join(predict_dir, pre_name)
        pre_seg_temp = nib.load(pre_name)
        pre_seg_temp_data = pre_seg_temp.get_data()
        #print('pre_name', pre_name)
        step+=1

        for i in range(0, patch_size_w):
            for j in range(0, patch_size_h):
                pre_seg_final[i][j][iSlice] = pre_seg_temp_data[i][j]


    pre_seg_final = nib.Nifti1Image(pre_seg_final, img_affine)
    pre_sge_finalname = 'pre_final-label.nii.gz'
    pre_sge_final_savepath = os.path.join(predict_dir, pre_sge_finalname)
    nib.save(pre_seg_final, pre_sge_final_savepath)






if __name__ == '__main__':

    x_transforms = transforms.Compose([
        transforms.ToPILImage(),
        transforms.ToTensor(),
        transforms.Normalize((0.5,), (0.5,))
    ])
    x_peaks_transforms = transforms.ToTensor()
    y_transforms = transforms.ToTensor()

    # 预测结果保存
    pre_file_name = 'predict_T1+FA_fusion_with_data_partition'
    if pre_file_name not in os.listdir(os.curdir):
        os.mkdir(pre_file_name)


    start_time = time.time()

    test_dir = os.listdir(test_imgs_path)
    for test_num in test_dir:
        test_name  = 'test_' + test_num
        test_pre_name  = 'test_result_' + test_num
        os.mkdir(os.path.join(pre_file_name, test_pre_name))

        test_input_path = 'ON_mydata/test_T1+FA_with_data_partition/'+ test_name +'/'
        test_result_path = pre_file_name+ '/' + test_pre_name + '/'
        ## 1.预测并合成
        predict(test_input_path, test_result_path, test_num)

    end_time = time.time()
    print("2D train time is {:.3f} s".format((end_time - start_time) ))