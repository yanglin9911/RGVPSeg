import config_2d
from NetModel import Unet_2d, Unet_plus_2d, MultiResUnet_2d, MultiResUnet_plus_2d,Newnet
import torch
from torch import nn
from torch.utils.data import DataLoader
from traindataset_withoutchiasm import MyTrainDataset
import os
from torchvision.transforms import transforms
import numpy as np
import time
import nibabel as nib
from skimage import measure


unet2d = Unet_2d.UNet2D                             # U-Net
unetplus2d = Unet_plus_2d.UNetPlus2D                # U-Net++
multiresunet2d = MultiResUnet_2d.MultiResUnet2D     # MultiRes U-Net
ournet2d = MultiResUnet_plus_2d.MultiResUnetPlus2D  # MultiRes U-Net++
fusionnet=Newnet.DatafusionNet

patch_size_w = config_2d.PATCH_SIZE_W
patch_size_h = config_2d.PATCH_SIZE_H
flag_gpu = config_2d.FLAG_GPU

batch_size = config_2d.BATCH_SIZE
n_epochs = config_2d.NUM_EPOCHS
n_classes = config_2d.NUM_CLASSES
image_rows = config_2d.VOLUME_ROWS
image_cols = config_2d.VOLUME_COLS
image_depth = config_2d.VOLUME_DEPS
test_imgs_path = config_2d.test_imgs_path
test_extraction_step = config_2d.TEST_EXTRACTION_STEP
# 是否使用cuda
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# 通过模型预测结果
def predict(img_dir, predict_dir, imgs_num):
    global model1, model2, model3, model4, test_dataset, test_dataloader
    model1_path = 'bestmodel/ETC_T1.pth'
    model2_path = 'bestmodel/CTL_t1.pth'
    model3_path = 'bestmodel/CTL_fa.pth'
    model4_path = 'bestmodel/CTL_t1fa.pth'


    # 模型选择
    model1 = unet2d(1, 2).to(device)
    model2 = unet2d(1, 2).to(device)
    model3 = unet2d(1, 2).to(device)
    model4 = fusionnet(4,2).to(device)


    model1 = nn.DataParallel(model1).cuda()
    model2 = nn.DataParallel(model2).cuda()
    model3 = nn.DataParallel(model3).cuda()
    model4 = nn.DataParallel(model4).cuda()


    ON_test_x_t1_dir = img_dir + 'x_t1_data/'
    ON_test_x_fa_dir = img_dir + 'x_fa_data/'
    ON_test_y_dir = img_dir + 'y_data/'

    model1.load_state_dict(torch.load(model1_path, map_location='cpu'))
    model2.load_state_dict(torch.load(model2_path, map_location='cpu'))
    model3.load_state_dict(torch.load(model3_path, map_location='cpu'))
    model4.load_state_dict(torch.load(model4_path, map_location='cpu'))


    test_dataset = MyTrainDataset(ON_test_x_t1_dir, ON_test_x_fa_dir, ON_test_y_dir,
                                  x_transform=x_transforms,
                                  y_transform=y_transforms)

    test_dataloader = DataLoader(test_dataset, batch_size=1, shuffle=False, num_workers=0)


    EC_T1_patch_num = 0
    CL_T1_patch_num = 0
    CL_FA_patch_num = 0
    CL_T1_FA_patch_num = 0

    model1.eval()  # T1
    model2.eval()  # T1
    model3.eval()  # FA
    model4.eval()  # T1+FA


    with torch.no_grad():
        for x1, x2, y in test_dataloader:
            inputs1 = x1.to(device)  # [batch_size, 9, 144, 144]->model(9,2)-> output:[batch_size, 2, 144, 144]
            inputs2 = x2.to(device)

            outputs1 = model1(inputs1) # EC-T1
            outputs2 = model2(inputs1) # CL-T1
            outputs3 = model3(inputs2) # CL-FA
            outputs4 = model4(outputs2, outputs3)

            EC_T1_pred = torch.max(outputs1, 1)[1].squeeze()
            CL_T1_pred = torch.max(outputs2, 1)[1].squeeze()
            CL_FA_pred = torch.max(outputs3, 1)[1].squeeze()
            CL_T1_FA_pred = torch.max(outputs4, 1)[1].squeeze()


            EC_T1_pred_result = EC_T1_pred.cpu().numpy().astype(int)
            CL_T1_pred_result = CL_T1_pred.cpu().numpy().astype(int)
            CL_FA_pred_result = CL_FA_pred.cpu().numpy().astype(int)
            CL_T1_FA_pred_result = CL_T1_FA_pred.cpu().numpy().astype(int)


            if EC_T1_patch_num == 0:
                test_data_path = ON_test_x_t1_dir + 'x_t1-data_0.nii.gz'
                test_img = nib.load(test_data_path)
                test_img_affine = test_img.get_affine()
            pred_patches_nii = nib.Nifti1Image(EC_T1_pred_result, test_img_affine)
            pred_nii_path = predict_dir + 'EC_T1/' + 'pre_' + str(EC_T1_patch_num) + '.nii.gz'
            nib.save(pred_patches_nii, pred_nii_path)
            EC_T1_patch_num += 1

            if CL_T1_patch_num == 0:
                test_data_path = ON_test_x_t1_dir + 'x_t1-data_0.nii.gz'
                test_img = nib.load(test_data_path)
                test_img_affine = test_img.get_affine()
            pred_patches_nii = nib.Nifti1Image(CL_T1_pred_result, test_img_affine)
            pred_nii_path = predict_dir + 'CL_T1/' + 'pre_' + str(CL_T1_patch_num) + '.nii.gz'
            nib.save(pred_patches_nii, pred_nii_path)
            CL_T1_patch_num += 1

            if CL_FA_patch_num == 0:
                test_data_path = ON_test_x_t1_dir + 'x_t1-data_0.nii.gz'
                test_img = nib.load(test_data_path)
                test_img_affine = test_img.get_affine()
            pred_patches_nii = nib.Nifti1Image(CL_FA_pred_result, test_img_affine)
            pred_nii_path = predict_dir + 'CL_FA/' + 'pre_' + str(CL_FA_patch_num) + '.nii.gz'
            nib.save(pred_patches_nii, pred_nii_path)
            CL_FA_patch_num += 1

            if CL_T1_FA_patch_num == 0:
                test_data_path = ON_test_x_t1_dir + 'x_t1-data_0.nii.gz'
                test_img = nib.load(test_data_path)
                test_img_affine = test_img.get_affine()
            pred_patches_nii = nib.Nifti1Image(CL_T1_FA_pred_result, test_img_affine)
            pred_nii_path = predict_dir + 'CL_T1_FA/' + 'pre_' + str(CL_T1_FA_patch_num) + '.nii.gz'
            nib.save(pred_patches_nii, pred_nii_path)
            CL_T1_FA_patch_num += 1


    pre_EC_T1_seg_final = np.zeros((image_rows, image_cols, image_depth))
    pre_CL_T1_seg_final = np.zeros((image_rows, image_cols, image_depth))
    pre_CL_FA_seg_final = np.zeros((image_rows, image_cols, image_depth))
    pre_CL_T1_FA_seg_final = np.zeros((image_rows, image_cols, image_depth))
    pre_AVP_T1_FA_seg_final = np.zeros((image_rows, image_cols, image_depth))


    # source.nii
    img_name = imgs_num + '_ON-new_T1.nii.gz'

    img_name = os.path.join(test_imgs_path, imgs_num, img_name)
    img = nib.load(img_name)
    img_data = img.get_data()
    img_affine = img.get_affine()


    # label.nii
    img_label_name = imgs_num + '_ON-label.nii.gz'
    img_label_name = os.path.join(test_imgs_path, imgs_num, img_label_name)
    img_label = nib.load(img_label_name)
    img_label_data = img_label.get_data()
    img_label_data = np.squeeze(img_label_data)

    X = img_label_data.shape

    step = 0


    for iSlice in range(0, X[2]):
        pre_name = 'pre_' + str(step) + '.nii.gz'

        EC_T1_pre_name = os.path.join(predict_dir,'EC_T1',pre_name)
        CL_T1_pre_name = os.path.join(predict_dir, 'CL_T1', pre_name)
        CL_FA_pre_name = os.path.join(predict_dir, 'CL_FA', pre_name)
        CL_T1_FA_pre_name = os.path.join(predict_dir, 'CL_T1_FA', pre_name)


        EC_T1_pre_seg_temp = nib.load(EC_T1_pre_name)
        EC_T1_pre_seg_temp_data = EC_T1_pre_seg_temp.get_data()

        CL_T1_pre_seg_temp = nib.load(CL_T1_pre_name)
        CL_T1_pre_seg_temp_data = CL_T1_pre_seg_temp.get_data()

        CL_FA_pre_seg_temp = nib.load(CL_FA_pre_name)
        CL_FA_pre_seg_temp_data = CL_FA_pre_seg_temp.get_data()

        CL_T1_FA_pre_seg_temp = nib.load(CL_T1_FA_pre_name)
        CL_T1_FA_pre_seg_temp_data = CL_T1_FA_pre_seg_temp.get_data()



        step+=1
        for i in range(0, patch_size_w):
            for j in range(0, patch_size_h):
                pre_EC_T1_seg_final[i][j][iSlice] = EC_T1_pre_seg_temp_data[i][j]
                pre_CL_T1_seg_final[i][j][iSlice] = CL_T1_pre_seg_temp_data[i][j]
                pre_CL_FA_seg_final[i][j][iSlice] = CL_FA_pre_seg_temp_data[i][j]
                pre_CL_T1_FA_seg_final[i][j][iSlice] = CL_T1_FA_pre_seg_temp_data[i][j]

                if EC_T1_pre_seg_temp_data[i][j]==1 or CL_T1_FA_pre_seg_temp_data[i][j]==1:
                    pre_AVP_T1_FA_seg_final[i][j][iSlice] = 1




    EC_T1_pre_seg_final = nib.Nifti1Image(pre_EC_T1_seg_final, img_affine)
    pre_sge_finalname = 'pre_final-label.nii.gz'
    EC_T1_pre_sge_final_savepath = os.path.join(predict_dir, 'EC_T1', pre_sge_finalname)
    nib.save(EC_T1_pre_seg_final, EC_T1_pre_sge_final_savepath)

    CL_T1_pre_seg_final = nib.Nifti1Image(pre_CL_T1_seg_final, img_affine)
    CL_T1_pre_sge_final_savepath = os.path.join(predict_dir, 'CL_T1', pre_sge_finalname)
    nib.save(CL_T1_pre_seg_final, CL_T1_pre_sge_final_savepath)

    CL_FA_pre_seg_final = nib.Nifti1Image(pre_CL_FA_seg_final, img_affine)
    CL_FA_pre_sge_final_savepath = os.path.join(predict_dir, 'CL_FA', pre_sge_finalname)
    nib.save(CL_FA_pre_seg_final, CL_FA_pre_sge_final_savepath)

    CL_T1_FA_pre_seg_final = nib.Nifti1Image(pre_CL_T1_FA_seg_final, img_affine)
    CL_T1_FA_pre_sge_final_savepath = os.path.join(predict_dir, 'CL_T1_FA', pre_sge_finalname)
    nib.save(CL_T1_FA_pre_seg_final, CL_T1_FA_pre_sge_final_savepath)

    AVP_T1_FA_pre_seg_final = nib.Nifti1Image(pre_AVP_T1_FA_seg_final, img_affine)
    AVP_T1_FA_pre_sge_final_savepath = os.path.join(predict_dir, 'AVP_T1_FA', pre_sge_finalname)
    nib.save(AVP_T1_FA_pre_seg_final, AVP_T1_FA_pre_sge_final_savepath)




if __name__ == '__main__':

    x_transforms = transforms.Compose([
        transforms.ToPILImage(),
        transforms.ToTensor(),
        transforms.Normalize((0.5,), (0.5,))
    ])
    x_peaks_transforms = transforms.ToTensor()
    y_transforms = transforms.ToTensor()

    # 预测结果保存
    pre_file_name = 'predict_t1fa_fusion_without_data_partition'
    if pre_file_name not in os.listdir(os.curdir):
        os.mkdir(pre_file_name)


    start_time = time.time()

    test_dir = os.listdir(test_imgs_path)
    for test_num in test_dir:
        test_name  = 'test_' + test_num
        test_pre_name  = 'test_result_' + test_num
        os.mkdir(os.path.join(pre_file_name, test_pre_name))
        os.mkdir(os.path.join(pre_file_name, test_pre_name,'EC_T1'))
        os.mkdir(os.path.join(pre_file_name, test_pre_name, 'CL_T1'))
        os.mkdir(os.path.join(pre_file_name, test_pre_name, 'CL_FA'))
        os.mkdir(os.path.join(pre_file_name, test_pre_name, 'CL_T1_FA'))
        os.mkdir(os.path.join(pre_file_name, test_pre_name, 'AVP_T1_FA'))

        test_input_path = 'ON_mydata/test_T1+FA_without_data_partition/'+ test_name +'/'
        test_result_path = pre_file_name+ '/' + test_pre_name + '/'
        ## 1.预测并合成
        predict(test_input_path, test_result_path, test_num)

    end_time = time.time()
    print("2D train time is {:.3f} s".format((end_time - start_time) ))