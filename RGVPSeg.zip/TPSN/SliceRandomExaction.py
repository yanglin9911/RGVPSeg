import os, random, shutil

def train_EC_moveFile(fileDir_x, fileDir_y):
        pathDir_x = os.listdir(fileDir_x)    #取图片的原始路径
        filenumber = len(pathDir_x)
        rate = 0.4481    # 4968 x 0.4481 = 2226
        picknumber = int(filenumber * rate) #按照rate比例从文件夹中取一定数量图片
        print('EC picknumber=',picknumber)
        sample = random.sample(pathDir_x, picknumber)  #随机选取picknumber数量的样本图片
        ptahtarDir_x = os.listdir(tarDir_EC_t1_x)
        tar_num = len(ptahtarDir_x)
        for name in sample:
            x_name = name
            filename_num = name.replace('x_EC_t1-data_','')
            filename_num = filename_num.replace('.nii.gz','')
            y_name = 'y_EC-data_' + filename_num + '.nii.gz'

            x_tar_name = 'x_EC_t1-data_' +  str(tar_num) + '.nii.gz'
            y_tar_name = 'y_EC-data_' + str(tar_num) + '.nii.gz'

            shutil.copy(fileDir_x + x_name, tarDir_EC_t1_x + x_tar_name)
            shutil.copy(fileDir_y + y_name, tarDir_EC_y + y_tar_name)

            tar_num += 1
        return


def train_CL_moveFile(fileDir_x_t1, fileDir_x_fa, fileDir_y):
    pathDir_x = os.listdir(fileDir_x_t1)  # 取图片的原始路径
    filenumber = len(pathDir_x)
    rate = 0.145253  # 12048 x 0.145253 = 1750
    picknumber = int(filenumber * rate)  # 按照rate比例从文件夹中取一定数量图片
    print('CL picknumber=', picknumber)
    sample = random.sample(pathDir_x, picknumber)  # 随机选取picknumber数量的样本图片
    ptahtarDir_x = os.listdir(tarDir_CL_t1_x)
    tar_num = len(ptahtarDir_x)
    for name in sample:
        x_t1_name = name
        filename_num = name.replace('x_CL_t1-data_', '')
        filename_num = filename_num.replace('.nii.gz', '')
        y_name = 'y_CL-data_' + filename_num + '.nii.gz'
        x_fa_name = 'x_CL_fa-data_' + filename_num + '.nii.gz'

        x_t1_tar_name = 'x_CL_t1-data_' + str(tar_num) + '.nii.gz'
        x_fa_tar_name = 'x_CL_fa-data_' + str(tar_num) + '.nii.gz'
        y_tar_name = 'y_CL-data_' + str(tar_num) + '.nii.gz'

        shutil.copy(fileDir_x_t1 + x_t1_name, tarDir_CL_t1_x + x_t1_tar_name)
        shutil.copy(fileDir_x_fa + x_fa_name, tarDir_CL_fa_x + x_fa_tar_name)
        shutil.copy(fileDir_y + y_name, tarDir_CL_y + y_tar_name)

        tar_num += 1
    return

if __name__ == '__main__':

    ### train
    fileDir_EC_t1_x = "./ON_mydata/train_T1+FA_label=0/x_EC_t1_data/"    # 源图片文件夹路径
    fileDir_EC_y    = "./ON_mydata/train_T1+FA_label=0/y_EC_data/"       # 源图片文件夹路径
    fileDir_CL_t1_x = "./ON_mydata/train_T1+FA_label=0/x_CL_t1_data/"    # 源图片文件夹路径
    fileDir_CL_fa_x = "./ON_mydata/train_T1+FA_label=0/x_CL_fa_data/"    # 源图片文件夹路径
    fileDir_CL_y    = "./ON_mydata/train_T1+FA_label=0/y_CL_data/"       # 源图片文件夹路径

    tarDir_EC_t1_x = './ON_mydata/train_T1+FA/x_EC_t1_data/'    # 移动到新的文件夹路径
    tarDir_EC_y    = './ON_mydata/train_T1+FA/y_EC_data/'       # 移动到新的文件夹路径
    tarDir_CL_t1_x = "./ON_mydata/train_T1+FA/x_CL_t1_data/"    # 源图片文件夹路径
    tarDir_CL_fa_x = "./ON_mydata/train_T1+FA/x_CL_fa_data/"    # 源图片文件夹路径
    tarDir_CL_y    = "./ON_mydata/train_T1+FA/y_CL_data/"       # 源图片文件夹路径

    train_EC_moveFile(fileDir_EC_t1_x, fileDir_EC_y)
    train_CL_moveFile(fileDir_CL_t1_x, fileDir_CL_fa_x, fileDir_CL_y)



    ### val
    # fileDir_EC_t1_x = "./ON_mydata/val_T1+FA_nonlabel/x_EC_t1_data/"    #源图片文件夹路径
    # fileDir_EC_y    = "./ON_mydata/val_T1+FA_nonlabel/y_EC_data/"  # 源图片文件夹路径
    # fileDir_CL_t1_x = "./ON_mydata/val_T1+FA_nonlabel/x_CL_t1_data/"    #源图片文件夹路径
    # fileDir_CL_fa_x = "./ON_mydata/val_T1+FA_nonlabel/x_CL_fa_data/"  # 源图片文件夹路径
    # fileDir_CL_y    = "./ON_mydata/val_T1+FA_nonlabel/y_CL_data/"  # 源图片文件夹路径
    #
    # tarDir_EC_t1_x = './ON_mydata/val_T1+FA/x_EC_t1_data/'    #移动到新的文件夹路径
    # tarDir_EC_y    = './ON_mydata/val_T1+FA/y_EC_data/'  # 移动到新的文件夹路径
    # tarDir_CL_t1_x = "./ON_mydata/val_T1+FA/x_CL_t1_data/"    #源图片文件夹路径
    # tarDir_CL_fa_x = "./ON_mydata/val_T1+FA/x_CL_fa_data/"  # 源图片文件夹路径
    # tarDir_CL_y    = "./ON_mydata/val_T1+FA/y_CL_data/"  # 源图片文件夹路径
    #
    # train_EC_moveFile(fileDir_EC_t1_x, fileDir_EC_y)
    # train_CL_moveFile(fileDir_CL_t1_x, fileDir_CL_fa_x, fileDir_CL_y)

