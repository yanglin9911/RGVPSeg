import nibabel as nib
import numpy as np
import os
import scipy.signal as signal
import scipy as sp
import scipy.ndimage
import SimpleITK as sitk
import config_2d
test_imgs_path = config_2d.test_imgs_path

batch_size = config_2d.BATCH_SIZE



def DICE_count(input1, input2):
    '''
    :param input1:   "107018_ON-label.nii"
    :param intput2:  "107018_ON-predict.nii"
    :return:
    '''
    smooth = 1.
    input1_label_path = os.path.join(input1)
    input2_predict_path = os.path.join(input2)

    label_load = nib.load(input1_label_path)  # 读取label.nii
    predict_load = nib.load(input2_predict_path)  # 读取predict.nii

    img1 = label_load.get_fdata()
    img2 = predict_load.get_fdata()

    if label_load.shape != predict_load.shape:
        raise ValueError("Shape mismatch: im1 and im2 must have the same shape.")

    VsegandVgt = 0
    Vseg = 0
    Vgt = 0

    #for k in range(z):#25-55
    for k in range(0,128):
        im1 = np.squeeze(img1[:, :, k] > 0.5)
        im2 = np.squeeze(img2[:, :, k] > 0.5)

        if im1.shape != im2.shape:
            raise ValueError("Shape mismatch: im1 and im2 must have the same shape.")

        segandgt = (np.logical_and(im1, im2)).sum() #两个1才为1（取交集）
        Sgt = im1.sum() #每层真实值部分
        Sseg = im2.sum()#每层预测值部分

        VsegandVgt = VsegandVgt + segandgt
        Vgt = Vgt + Sgt   #真实值为1体素个数
        Vseg = Vseg + Sseg #预测值为1体素个数

    #DICE = 2. * (VsegandVgt) /(Vseg + Vgt)
    DICE = (2. * VsegandVgt + smooth) / (Vseg + Vgt + smooth)
    # print("VsegandVgt={}".format(VsegandVgt))
    # print("Vgt={}".format(Vgt))
    # print("Vseg={}".format(Vseg))
    # print("DICE=", DICE)
    # print("done!")
    # print('-' * 30)
    return DICE


def VOE_count(input1, input2):
    '''
    :param input1:   "107018_ON-label.nii"
    :param intput2:  "107018_ON-predict.nii"
    :return:
    '''
    input1_label_path = os.path.join(input1)
    input2_predict_path = os.path.join(input2)

    label_load = nib.load(input1_label_path)  # 读取label.nii
    predict_load = nib.load(input2_predict_path)  # 读取predict.nii

    img1 = label_load.get_fdata()
    img2 = predict_load.get_fdata()

    if label_load.shape != predict_load.shape:
        raise ValueError("Shape mismatch: im1 and im2 must have the same shape.")

    Vseg = 0
    Vgt = 0

    # for k in range(z):#25-55
    for k in range(0, 128):
        im1 = np.squeeze(img1[:, :, k] > 0.5)
        im2 = np.squeeze(img2[:, :, k] > 0.5)

        if im1.shape != im2.shape:
            raise ValueError("Shape mismatch: im1 and im2 must have the same shape.")

        Sgt = im1.sum()  # 每层真实值部分
        Sseg = im2.sum()  # 每层预测值部分

        Vgt = Vgt + Sgt  # 真实值为1体素个数
        Vseg = Vseg + Sseg  # 预测值为1体素个数

    VOE = 2. * (Vseg - Vgt) / (Vseg + Vgt)
    # print("Vgt={}".format(Vgt))
    # print("Vseg={}".format(Vseg))
    # print("VOE=", VOE)
    # print("done!")
    # print('-' * 30)
    return VOE


def HD_count(input1, input2):
    input1_label_path = os.path.join(input1)
    input2_predict_path = os.path.join(input2)

    label_load = nib.load(input1_label_path)  # 读取label.nii
    predict_load = nib.load(input2_predict_path)  # 读取predict.nii

    img1 = label_load.get_fdata()
    img2 = predict_load.get_fdata()

    if label_load.shape != predict_load.shape:
        raise ValueError("Shape mismatch: im1 and im2 must have the same shape.")

    quality=dict()
    labelPred = sitk.GetImageFromArray(img1, isVector=False)
    labelTrue = sitk.GetImageFromArray(img2, isVector=False)
    hausdorffcomputer = sitk.HausdorffDistanceImageFilter()
    hausdorffcomputer.Execute(labelTrue > 0.5, labelPred > 0.5)
    # quality["avgHausdorff"] = hausdorffcomputer.GetAverageHausdorffDistance()
    quality["Hausdorff"] = hausdorffcomputer.GetHausdorffDistance()
    # dicecomputer = sitk.LabelOverlapMeasuresImageFilter()
    # dicecomputer.Execute(labelTrue > 0.5, labelPred > 0.5)
    # quality["dice"] = dicecomputer.GetDiceCoefficient()
    return quality["Hausdorff"]


def MSD_count(input1, input2):
    input1_label_path = os.path.join(input1)
    input2_predict_path = os.path.join(input2)

    label_load = nib.load(input1_label_path)  # 读取label.nii
    predict_load = nib.load(input2_predict_path)  # 读取predict.nii

    img1 = label_load.get_fdata()
    img2 = predict_load.get_fdata()

    if label_load.shape != predict_load.shape:
        raise ValueError("Shape mismatch: im1 and im2 must have the same shape.")

    quality = dict()
    labelPred = sitk.GetImageFromArray(img1, isVector=False)
    labelTrue = sitk.GetImageFromArray(img2, isVector=False)
    hausdorffcomputer = sitk.HausdorffDistanceImageFilter()
    hausdorffcomputer.Execute(labelTrue > 0.5, labelPred > 0.5)
    # dicecomputer = sitk.LabelOverlapMeasuresImageFilter()
    # dicecomputer.Execute(labelTrue > 0.5, labelPred > 0.5)
    quality["avgHausdorff"] = hausdorffcomputer.GetAverageHausdorffDistance()
    # quality["dice"] = dicecomputer.GetDiceCoefficient()
    return quality["avgHausdorff"]


def dice_coef(input1, input2):
    smooth = 1.
    input1_label_path = os.path.join(input1)
    input2_predict_path = os.path.join(input2)

    label_load = nib.load(input1_label_path)  # 读取label.nii
    predict_load = nib.load(input2_predict_path)  # 读取predict.nii

    img1 = label_load.get_fdata()
    img2 = predict_load.get_fdata()


    m1 = img1.flatten()  # Flatten
    m2 = img2.flatten()  # Flatten
    intersection = (m1 * m2).sum()
    return (2. * intersection + smooth) / (m1.sum() + m2.sum() + smooth)


def relative_volume_diatance(input1, input2):
    input1_label_path = os.path.join(input1)
    input2_predict_path = os.path.join(input2)

    label_load = nib.load(input1_label_path)  # 读取label.nii
    predict_load = nib.load(input2_predict_path)  # 读取predict.nii

    img1 = label_load.get_fdata()
    img2 = predict_load.get_fdata()

    m1 = img1.flatten()  # Flatten  # label
    m2 = img2.flatten()  # Flatten  # predict
    return m2.sum()/m1.sum() - 1


if __name__ == '__main__':


    #input_label_base = 'F:/Data/ON_Data/Finish/ON_Data_128x160x128_102/All/Test_Set'
    input_label_base  = '/tmp/LSQ/All/Test_Set'

    predice_name = 'predict_t1fa_fusion_without_data_partition'

    pre_dir = os.listdir(predice_name + '/')
    input_predict_base = predice_name + '/'

    all_dice = []
    all_Iou = []

    with open( predice_name + '/' +'Dice.txt','a+') as f:
        f.writelines('epoch\n')

    with open(predice_name + '/' +'RVD.txt','a+') as f:
        f.writelines('epoch\n')

    with open(predice_name + '/' +'HD.txt','a+') as f:
        f.writelines('epoch\n')

    with open(predice_name + '/' +'ASD.txt', 'a+') as f:
        f.writelines('epoch\n')

    mDice = 0
    Dice = 0

    mHD = 0
    HD = 0.

    mRVD = 0
    RVD = 0.

    ASD = 0
    mASD = 0

    input_predict_name = input_predict_base
    test_dir = os.listdir(input_label_base)


    for num in test_dir:
        input1_label_nii = input_label_base +'/'+ num +'/'+ num + '_ON-label.nii.gz'
        input2_predict_nii = input_predict_name + '/' + 'test_result_'+ num + '/AVP_T1_FA' +'/pre_final-label.nii.gz'


        # DSC
        DICE1 = dice_coef(input1_label_nii, input2_predict_nii)
        Dice = Dice + DICE1
        DICE1 = '%.3f'%(DICE1)
        print('DSC =',DICE1)
        with open(predice_name + '/' +'Dice.txt', 'a+') as f:
            f.writelines('{0}\t'.format(DICE1))

        # RVD
        RVD1 = relative_volume_diatance(input1_label_nii, input2_predict_nii)
        RVD = RVD + RVD1
        RVD1 = '%.3f' % (RVD1 * 100) + "%"
        print('RVD =',RVD1)
        with open(predice_name + '/' +'RVD.txt', 'a+') as f:
            f.writelines('{0}\t'.format(RVD1))

        # HD
        HD1 = HD_count(input1_label_nii, input2_predict_nii)
        HD = HD + HD1
        HD1 = '%.3f' % (HD1)
        print('HD =',HD1)
        with open(predice_name + '/' +'HD.txt', 'a+') as f:
            f.writelines('{0}\t'.format(HD1))

        # ASD
        ASD1 = MSD_count(input1_label_nii, input2_predict_nii)
        ASD = ASD + ASD1
        ASD1 = '%.3f' % (ASD1)
        print('ASD =', ASD1)
        with open(predice_name + '/' +'ASD.txt', 'a+') as f:
            f.writelines('{0}\t'.format(ASD1))



    mDice = Dice / 10
    mDice = '%.3f' % (mDice)
    print("mDice =", mDice)
    with open(predice_name + '/' +'Dice.txt', 'a+') as f:
        f.writelines('{0}\t\n'.format(mDice))

    mRVD = RVD / 10
    mRVD = '%.3f' % (mRVD * 100) + "%"
    print("mRVD =", mRVD)
    with open(predice_name + '/' +'RVD.txt', 'a+') as f:
        f.writelines('{0}\t\n'.format(mRVD))

    mHD = HD / 10
    mHD = '%.3f' % (mHD)
    print("mHD =", mHD)
    with open(predice_name + '/' +'HD.txt', 'a+') as f:
        f.writelines('{0}\t\n'.format(mHD))

    mASD = ASD / 10
    mASD = '%.3f' % (mASD )
    print("mASD =", mASD)
    with open(predice_name + '/' +'ASD.txt', 'a+') as f:
        f.writelines('{0}\t\n'.format(mASD))











    # print("IoU:")
    # for num in test_dir:
    #     input1_label_nii = input_label_base +'/'+ num +'/'+ num + '_ON-label.nii.gz'
    #     input2_predict_nii = input_predict_name + '/' +'test_result_'+ num +'/pre_final-label.nii.gz'
    #     Iou1 = IoU_count(input1_label_nii, input2_predict_nii)
    #     Iou = Iou + Iou1
    #     print("{:.3f}%".format(Iou1 * 100))
    # mIou = Iou / 20
    # print("mIou = {:.3f}%".format( mIou * 100))



    # #1.求IoU：交并比
    # IoU = IoU_count(input1_label_nii, input2_predict_nii)
    # print(">> Testing dataset IoU  = {:.3f}%".format(IoU*100))
    # print("done!")

    # #2.求DICE（DSC/DSI）：表示两物体相交体积占总体积的比值
    # DICE = DICE_count(input1_label_nii, input2_predict_nii)
    # print(">> Testing dataset DICE  = {:.3f}%".format(DICE*100))
    # print("done!")

    # # 3.求VOE：表示错误率
    # VOE = VOE_count(input1_label_nii, input2_predict_nii)
    # print(">> Testing dataset VOE  = {:.3f}%".format(VOE*100))
    # print("done!")
    #
    # # 4.求HD：豪斯多夫距离 最大不相同度
    # HD = HD_count(input1_label_nii, input2_predict_nii)
    # print(">> Testing dataset HD  = {:.3f}".format(HD["Hausdorff"]))
    # print("done!")

