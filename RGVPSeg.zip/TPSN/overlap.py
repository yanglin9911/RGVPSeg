import nibabel as nib
import numpy as np
import os


if __name__ == '__main__':
    label_path = 'F:/Data/ON_Data/Finish/128x160x128_102_T1+FA+hist+mask+label/Test_Set/120515/120515_ON-label.nii.gz'
    pre_label_base = 'D:/Brain/Code/DEEP_LEARNING/Segmentation/Pytorch/Final_example/ON_segmentation_2020.5.18/2DU-net/Test_result/2DUnet_100T1+100FA_fusion_4batch/predict_2d_100T1+100FA_fusion_4batch/2DUnet_T1_Dice_75epoch_4batch/test_result_120515/'
    pre_label_path = pre_label_base + 'pre_final-label.nii.gz'
    output_path = pre_label_base

    label = nib.load(label_path)
    label_data= label.get_data()
    label_affine = label.get_affine()

    pre_label= nib.load(pre_label_path)
    pre_label_data = pre_label.get_data()


    X = label_data.shape

    overlap_label = np.zeros(shape=X, dtype='float32')  # 预测label和标记label重叠部分  TP
    new_label = np.zeros(shape=X, dtype='float32')      # 标记的，但没有预测出来的部分    TN
    new_pre_label = np.zeros(shape=X, dtype='float32')  # 没有标记的，但预测出来的部分    FP


    for i in range(X[0]):
        for j in range(X[1]):
            for k in range(X[2]):
                if label_data[i,j,k]==1 and pre_label_data[i,j,k]==1:
                    overlap_label[i,j,k] = pre_label_data[i,j,k]
                if label_data[i, j, k] == 1 and pre_label_data[i, j, k] == 0:
                    new_label[i,j,k] = label_data[i, j, k]
                if label_data[i, j, k] == 0 and pre_label_data[i, j, k] == 1:
                    new_pre_label[i,j,k]= pre_label_data[i, j, k]

    overlap_label_nii_path = output_path + 'overlap_label.nii.gz'
    new_label_nii_path = output_path + 'new_label.nii.gz'
    new_pre_label_nii_path = output_path + 'new_pre_label.nii.gz'

    overlap_label_nii_data = nib.Nifti1Image(overlap_label, label_affine)
    nib.save(overlap_label_nii_data, overlap_label_nii_path)

    new_label_nii_data = nib.Nifti1Image(new_label, label_affine)
    nib.save(new_label_nii_data, new_label_nii_path)

    new_pre_label_nii_data = nib.Nifti1Image(new_pre_label, label_affine)
    nib.save(new_pre_label_nii_data, new_pre_label_nii_path)


    print('done')
