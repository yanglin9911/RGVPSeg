import config_2d
from NetModel import Unet_2d, Unet_plus_2d, MultiResUnet_2d, MultiResUnet_plus_2d, Newnet
import torch, time
from torch import nn, optim
from torch.utils.data import DataLoader
from traindataset_2d import EC_MyTrainDataset, CL_MyTrainDataset
from torchvision.transforms import transforms
from metrics_2d import dice_loss, dice
import os

unet2d = Unet_2d.UNet2D                             # U-Net
unetplus2d = Unet_plus_2d.UNetPlus2D                # U-Net++

patch_size_w = config_2d.PATCH_SIZE_W
patch_size_h = config_2d.PATCH_SIZE_H
batch_size = config_2d.BATCH_SIZE
n_epochs = config_2d.NUM_EPOCHS
n_classes = config_2d.NUM_CLASSES
image_rows = config_2d.VOLUME_ROWS
image_cols = config_2d.VOLUME_COLS
image_depth = config_2d.VOLUME_DEPS
test_imgs_path = config_2d.test_imgs_path
flag_gpu = config_2d.FLAG_GPU
flag_model = config_2d.MODEL_name

# 是否使用cuda
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# train
def train():
    global model1, losses, train_dataset, train_dataloader, val_dataset, val_dataloader

    lr = 0.002 #
    op_lr = 0.0004 #

    #### 训练集选择
    #For model 1 (ETC_t1)
    ON_train_x_EC_t1_dir = 'ON_mydata/train1_T1+FA/x_EC_t1_data/'
    ON_train_y_EC_dir    = 'ON_mydata/train1_T1+FA/y_EC_data/'



    #### 验证集选择
    #For model 1 (ETC_t1)
    # ON_val_x_EC_t1_dir = 'ON_mydata/val_T1+FA/x_EC_t1_data/'
    # ON_val_y_EC_dir    = 'ON_mydata/val_T1+FA/y_EC_data/'



    # 损失函数选择
    losses1 = dice_loss()
    losses2 = torch.nn.CrossEntropyLoss()


    model1 = unet2d(1,2).to(device)
    train_dataset = EC_MyTrainDataset(ON_train_x_EC_t1_dir, ON_train_y_EC_dir, x_transform=x_transforms, y_transform=y_transforms)
    # val_dataset   = EC_MyTrainDataset(ON_val_x_EC_t1_dir, ON_val_y_EC_dir, x_transform=x_transforms, y_transform=y_transforms)
    # 是否使用多块GPU
    if flag_gpu == 1:
        model1 = nn.DataParallel(model1).cuda()


    ### 模型载入
    # model1.load_state_dict(torch.load(r"outputs_ETC_t1/ETC_t1_100epoch_64batch.pth", map_location='cuda'))
    # model2.load_state_dict(torch.load(r"outputs_CTL_t1/CTL_t1_100epoch_64batch.pth", map_location='cuda'))
    # model3.load_state_dict(torch.load(r"outputs_CTL_fa/CTL_fa_100epoch_64batch.pth", map_location='cuda'))


    train_dataloader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=0)
    # val_dataloader = DataLoader(val_dataset, batch_size=batch_size, shuffle=True, num_workers=0)



###----------------------
#### start train
    print('-' * 30)
    print('Training start...')
    print('-' * 30)
    print('model type   : ', flag_model)
    print('patch size   : ', patch_size_w, 'x', patch_size_h)
    print('batch size   : ', batch_size)
    print('  epoch      : ', n_epochs)
    print('learning rate: ', op_lr)
    print('-' * 30)

    # last_val_epoch_loss = 10


    for epoch in range(0, 100):

        # if (epoch+1) > 20:
        #     op_lr = lr * 0.5

        # if (epoch+1) > 100:
        #     op_lr = lr * 0.5 * 0.5
        #
        # if (epoch+1) > 150:
        #     op_lr = lr * 0.5 * 0.5 * 0.5


        dt_size = len(train_dataloader.dataset)

        ## model1
        epoch_loss_EC_t1 = 0
        epoch_dice_EC_t1 = 0
        loss_EC_t1 = 0


        step = 0


        optimizer1 = optim.Adam(model1.parameters(), lr=op_lr)

        model1.train()
        for x1, y in train_dataloader:
            step += 1

            inputs1 = x1.to(device)  # [batch_size, 9, 144, 144]->model(9,2)-> output:[batch_size, 2, 144, 144]
            groundtruth = y.to(device)
            # 梯度清零
            optimizer1.zero_grad()

            outputs1 = model1(inputs1)  # tensor[batch_size, 2, 144, 144]

            net1_predict = outputs1[:, 1, :, :].squeeze()  # label预测值      tensor[batch_size, 1, 144, 144]

            y_truth = groundtruth.squeeze()  # label真实值      tensor[batch_size, 1, 144, 144]

            loss_EC_t1 = losses1(net1_predict, y_truth)+losses2(net1_predict, y_truth)
            label_dice_EC_t1 = dice(net1_predict, y_truth)

            # 反向传播
            loss_EC_t1.backward()

            # 梯度更新
            optimizer1.step()

            epoch_loss_EC_t1 += float(loss_EC_t1.item())
            epoch_dice_EC_t1 += float(label_dice_EC_t1.item())
            step_loss_EC_t1 = loss_EC_t1.item()
            step_dice_EC_t1 = label_dice_EC_t1.item()


            if step % 10 == 0:
                with open(r'loss/2DUnet_train_ETC_t1_' + str(batch_size) + 'batch_step_loss.txt', 'a+') as f:
                    f.writelines('step{0}\t{1} \n'.format(str(step), str(step_loss_EC_t1)))

            print("epoch:%d/%d, %d/%d, loss_ETC_t1:%0.3f, label_dice_ETC_t1:%0.3f, op_lr:%0.5f" % (epoch + 1,
                                                                                                  n_epochs,
                                                                                                  step * train_dataloader.batch_size,
                                                                                                  dt_size,
                                                                                                  step_loss_EC_t1,
                                                                                                  step_dice_EC_t1,
                                                                                                  op_lr))
        model1_path = 'outputs1_ETC_t1/' + 'ETC_t1_%depoch_%dbatch.pth' % (epoch + 1, batch_size)
        torch.save(model1.state_dict(), model1_path)

        train_epoch_loss_EC_t1 = epoch_loss_EC_t1 / step
        train_epoch_dice_EC_t1 = epoch_dice_EC_t1 / step

        # step_val = 0
        # val_epoch_loss_EC_t1 = 0
        # val_dt_size_EC_t1 = len(val_dataloader.dataset)
        #
        #
        # ## 验证集
        # model1.load_state_dict(torch.load(model1_path, map_location='cpu'))
        # model1.eval()
        # with torch.no_grad():
        #     for x1, y in val_dataloader:
        #         step_val += 1
        #         inputs1 = x1.to(device)  # [batch_size, 9, 144, 144]->model(9,2)-> output:[batch_size, 2, 144, 144]
        #         y_truth = y.to(device)
        #
        #         outputs1_EC_t1 = model1(inputs1)
        #
        #         val_EC_t1_pred = torch.max(outputs1_EC_t1, 1)[1].squeeze().float()  # troch.max()[1]，只返回最大值的每个索引
        #
        #         val_loss_EC_t1 = 1 - dice(val_EC_t1_pred, y_truth)
        #
        #         val_epoch_loss_EC_t1 += float(val_loss_EC_t1.item())
        #
        #         print("epoch:%s, %d/%d, val_loss_EC_t1:%0.3f" % (epoch+1,
        #                                                         step_val * val_dataloader.batch_size,
        #                                                         val_dt_size_EC_t1,
        #                                                         val_loss_EC_t1.item()))
        #
        #     val_epoch_loss_EC_t1 = val_epoch_loss_EC_t1 / step_val

        with open(r'loss/2DUnet_val_ETC_t1_'  + str(batch_size) + 'batch_epoch_loss.txt', 'a+') as f:
            f.writelines('epoch{0}\t{1}\t{2} \n'.format(str(epoch + 1), str(train_epoch_loss_EC_t1), str(train_epoch_dice_EC_t1)))


        print("epoch:%d, train_loss_EC_t1:%0.3f,  val_loss_EC_t1:%0.3f" % (epoch + 1, train_epoch_loss_EC_t1, train_epoch_dice_EC_t1))
        # if val_epoch_loss_EC_t1 > last_val_epoch_loss:
        #     loss_nodecrease_num +=1
        #     if loss_nodecrease_num > 10 :
        #          return
        # else :
        #     loss_nodecrease_num = 0
        # last_val_epoch_loss = val_epoch_loss_EC_t1

        print('-' * 30)





if __name__ == '__main__':

    x_transforms = transforms.Compose([
        transforms.ToPILImage(),
        transforms.RandomHorizontalFlip(0.5),
        transforms.ColorJitter(brightness=0.5, contrast=0.5, hue=0.3),
        transforms.ToTensor(),
        transforms.Normalize((0.5,), (0.5,))
    ])

    y_transforms = transforms.Compose([
        transforms.ToTensor()
    ])

    # 模型保存
    if 'outputs1_ETC_t1' not in os.listdir(os.curdir):
        os.mkdir('outputs1_ETC_t1')


    # loss保存
    if 'loss' not in os.listdir(os.curdir):
        os.mkdir('loss')


    ### train test ###
    start_time = time.time()
    train()
    end_time = time.time()
    print("2D train time is {:.3f} mins".format((end_time - start_time) / 60.0))
    print('-' * 30)
    print('model type   : ', flag_model)
    print('patch size   : ', patch_size_w,'x',patch_size_h)
    print('batch size   : ', batch_size)
    print('  epoch      : ', n_epochs)
    print('-' * 30)
    print("done")




