### 指标画图
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import rcParams
import matplotlib
from matplotlib.pyplot import MultipleLocator
#从pyplot导入MultipleLocator类，这个类用于设置刻度间隔

matplotlib.use("pgf")
pgf_config = {
    "font.family":'serif',
    "font.size": 14,
    "pgf.rcfonts": False,
    "text.usetex": True,
    "pgf.preamble": [
        r"\usepackage{unicode-math}",
        r"\setmainfont{Times New Roman}",
        r"\usepackage{xeCJK}",
        r"\setCJKmainfont{SimSun}",
    ],
}
rcParams.update(pgf_config)

# x = [1,3,5]
# y = [4,2,5]
# plt.plot(x,y)
# plt.savefig('./Dice.png', dpi=600)
# plt.show()

#DSC
# A = [0.798, 0.815,  0.820, 	0.838, 	0.826, 	0.814, 	0.787, 	0.836, 	0.842, 	0.850 ] #  mDSC=0.822   2D Unet T1
# A2 = [ 0.659 ,	0.668 ,	0.726 ,	0.616, 	0.698 ,	0.719 ,	0.666 ,	0.711, 	0.680 ,	0.645 ] #  mDSC=   2D Unet FA
# B = [0.785, 0.822, 	0.821, 	0.854, 	0.845,	0.821, 	0.783, 	0.830, 	0.845, 	0.860 ] #  mDSC=0.827   2D Unet++ T1
# B2 = [0.694, 	0.657, 	0.719, 	0.649 ,	0.682 ,	0.698 ,	0.716 ,	0.752 ,	0.670, 	0.674 ,	0.691 ] #  mDSC=0.691   2D Unet++ FA
# C = [0.832, 0.850, 	0.836, 	0.862, 	0.862, 	0.864, 	0.849, 	0.853,	0.865, 	0.877 ]  # mDSC=0.855  # 2D Newnet T1+FA
# plt.figure(figsize=(16, 12))  # 设置画布的尺寸
# plt.title('A. Dice Similarity Coefficient Comparison', fontsize=40)  # 标题，并设定字号大小
# # boxprops：color箱体边框色，facecolor箱体填充色；
# labels = 'U-Net\n(T1 Only)', 'U-Net\n(FA Only)', 'U-Net\n(T1 Only)', 'U-Net++\n(FA Only)', 'TPSN\n(T1+FA)'
# plt.boxplot([A,A2, B,B2, C], widths=0.5, patch_artist=True, boxprops={'color': 'orangered', 'facecolor': 'pink'}, labels = labels)
# plt.ylabel('Dice similarity coefficient',fontsize=40)
# plt.grid(linestyle="--", alpha=0.8)
# plt.xticks(fontsize=40)
# plt.yticks(fontsize=40)
# plt.savefig('./Dice.png', dpi=600)



# HD (Hausdorff distance)
# A = [2.236067977	,2.449489743,	2.236067977	,2.96	,2.96	,3.464101615,	2.96,	2	,4.242640687	,4.123105626] #  mHD=2.96   2D Unet T1
# A2 = [3,	8.944272,	2.236068,	7.071068	,8.85,	3.162278,	3.741657,	3.162278,	3,	15.937377] #  mHD=2.96   2D Unet FA
# B = [2.97,	3,	2,	4.242640687,	4.123105626	,2.236067977	,2.97,	2,	3.16227766	,3 ] #  mHD=2.97  2D Unet++ T1
# B2 = [3.16227766,	10.63014581	,4.242640687	,7.071067812,	3.741657387	,4.69041576,	3.605551275,	6.557438524	,6.557438524	,5.196152423 ] #  mHD=2.97  2D Unet++ FA
# C = [2,	2.453	,2.236067977,	2.236067977,	1.732050808	,2.236067977	,3	,2.453,	2.449489743	,2.5]  # mHD=2.33  # 2D Newnet T1+FA
# plt.figure(figsize=(16, 12))  # 设置画布的尺寸
# plt.title('B. Hausdorff Distance Comparison', fontsize=40)  # 标题，并设定字号大小
# # boxprops：color箱体边框色，facecolor箱体填充色；
# #y_major_locator=MultipleLocator()  # 间隔
# labels = 'U-Net\n(T1 Only)', 'U-Net\n(FA Only)', 'U-Net\n(T1 Only)', 'U-Net++\n(FA Only)', 'TPSN\n(T1+FA)'
# ax=plt.gca()
# #ax.yaxis.set_major_locator(y_major_locator)
# plt.boxplot([A,A2, B,B2, C], widths=0.5, patch_artist=True, boxprops={'color': 'orangered', 'facecolor': 'pink'}, labels = labels)
# plt.ylabel('Hausdorff distance(mm)',fontsize=40)
# plt.grid(linestyle="--", alpha=0.8)
# plt.xticks(fontsize=40)
# plt.yticks(fontsize=40)
# #plt.ylim(0.1,0.3)  #  值范围
# plt.savefig('./HD.png', dpi=600)




## ASD (the symmetric average surface distance)
A = [0.207, 0.198, 	0.182, 	0.202, 	0.204, 	0.219, 0.272, 0.168, 0.1730, 0.174] #     mASD=0.200   2D Unet T1
A2 = [0.392,	0.487	,0.282	,0.592,	0.422	,0.321	,0.418	,0.332,	0.386,	0.589] #     mASD=0.422   2D Unet FA
B = [0.229, 0.193, 	0.183, 	0.164, 	0.164,	0.191, 0.312, 0.175, 0.168, 0.151 ] #     mASD=0.193   2D Unet++ T1
B2 = [0.34,	0.618,	0.316,	0.577,	0.386,	0.382,	0.34	,0.324,	0.491,	0.422 ] #     mASD=0.420   2D Unet++ FA
C = [0.167, 0.200, 	0.165, 	0.144, 	0.142, 	0.141, 	0.158, 	0.230,	0.143, 0.126 ]  # mASD=0.162  # 2D Newnet T1+FA
plt.figure(figsize=(16, 12))  # 设置画布的尺寸
plt.title('C. Average Surface Distance Comparison', fontsize=40)  # 标题，并设定字号大小
# boxprops：color箱体边框色，facecolor箱体填充色；
# y_major_locator=MultipleLocator(0.05)
labels = 'U-Net\n(T1 Only)', 'U-Net\n(FA Only)', 'U-Net\n(T1 Only)', 'U-Net++\n(FA Only)', 'TPSN\n(T1+FA)'
ax=plt.gca()
# ax.yaxis.set_major_locator(y_major_locator)
plt.boxplot([A,A2, B,B2, C], widths=0.5, patch_artist=True, boxprops={'color': 'orangered', 'facecolor': 'pink'}, labels = labels)
plt.ylabel('Average surface distance(mm)',fontsize=40)
plt.grid(linestyle="--", alpha=0.8)
plt.xticks(fontsize=40)
plt.yticks(fontsize=40)
# plt.ylim(0.1,0.45)
plt.savefig('./ASD.png', dpi=600)

